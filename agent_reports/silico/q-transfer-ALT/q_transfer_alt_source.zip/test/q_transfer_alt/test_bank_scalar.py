"""Focused stdlib validation: python -m unittest discover -s test/q_transfer_alt -p test_bank_scalar.py -v."""
import _q_transfer_alt_testpath  # supports stdlib unittest discovery from repository root
import ast
import builtins
from collections import Counter
import inspect
from pathlib import Path
import random
import sys
import unittest

from q_transfer_alt.bank.bank_scalar import TASKS
from q_transfer_alt.bank.task import Task, canonical, in_domain, output_matches, typed


def integer_inputs():
    rng = random.Random(8219)
    values = set(range(-256, 257))
    values.update([-1000000, -999999, -999998, 999998, 999999, 1000000])
    for value in [10, 100, 1000, 10000, 100000, 1000000, 100001, 101010,
                  121, 123321, 123456, 90909, 777777, 888888]:
        values.update([value, -value])
    for exponent in range(20):
        for delta in [-1, 0, 1]:
            value = 2 ** exponent + delta
            values.update([value, -value])
    values.update(rng.randint(-1000000, 1000000) for _ in range(240))
    return sorted(values)


def string_inputs():
    rng = random.Random(9811)
    values = [
        '', 'a', 'A', '0', ' ', '\n', '\t', '\r', 'ab', 'abc', 'abcd',
        'aba', 'abba', 'abca', 'Aa', 'aA', 'aaaa', 'banana', 'zyxzyx',
        ' left', 'right ', ' both ', ' a  bb\tccc\n', ' \t\r\n',
        '0123456789', '12321', '111', '0a1B2!', 'hello world',
        'é', 'e\u0301', 'Ééßẞ', 'Straße', 'İıI', 'Σσς', 'ΟΣ',
        '中文', '世界世', 'مرحبا', '١٢٣', '१२३', '１２３', '²³Ⅳ½',
        'ﬀﬁﬃ', '\u01c5\u01c6\u01c4', '🙂🙃🙂', '👩\u200d🔬',
        '\u00a0x\u2003y\u202f', '\u001c\u001d\u001e\u001f',
        '\u200b', '\u2028\u2029', '\x00\x01\x7f', '\ufeff',
        '\ud800', '\udfff', '\U0010ffff', 'x\r\ny\rz\nv',
        'a' * 128, ' ' * 128, '🙂' * 128, ('ab\tÇ٣ß\n0' * 16),
    ]
    alphabet = 'aAbB019 \t\n\rßİΣςé\u0301١²中🙂\u2003\x00\ud800'
    for _ in range(160):
        length = rng.randrange(129)
        values.append(''.join(rng.choice(alphabet) for _ in range(length)))
    for _ in range(40):
        # Includes unassigned characters, supplementary planes, and surrogates.
        values.append(''.join(chr(rng.randrange(0x110000))
                              for _ in range(rng.randrange(129))))
    return list(dict.fromkeys(values))


CORPORA = {'int': integer_inputs(), 'str': string_inputs()}
BY_ID = {task.id: task for task in TASKS}


class ScalarBankTests(unittest.TestCase):
    def test_schema_and_named_references(self):
        self.assertEqual(Counter(task.datatype for task in TASKS),
                         {'int': 32, 'str': 32})
        self.assertEqual(len(BY_ID), len(TASKS))
        self.assertEqual(len({task.reference.__name__ for task in TASKS}), len(TASKS))
        for task in TASKS:
            with self.subTest(task=task.id):
                self.assertIsInstance(task, Task)
                self.assertRegex(task.id, r'^py\.(int|str)\.[a-z_]+\.v1$')
                self.assertTrue(task.description)
                self.assertTrue(task.family.startswith(task.datatype + '.'))
                self.assertNotEqual(task.reference.__name__, '<lambda>')
                source = ast.parse(inspect.getsource(task.reference))
                self.assertIsInstance(source.body[0], ast.FunctionDef)
                self.assertFalse(any(isinstance(node, ast.Call)
                                     and isinstance(node.func, ast.Name)
                                     and node.func.id in {'eval', 'exec', task.reference.__name__}
                                     for node in ast.walk(source)))
                self.assertEqual(task.record()['reference_name'], task.reference.__name__)

    def test_standalone_expression_contract(self):
        for task in TASKS:
            with self.subTest(task=task.id):
                self.assertNotIn('\n', task.expression)
                self.assertNotIn(';', task.expression)
                tree = ast.parse(task.expression, mode='eval')
                forbidden = (ast.Lambda, ast.NamedExpr, ast.Await, ast.Yield, ast.YieldFrom)
                self.assertFalse(any(isinstance(node, forbidden) for node in ast.walk(tree)))
                locals_ = {'x'} | {node.id for node in ast.walk(tree)
                                   if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store)}
                names = {node.id for node in ast.walk(tree) if isinstance(node, ast.Name)}
                self.assertIn('x', names)
                self.assertTrue(names <= locals_ | set(dir(builtins)))
                self.assertTrue(names.isdisjoint({'__import__', 'eval', 'exec', 'open', 'globals', 'locals'}))
                self.assertFalse(any(isinstance(node, ast.Attribute) and node.attr.startswith('__')
                                     for node in ast.walk(tree)))

    def test_reference_agreement_and_exact_output_types(self):
        for task in TASKS:
            for value in CORPORA[task.datatype]:
                with self.subTest(task=task.id, value=value):
                    self.assertTrue(in_domain(task.datatype, value))
                    actual = task.evaluate(value)
                    expected = task.reference(value)
                    self.assertTrue(output_matches(task.output_type, actual))
                    self.assertTrue(output_matches(task.output_type, expected))
                    self.assertEqual(typed(actual), typed(expected))

    def test_no_duplicate_finite_suite_signatures(self):
        signatures = {}
        for task in TASKS:
            signature = (task.datatype, tuple(canonical(typed(task.evaluate(value)))
                                              for value in CORPORA[task.datatype]))
            self.assertNotIn(signature, signatures,
                             msg=f'{task.id} duplicates {signatures.get(signature)}')
            signatures[signature] = task.id

    def test_square_root_boundaries(self):
        # Exercise every square and its immediate neighbors in the stated domain.
        root = BY_ID['py.int.sqrt_magnitude.v1']
        square = BY_ID['py.int.perfect_square.v1']
        for k in range(1001):
            for n in [k * k - 1, k * k, k * k + 1]:
                if not 0 <= n <= 1000000:
                    continue
                for signed in {n, -n}:
                    self.assertEqual(root.evaluate(signed), root.reference(signed))
                    self.assertEqual(square.evaluate(signed), square.reference(signed))

    def test_known_semantics(self):
        cases = [
            ('int.floor_half', -3, -2), ('int.ceil_half', -3, -1),
            ('int.modulo_ten', -11, 9), ('int.floor_ten', -11, -20),
            ('int.digits', 0, [0]), ('int.zero_digits', 0, 1),
            ('int.reverse_digits', -1200, 21), ('int.binary', -10, '1010'),
            ('int.bit_positions', -10, [1, 3]), ('int.bit_length', 0, 0),
            ('int.power_two', -8, False), ('int.power_two', 1, True),
            ('int.perfect_square', -4, False), ('int.perfect_square', 0, True),
            ('str.upper', 'Straße', 'STRASSE'), ('str.casefold', 'Σςßİ', 'σσssi\u0307'),
            ('str.words', '\u001c a\u00a0b\u2003', ['a', 'b']),
            ('str.normalize_whitespace', '\u00a0a\t b\n', 'a b'),
            ('str.count_decimal', '٣²９1', 3), ('str.count_ascii_digits', '٣²９1', 1),
            ('str.ascii', '', True), ('str.printable', '', True),
            ('str.palindrome', '', True), ('str.alpha', '', False),
            ('str.reverse', 'e\u0301', '\u0301e'),
            ('str.stable_unique', 'babaB', 'baB'),
            ('str.sorted_unique', 'babaB', ['B', 'a', 'b']),
            ('str.count_lf', '\r\n\u2028\r', 1),
            ('str.codepoints', '\ud800🙂', [0xD800, 0x1F642]),
        ]
        for name, value, expected in cases:
            with self.subTest(name=name, value=value):
                task = BY_ID[f'py.{name}.v1']
                self.assertEqual(typed(task.evaluate(value)), typed(expected))
                self.assertEqual(typed(task.reference(value)), typed(expected))

    def test_family_grouping_is_explicit(self):
        groups = [
            ['int.floor_half', 'int.ceil_half', 'int.modulo_ten', 'int.floor_ten'],
            ['int.digits', 'int.digit_count', 'int.digit_sum', 'int.digit_square_sum',
             'int.digit_max', 'int.zero_digits', 'int.unique_digits', 'int.reverse_digits'],
            ['int.bit_length', 'int.popcount', 'int.lowest_bit', 'int.clear_lowest_bit',
             'int.bit_positions', 'int.binary', 'int.bit_parity', 'int.power_two'],
            ['int.sqrt_magnitude', 'int.perfect_square'],
            ['str.upper', 'str.casefold'], ['str.strip', 'str.lstrip', 'str.rstrip'],
            ['str.reverse', 'str.even_positions', 'str.odd_positions',
             'str.rotate_left', 'str.rotate_right', 'str.first', 'str.last'],
            ['str.words', 'str.word_lengths', 'str.normalize_whitespace', 'str.remove_whitespace'],
            ['str.count_alpha', 'str.alpha', 'str.count_decimal', 'str.decimal', 'str.has_upper'],
            ['str.sorted_chars', 'str.sorted_unique', 'str.stable_unique'],
        ]
        for names in groups:
            self.assertEqual(len({BY_ID[f'py.{name}.v1'].family for name in names}), 1)

    def test_domain_bounds_rejected(self):
        invalid = {'int': [True, False, 1000001, -1000001, 1.0, '1'],
                   'str': ['x' * 129, 0, None, ['x']]}
        for task in TASKS:
            for value in invalid[task.datatype]:
                with self.assertRaises(ValueError):
                    task.evaluate(value)


if __name__ == '__main__':
    unittest.main()
