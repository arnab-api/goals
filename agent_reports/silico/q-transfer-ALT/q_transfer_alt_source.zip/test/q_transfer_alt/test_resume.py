"""Strict completed-product reuse and portable byte identity regressions."""
import _q_transfer_alt_testpath  # supports stdlib unittest discovery from repository root
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

from q_transfer_alt.provenance import (sha, file_sha, dump, verify_resume,
    prepare_resume, create_model_manifest, verify_model_manifest, recipe_hash,
    source_cache_key, PINNED_REVISION)
from q_transfer_alt import CONFIG_DIR


class ResumeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.group = {'id': 'demo'}
        self.rows = [{'id': f'{alt}/demo', 'scenario': alt} for alt in ('ALT1', 'ALT2', 'ALT3')]
        self.sub = self.root / 'source' / 'groups' / 'demo'
        self.sub.mkdir(parents=True)
        self.materials = []
        self.records = []
        for row in self.rows:
            prompts = {k: {'input_ids': [1, 2], 'input_ids_sha256': sha([1, 2])} for k in ('p_src', 'p_kv', 'p_dst')}
            self.materials.append({'id': row['id'], 'row_config_sha256': sha(row), 'prompts': prompts})
            self.records.append({'id': row['id'], 'config_sha256': sha(row),
                'recipe_sha256': 'recipe', 'panel_sha256': 'panel',
                'prompt_hashes': {k: sha([1, 2]) for k in prompts},
                'materialized': 'groups/demo/materialized.json',
                'conditions': {name: {'raw': 'groups/demo/raw.npz', 'input_ids_sha256': sha([1, 2])}
                    for name in ('clean_source', 'clean_destination', 'kv_only', 'kv_plus_source_q')}})
        dump(self.sub / 'materialized.json', self.materials)
        dump(self.sub / 'scores.json', self.records)
        dump(self.sub / 'checks.json', {'group_id': 'demo'})
        (self.sub / 'raw.npz').write_bytes(b'fixture raw bytes')
        self.seal()

    def seal(self):
        dump(self.sub / 'complete.json', {'schema': 'q_transfer_alt_group_v1', 'group_id': 'demo', 'records': 3,
            'panel_sha256': 'panel', 'group_sha256': sha(self.group), 'recipe_sha256': 'recipe',
            'file_sha256': {p.name: file_sha(p) for p in self.sub.iterdir() if p.name != 'complete.json'}})

    def verify(self):
        return verify_resume(self.sub, self.group, self.rows, 'recipe', 'panel')

    def test_valid_and_corrupt_completed(self):
        self.assertEqual(self.verify(), self.records)
        (self.sub / 'raw.npz').write_bytes(b'corrupt')
        with self.assertRaisesRegex(ValueError, 'corrupt'):
            self.verify()

    def test_recipe_and_historical_schema_rejected(self):
        with self.assertRaisesRegex(ValueError, 'recipe'):
            verify_resume(self.sub, self.group, self.rows, 'new', 'panel')
        done = json.loads((self.sub / 'complete.json').read_text())
        del done['schema']
        dump(self.sub / 'complete.json', done)
        with self.assertRaisesRegex(ValueError, 'schema'):
            self.verify()

    def test_missing_inventory_and_unreferenced_extra_rejected(self):
        (self.sub / 'checks.json').unlink()
        self.seal()
        with self.assertRaisesRegex(ValueError, 'required'):
            self.verify()
        dump(self.sub / 'checks.json', {'group_id': 'demo'})
        self.seal()
        (self.sub / 'stale.npz').write_bytes(b'stale')
        with self.assertRaisesRegex(ValueError, 'inventory'):
            self.verify()

    def test_required_refs_and_exact_ids(self):
        self.records[0]['conditions']['kv_only']['raw'] = 'groups/demo/missing.npz'
        dump(self.sub / 'scores.json', self.records)
        self.seal()
        with self.assertRaisesRegex(ValueError, 'raw'):
            self.verify()
        self.records[0]['conditions']['kv_only']['raw'] = 'groups/demo/raw.npz'
        dump(self.sub / 'scores.json', self.records)
        self.materials[0]['prompts']['p_src']['input_ids'] = [9]
        dump(self.sub / 'materialized.json', self.materials)
        self.seal()
        with self.assertRaisesRegex(ValueError, 'input IDs'):
            self.verify()

    def test_validate_before_copy_and_partial_recompute(self):
        out = self.root / 'output'
        target = out / 'groups' / 'demo'
        target.mkdir(parents=True)
        (target / 'stale.npz').write_bytes(b'stale')
        grouped = {'demo': self.rows}
        (self.sub / 'raw.npz').write_bytes(b'corrupt')
        with self.assertRaises(ValueError):
            prepare_resume(out, self.root / 'source', [self.group], grouped, 'recipe', 'panel')
        self.assertEqual(list(target.iterdir()), [target / 'stale.npz'])
        self.seal()
        prepare_resume(out, self.root / 'source', [self.group], grouped, 'recipe', 'panel')
        self.assertFalse((target / 'stale.npz').exists())
        self.assertTrue((target / 'complete.json').exists())
        (target / 'complete.json').unlink()
        prepare_resume(out, None, [self.group], grouped, 'recipe', 'panel')
        self.assertEqual(list(target.iterdir()), [])

    def test_missing_condition_rejected(self):
        del self.records[0]['conditions']['kv_only']
        dump(self.sub / 'scores.json', self.records)
        self.seal()
        with self.assertRaisesRegex(ValueError, 'conditions'):
            self.verify()

    def test_symlink_and_traversal_rejected(self):
        outside = self.root / 'external.npz'
        outside.write_bytes(b'fixture raw bytes')
        (self.sub / 'raw.npz').unlink()
        (self.sub / 'raw.npz').symlink_to(outside)
        with self.assertRaisesRegex(ValueError, 'corrupt'):
            self.verify()
        with self.assertRaises(ValueError):
            prepare_resume(self.root / 'out', None, [{'id': '../escape'}], {'../escape': []}, 'recipe', 'panel')

    def test_completion_metadata_rejected(self):
        done = json.loads((self.sub / 'complete.json').read_text())
        done['group_id'] = 'wrong'
        dump(self.sub / 'complete.json', done)
        with self.assertRaisesRegex(ValueError, 'group/count'):
            self.verify()

    def test_unexpected_groups_and_parent_symlink_rejected(self):
        out = self.root / 'output'
        (out / 'groups' / 'wrong').mkdir(parents=True)
        with self.assertRaisesRegex(ValueError, 'Unexpected groups'):
            prepare_resume(out, None, [self.group], {'demo': self.rows}, 'recipe', 'panel')
        shutil.rmtree(out / 'groups')
        (out / 'groups').symlink_to(self.root / 'source' / 'groups')
        with self.assertRaisesRegex(ValueError, 'Symlinked groups'):
            prepare_resume(out, None, [self.group], {'demo': self.rows}, 'recipe', 'panel')

    def test_manifest_copy_identity_and_corruption(self):
        model = self.root / 'model'
        model.mkdir()
        for name in ('config.json', 'tokenizer_config.json', 'tokenizer.json'):
            (model / name).write_text('{}')
        (model / 'model.safetensors').write_bytes(b'fake model, no loading')
        (model / 'chat_templates').mkdir()
        (model / 'chat_templates' / 'default.jinja').write_text('{{ messages }}')
        manifest = create_model_manifest(model)
        self.assertIn('chat_templates/default.jinja', manifest['files'])
        path = self.root / 'manifest.json'
        dump(path, manifest)
        copied = self.root / 'copied'
        shutil.copytree(model, copied)
        (copied / '.cache').mkdir()
        (copied / '.cache' / 'unrelated').write_text('different cache layout')
        self.assertEqual(verify_model_manifest(model, path), verify_model_manifest(copied, path))
        (copied / 'tokenizer.json').write_text('{"changed":true}')
        with self.assertRaisesRegex(ValueError, 'bytes'):
            verify_model_manifest(copied, path)
        (model / 'model.safetensors.index.json').write_text('{"weight_map":{"x":"missing.safetensors"}}')
        with self.assertRaisesRegex(ValueError, 'shards'):
            create_model_manifest(model)

    def test_recipe_dynamic_bytes_and_source_key(self):
        panel = self.root / 'panel.json'
        panel.write_text('{}')
        lock = self.root / 'uv.lock'
        lock.write_text('version = 1')
        heads = [(0, 1)]
        baseline = recipe_hash(panel, heads, {'revision': PINNED_REVISION}, {'alpha': 1}, lock)
        panel.write_text('{}\n')
        self.assertNotEqual(baseline, recipe_hash(panel, heads, {'revision': PINNED_REVISION}, {'alpha': 1}, lock))
        panel.write_text('{}')
        lock.write_text('version = 2')
        self.assertNotEqual(baseline, recipe_hash(panel, heads, {'revision': PINNED_REVISION}, {'alpha': 1}, lock))
        self.assertNotEqual(source_cache_key([1, 2], heads, baseline), source_cache_key([1, 3], heads, baseline))
        self.assertNotEqual(source_cache_key([1, 2], heads, baseline), source_cache_key([1, 2], heads, 'new'))


if __name__ == '__main__':
    unittest.main()


class RuntimeVersionTests(unittest.TestCase):
    def test_actual_runtime_versions_bound_and_wrong_numerical_stack_rejected(self):
        from unittest.mock import patch
        from q_transfer_alt.runtime import runtime_versions
        versions = {'torch': '2.11.0+cu128', 'numpy': '2.4.6', 'transformers': '5.18.0',
                    'tokenizers': '0.22.2', 'huggingface-hub': '1.10.0', 'safetensors': '0.6.2'}
        with patch('q_transfer_alt.runtime.platform.python_version_tuple', return_value=('3','11','17')), \
             patch('q_transfer_alt.runtime.platform.python_version', return_value='3.11.17'), \
             patch('q_transfer_alt.runtime.importlib.metadata.version', side_effect=versions.__getitem__):
            self.assertEqual(runtime_versions(), {'python': '3.11.17', 'versions': versions})
            for name in ('torch', 'numpy', 'transformers'):
                old = versions[name]
                versions[name] = '0.0.0'
                with self.assertRaisesRegex(RuntimeError, name):
                    runtime_versions()
                versions[name] = old
