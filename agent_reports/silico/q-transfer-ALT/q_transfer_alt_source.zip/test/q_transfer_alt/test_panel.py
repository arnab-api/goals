"""Model-free regression checks for the full original scientific panel."""
import _q_transfer_alt_testpath  # supports stdlib unittest discovery from repository root
import copy
from dataclasses import replace
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from contextlib import redirect_stdout, redirect_stderr
from unittest.mock import patch

from q_transfer_alt import CONFIG_DIR
from q_transfer_alt.bank.builder import implementation_hash
from q_transfer_alt.bank.registry import Registry
from q_transfer_alt.bank.render import opaque_names, render_prompt
from q_transfer_alt.bank.sampling import InfeasibleSampling, sample_roles, assignment_space, pool_for
from q_transfer_alt.bank.scenarios import Layout, SCENARIOS as BANK_SCENARIOS
from q_transfer_alt.loader import load_panel
from q_transfer_alt.panel import build_panel, main, SCENARIOS
from q_transfer_alt.validate_panel import digest, validate_panel, PREDICTIONS, OLD16_SIGNATURES

ORIGINAL_SHA256 = "c8fdfc60501fcfe5b020684798d81ebe19c0dd6333e0194be586a458dcb6808d"


class PanelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original_bytes = (CONFIG_DIR / "panel.original.json").read_bytes()
        cls.original = json.loads(cls.original_bytes)
        cls.panel = build_panel()

    def test_exact_original_bytes_and_heads(self):
        self.assertEqual(hashlib.sha256(self.original_bytes).hexdigest(), ORIGINAL_SHA256)
        self.assertEqual(load_panel(CONFIG_DIR / "panel.original.json"), self.original)
        heads = (CONFIG_DIR / "goal250.json").read_bytes()
        self.assertEqual(json.loads(heads), self.original["goal_heads"])
        self.assertEqual(hashlib.sha256(heads).hexdigest(), self.original["goal_heads_sha256"])

    def test_full_scientific_equality_and_current_provenance(self):
        ignored = {"content_sha256", "bank_implementation_sha256", "generation_provenance"}
        self.assertEqual({k: v for k, v in self.panel.items() if k not in ignored},
                         {k: v for k, v in self.original.items() if k not in ignored})
        self.assertEqual(self.panel["bank_implementation_sha256"], implementation_hash())
        self.assertNotEqual(self.panel["bank_implementation_sha256"],
                            self.original["bank_implementation_sha256"])
        self.assertNotEqual(self.panel["content_sha256"], self.original["content_sha256"])
        self.assertFalse(self.panel["generation_provenance"]["historical_panel_read"])
        self.assertEqual(validate_panel(self.panel)["row_count"], 384)

    def test_deterministic_without_reading_frozen_panel(self):
        read_bytes, read_text = Path.read_bytes, Path.read_text
        def guarded_bytes(path, *args, **kwargs):
            self.assertNotEqual(path.name, "panel.original.json")
            return read_bytes(path, *args, **kwargs)
        def guarded_text(path, *args, **kwargs):
            self.assertNotEqual(path.name, "panel.original.json")
            return read_text(path, *args, **kwargs)
        with patch.object(Path, "read_bytes", guarded_bytes), patch.object(Path, "read_text", guarded_text):
            self.assertEqual(build_panel(), self.panel)
        self.assertEqual((CONFIG_DIR / "panel.original.json").read_bytes(), self.original_bytes)
        with self.assertRaisesRegex(ValueError, "Unknown preset"):
            build_panel("smaller-grid")

    def test_rows_families_seeds_predictions_and_explicit_orders(self):
        self.assertEqual(len(self.panel["groups"]), 128)
        self.assertEqual(len(self.panel["rows"]), 384)
        scalar_overlap = False
        for group in self.panel["groups"]:
            roles, families = group["roles"], group["family_by_role"]
            self.assertEqual(list(roles), list("abcdefxyz"))
            self.assertEqual(len(set(roles.values())), 9)
            self.assertEqual(len({families[r] for r in "bcdef"}), 5)
            if group["datatype"].startswith("list"):
                self.assertEqual(len(set(families.values())), 9)
            else:
                scalar_overlap |= len(set(families.values())) < 9
            self.assertEqual(group["opaque_names"], opaque_names("abcdefxyz", group["seed"]))
            rows = [r for r in self.panel["rows"] if r["group_id"] == group["id"]]
            self.assertEqual([r["scenario"] for r in rows], ["ALT1", "ALT2", "ALT3"])
            for row in rows:
                scenario = SCENARIOS[row["scenario"]]
                self.assertEqual(row["predictions"], PREDICTIONS[row["scenario"]])
                for key, layout in (("p_src", scenario.src), ("p_kv", scenario.kv), ("p_dst", scenario.dst)):
                    self.assertEqual(row["prompts"][key]["listed_roles"], list(layout.listed))
                    self.assertEqual(row["prompts"][key]["written_roles"], list(layout.written))
        self.assertTrue(scalar_overlap, "Supporting scalar families must not be forced distinct")

    def test_smoke_exclusions_and_prompt_examples_are_closed(self):
        fixture = json.loads((CONFIG_DIR / "smoke_exclusions.json").read_text())
        self.assertEqual(fixture["content_sha256"], digest({k: v for k, v in fixture.items() if k != "content_sha256"}))
        self.assertEqual(len(OLD16_SIGNATURES), 16)
        new = {(r["datatype"], digest(r["roles"])) for r in self.panel["rows"] if r["scenario"] == "ALT1"}
        self.assertTrue(new.isdisjoint(OLD16_SIGNATURES))
        examples = json.loads((CONFIG_DIR / "prompt_examples.json").read_text())
        self.assertEqual(examples["source_panel_file_sha256"], ORIGINAL_SHA256)
        self.assertEqual(examples["rows"], [r for r in self.panel["rows"] if r["group_id"].endswith("-00")])
        self.assertEqual(len(examples["rows"]), 12)

    def test_cli_required_output_roundtrip_and_immutable_original(self):
        with redirect_stderr(io.StringIO()), self.assertRaises(SystemExit) as missing:
            main([])
        self.assertEqual(missing.exception.code, 2)
        with redirect_stderr(io.StringIO()), self.assertRaises(SystemExit) as immutable:
            main(["--output", str(CONFIG_DIR / "panel.original.json")])
        self.assertEqual(immutable.exception.code, 2)
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "panel.json"
            with redirect_stdout(io.StringIO()):
                self.assertEqual(main(["--output", str(path)]), 0)
            self.assertEqual(load_panel(path), self.panel)
            corrupted = copy.deepcopy(self.panel)
            corrupted["rows"][0]["seed"] += 1
            path.write_text(json.dumps(corrupted))
            with self.assertRaises(ValueError):
                load_panel(path)

    def test_standard_library_only_import_and_build(self):
        source = str(CONFIG_DIR.parents[1] / "src")
        code = (f"import sys; sys.path.insert(0, {source!r}); "
                "from q_transfer_alt.panel import build_panel; "
                "from q_transfer_alt.loader import load_panel; "
                "from q_transfer_alt.prompts import materialize_group; "
                "p=build_panel(); assert len(p['rows'])==384; "
                "assert not {'torch','numpy','transformers','silico'} & set(sys.modules)")
        result = subprocess.run([sys.executable, "-S", "-c", code], capture_output=True, text=True, timeout=30)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_malformed_roots_and_domain_tampering_rejected(self):
        for malformed in (None, [], "panel", 1, True, {}):
            with self.subTest(value=malformed), self.assertRaises(ValueError):
                validate_panel(malformed)
        for field, value in (("input_domains", {}), ("renderer_version", "2.0.0")):
            p = copy.deepcopy(self.panel)
            p[field] = value
            p["content_sha256"] = digest({k: v for k, v in p.items() if k != "content_sha256"})
            with self.subTest(field=field), self.assertRaises(ValueError):
                validate_panel(p)

    def test_exact_head_order_and_settings_rejected_even_rehashed(self):
        for change in ("head_order", "settings", "head_hash"):
            p = copy.deepcopy(self.panel)
            if change == "head_order":
                p["goal_heads"][0], p["goal_heads"][1] = p["goal_heads"][1], p["goal_heads"][0]
            elif change == "settings":
                p["settings"]["ov_boost_alpha"] = 2.0
            else:
                p["goal_heads_sha256"] = "0" * 64
            p["content_sha256"] = digest({k: v for k, v in p.items() if k != "content_sha256"})
            with self.subTest(change=change), self.assertRaises(ValueError):
                validate_panel(p)


class BankRegistryTests(unittest.TestCase):
    def test_finite_suite_registry_and_duplicates(self):
        registry = Registry()
        evidence = registry.validate()
        self.assertEqual(evidence["task_counts"], {d: 32 for d in ("int", "str", "list[int]", "list[str]")})
        self.assertEqual(evidence["signature_count"], 128)
        self.assertEqual(evidence["expression_reference_comparisons"], 13504)
        task = registry.tasks[0]
        with self.assertRaisesRegex(ValueError, "Duplicate task ID"):
            Registry([task, task])
        duplicate = replace(task, id="py.int.another.v1", description="Another description.")
        with self.assertRaisesRegex(ValueError, "Duplicate functional signature"):
            Registry([task, duplicate]).validate()
        with self.assertRaisesRegex(ValueError, "Unknown predicate"):
            registry.get("bogus")

    def test_sampling_constraints_and_explicit_written_order(self):
        registry = Registry()
        with self.assertRaises(InfeasibleSampling):
            sample_roles(registry, BANK_SCENARIOS["ALT2_KV"], "int", 73)
        roles, report = sample_roles(registry, BANK_SCENARIOS["ALT2_KV"], "list[str]", 73)
        self.assertEqual(roles, sample_roles(registry, BANK_SCENARIOS["ALT2_KV"], "list[str]", 73)[0])
        self.assertEqual(len({registry.get(i).family for i in roles.values()}), 9)
        self.assertEqual(report["family_policy"], "distinct")
        names = opaque_names(roles, 73)
        prompt = render_prompt(registry, roles, names, "list[str]", Layout(tuple("abcd"), tuple("dba")))
        self.assertEqual([a["role"] for a in prompt["supplied_assignments"]], list("dba"))
        self.assertEqual(prompt["completed_set"], list("abd"))
        self.assertEqual(prompt["frontier_role"], "c")
        self.assertEqual(assignment_space(pool_for(registry, "int"), 9, "distinct")["feasible_ordered_role_assignments"], 0)


if __name__ == "__main__":
    unittest.main()
