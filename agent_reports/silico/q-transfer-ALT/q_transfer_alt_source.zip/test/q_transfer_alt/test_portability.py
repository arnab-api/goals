"""Import/CLI contracts checked without site-packages, weights, or host state."""
import _q_transfer_alt_testpath  # supports stdlib unittest discovery from repository root
import ast
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[2]


class PortabilityTests(unittest.TestCase):
    def cli(self, name, args, cwd):
        script = ROOT / 'scripts/diff' / ('q_transfer_alt_' + name + '.py')
        env = {k: v for k, v in os.environ.items()
               if not k.startswith('SILICO_') and k not in ('PYTHONPATH', 'HF_TOKEN')}
        # -S removes third-party packages. CLI build/help/dry-run must be stdlib-only.
        proc = subprocess.run([sys.executable, '-S', str(script), *args], cwd=cwd,
                              env=env, text=True, capture_output=True, timeout=45)
        self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
        return proc

    def test_help_without_model_packages_from_unrelated_cwd(self):
        with tempfile.TemporaryDirectory() as tmp:
            for name in ('build', 'run', 'analyze', 'manifest'):
                with self.subTest(name=name):
                    self.assertIn('usage:', self.cli(name, ['--help'], tmp).stdout)

    def test_builder_and_dryrun_are_model_free_and_portable(self):
        with tempfile.TemporaryDirectory() as tmp:
            panel = str(Path(tmp) / 'panel.json')
            self.cli('build', ['--preset', 'original-grid', '--output', panel], tmp)
            generated = json.loads(Path(panel).read_text())
            self.assertEqual(len(generated['groups']), 128)
            self.assertEqual(len(generated['rows']), 384)
            out = str(Path(tmp) / 'dry')
            self.cli('run', ['--panel', panel, '--output', out, '--dry-run'], tmp)
            self.assertTrue((Path(out) / 'dry_run.json').is_file())

    def test_no_generation_calls_or_legacy_setup_imports(self):
        for path in (ROOT / 'src/q_transfer_alt').rglob('*.py'):
            tree = ast.parse(path.read_text())
            for node in ast.walk(tree):
                if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
                    self.assertNotEqual(node.func.attr, 'generate', str(path))
                if isinstance(node, ast.ImportFrom):
                    self.assertFalse((node.module or '').startswith(('src.', 'nnsight', 'baukit')),
                                     str(path) + ': ' + str(node.module))
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        self.assertFalse(alias.name.startswith(('src.', 'nnsight', 'baukit')),
                                         str(path) + ': ' + alias.name)
            text = path.read_text()
            for forbidden in ('SILICO_', '/srv/silico-state/', '/mnt/', 'SILICO_REUSED_VOLUME_DIR'):
                self.assertNotIn(forbidden, text, str(path))


if __name__ == '__main__':
    unittest.main()
