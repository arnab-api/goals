"""CPU fake-model regression tests; deliberately do not import Transformers."""
import _q_transfer_alt_testpath  # supports stdlib unittest discovery from repository root
import contextlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import types
import unittest

import torch
from q_transfer_alt.interventions import capture, query_patch, kv_patch
from q_transfer_alt.observe import Gaze, native_gaze
from q_transfer_alt.runtime_helpers import projections, audited_query, rotation_audit, arrays
from q_transfer_alt.runtime import summarize
from q_transfer_alt import CONFIG_DIR


def apply_rotary_pos_emb(q, k, cos, sin):
    def rotate(x):
        a, b = x.chunk(2, dim=-1)
        return torch.cat((-b, a), dim=-1)
    cos, sin = cos[:, None], sin[:, None]
    return q * cos + rotate(q) * sin, k * cos + rotate(k) * sin


def eager_attention_forward(module, query, key, value, attention_mask, **kwargs):
    k = key.repeat_interleave(module.num_key_value_groups, dim=1)
    v = value.repeat_interleave(module.num_key_value_groups, dim=1)
    scores = query @ k.transpose(-2, -1) * module.scaling
    n = query.shape[-2]
    scores = scores.masked_fill(torch.ones(n, n, dtype=torch.bool).triu(1), float('-inf'))
    weights = scores.softmax(-1)
    return (weights @ v).transpose(1, 2).contiguous(), weights


class Attention(torch.nn.Module):
    def __init__(self, layer):
        super().__init__()
        self.layer_idx = layer
        self.head_dim = 2
        self.num_key_value_groups = 2
        self.scaling = 2 ** -.5
        self.sliding_window = None
        self.q_proj = torch.nn.Linear(8, 8, bias=False)
        self.k_proj = torch.nn.Linear(8, 4, bias=False)
        self.v_proj = torch.nn.Linear(8, 4, bias=False)
        self.o_proj = torch.nn.Linear(8, 8, bias=False)

    def forward(self, hidden_states, position_embeddings, attention_mask, **kwargs):
        def project(p):
            return p(hidden_states).view(1, -1, p.out_features // 2, 2).transpose(1, 2)
        q, k = apply_rotary_pos_emb(project(self.q_proj), project(self.k_proj), *position_embeddings)
        output, weights = eager_attention_forward(self, q, k, project(self.v_proj), attention_mask)
        return self.o_proj(output.reshape(1, -1, 8)), weights


class Block(torch.nn.Module):
    def __init__(self, layer):
        super().__init__()
        self.self_attn = Attention(layer)


class Core(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.layers = torch.nn.ModuleList([Block(0), Block(1)])

    def rotary_emb(self, dummy, positions):
        angles = positions.to(dummy.dtype)[..., None].expand(-1, -1, 2) * .2
        return angles.cos(), angles.sin()


class Model(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.model = Core()
        self.embedding = torch.nn.Embedding(32, 8)

    def forward(self, input_ids, attention_mask=None, use_cache=False, **kwargs):
        if use_cache:
            raise AssertionError('No generation/cache in this fake model')
        h = self.embedding(input_ids)
        positions = torch.arange(h.shape[1])[None]
        emb = self.model.rotary_emb(h, positions)
        for block in self.model.layers:
            h = block.self_attn(h, emb, attention_mask)[0]
        return types.SimpleNamespace(logits=h)


class RuntimeTests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1)
        torch.manual_seed(9)
        self.model = Model().eval()
        self.heads = [(0, 1), (1, 2)]
        self.inp = {'input_ids': torch.tensor([[1, 2, 3, 4, 5, 6]])}
        donor = {'input_ids': torch.tensor([[7, 8, 9, 10, 11, 12]])}
        self.q = capture(self.model, donor, [0, 1], [-1], 'q')
        self.k = capture(self.model, donor, [0, 1], [1, 2], 'k')
        self.v = capture(self.model, donor, [0, 1], [1, 2], 'v')

    def test_routing_gaze_self_transfer_and_raw_scores(self):
        with torch.inference_mode():
            native = self.model(**self.inp).logits
            gaze = Gaze(self.heads)
            with native_gaze(self.model, gaze):
                observed = self.model(**self.inp).logits
            self.assertTrue(torch.equal(native, observed))
            gaze.validate()
            with kv_patch(self.model, self.heads, self.k, self.v, [2, 3]), query_patch(self.model, self.q, self.heads):
                plain = self.model(**self.inp).logits
            gaze = Gaze(self.heads)
            with kv_patch(self.model, self.heads, self.k, self.v, [2, 3], gaze.transferred) as state:
                self.assertEqual(rotation_audit(self.model, state, self.k), {0: 0., 1: 0.})
                with audited_query(self.model, self.q, self.heads) as audit:
                    observed = self.model(**self.inp).logits
            self.assertEqual(state['forward_calls'], {0: 1, 1: 1})
            self.assertTrue(torch.equal(plain, observed))
            self.assertFalse(torch.equal(native, observed))
            gaze.validate()
            for check in gaze.checks.values():
                self.assertEqual(check['selected_routed_max_abs'], 0)
                self.assertEqual(check['unselected_native_max_abs'], 0)
            self.assertEqual(audit[0]['edited_position'], 5)
            for key, value in audit.items():
                self.assertEqual(value['all_raw_q_replacement_max_abs'], 0)
            with tempfile.TemporaryDirectory() as tmp:
                p = arrays(gaze, Path(tmp) / 'raw.npz')
                rec = summarize(p, {'e': [2, 3], 'a': [0]}, 'raw.npz', 'ids')
                expected = float((p['attention'][:, [2, 3]] * p['value_norm'][:, [2, 3]]).mean())
                self.assertEqual(rec['scores']['e'], expected)
                self.assertEqual(rec['description_token_counts']['e'], 2)
            specs = {w: (w, [0, 1], [-1] if w == 'q' else [2, 3]) for w in ('q', 'k', 'v')}
            with projections(self.model, specs) as stores:
                self.model(**self.inp)
            with kv_patch(self.model, self.heads, stores['k'], stores['v'], [2, 3]), query_patch(self.model, stores['q'], self.heads):
                noop = self.model(**self.inp).logits
            self.assertTrue(torch.equal(native, noop))

    def test_only_selected_final_pre_rope_q_changes(self):
        attn = self.model.model.layers[0].self_attn
        x = torch.randn(1, 6, 8)
        clean = attn.q_proj(x)
        with query_patch(self.model, self.q, [(0, 1)]):
            changed = attn.q_proj(x)
        expected = clean.clone()
        expected[:, -1, 2:4] = self.q[0][:, 2:4]
        self.assertTrue(torch.equal(expected, changed))
        self.assertTrue(torch.equal(attn.q_proj(x), clean))

    @torch.inference_mode()
    def test_context_restoration_on_forward_error(self):
        before = [b.self_attn.forward for b in self.model.model.layers]
        eager = eager_attention_forward
        with self.assertRaisesRegex(RuntimeError, 'deliberate'):
            with native_gaze(self.model, Gaze(self.heads)), projections(self.model, {'q': ('q', [0], [-1])}), kv_patch(self.model, self.heads, self.k, self.v, [2, 3]), audited_query(self.model, self.q, self.heads):
                self.model(**self.inp)
                raise RuntimeError('deliberate')
        self.assertIs(eager_attention_forward, eager)
        self.assertEqual(before, [b.self_attn.forward for b in self.model.model.layers])
        self.assertTrue(all(not b.self_attn.q_proj._forward_hooks for b in self.model.model.layers))
        self.assertTrue(all('forward' not in b.self_attn.__dict__ for b in self.model.model.layers))

    @torch.inference_mode()
    def test_observer_error_during_forward_restores_contexts(self):
        originals = [b.self_attn.forward for b in self.model.model.layers]
        def broken_observer(*args):
            raise RuntimeError('observer failure')
        with self.assertRaisesRegex(RuntimeError, 'observer failure'):
            with kv_patch(self.model, self.heads, self.k, self.v, [2, 3], broken_observer), query_patch(self.model, self.q, self.heads):
                self.model(**self.inp)
        self.assertEqual(originals, [b.self_attn.forward for b in self.model.model.layers])
        self.assertTrue(all(not b.self_attn.q_proj._forward_hooks for b in self.model.model.layers))

    def test_partial_setup_restores_instance_override(self):
        attn = self.model.model.layers[0].self_attn
        override = attn.forward
        attn.forward = override
        with self.assertRaises(ValueError):
            with kv_patch(self.model, self.heads, {0: self.k[0]}, self.v, [2, 3]):
                pass
        self.assertIs(attn.forward, override)
        with self.assertRaises(ValueError):
            with query_patch(self.model, {0: self.q[0]}, self.heads):
                pass
        self.assertFalse(attn.q_proj._forward_hooks)

    def test_help_and_dry_run_standard_library_only(self):
        code = '''
import sys
class BlockHeavy:
    def find_spec(self, fullname, *args):
        if fullname.split('.')[0] in {'torch','numpy','transformers'}:
            raise RuntimeError('heavy import: '+fullname)
sys.meta_path.insert(0, BlockHeavy())
from q_transfer_alt.runtime import main
main(sys.argv[1:])
'''
        code = 'import sys; sys.path.insert(0, ' + repr(str(_q_transfer_alt_testpath.ROOT / 'src')) + ')\n' + code
        help_result = subprocess.run([sys.executable, '-c', code, '--help'], capture_output=True, text=True)
        self.assertEqual(help_result.returncode, 0, help_result.stderr)
        with tempfile.TemporaryDirectory() as tmp:
            result = subprocess.run([sys.executable, '-c', code, '--panel', str(CONFIG_DIR / 'panel.original.json'), '--output', tmp, '--dry-run'], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            data = json.loads((Path(tmp) / 'dry_run.json').read_text())
            self.assertEqual((data['groups'], data['rows'], data['primary_conditions'], data['heads']), (128, 384, 768, 250))
            self.assertFalse(data['tokenization_performed'])
            self.assertFalse(data['inference_performed'])


if __name__ == '__main__':
    unittest.main()
