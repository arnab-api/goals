"""Tiny synthetic checks only: no real experiment analysis or model loading."""
import _q_transfer_alt_testpath  # supports stdlib unittest discovery from repository root
from copy import deepcopy
import csv
import hashlib
import json
import sys

import numpy as np
import unittest
from unittest.mock import patch
from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess
import os

from q_transfer_alt import analysis


def condition(scores, raw='raw.npz', positions=None, ids=None):
    positions = positions or {r: [i] for i, r in enumerate(scores)}
    winners = [r for r, s in scores.items() if s == max(scores.values())]
    return {'scores': scores, 'sums': {r: s * len(positions[r]) for r, s in scores.items()},
            'description_token_counts': {r: len(p) for r, p in positions.items()},
            'description_positions': positions, 'winners': winners, 'tie': len(winners) > 1,
            'raw': raw, 'input_ids_sha256': analysis.digest(ids or [10, 11, 12, 13]),
            'token_count': len(ids or [10, 11, 12, 13])}


def small_records():
    records = []
    for datatype in ('int', 'str'):
        for group in range(3):
            for scenario, roles in [('ALT1', 'abde'), ('ALT2', 'adef'), ('ALT3', 'acbe')]:
                before = {r: float(np.float32((group + 1) / 16)) for r in roles}
                before['e'] += .5
                after = dict(before)
                after['e'] += (group + 1) / 8
                if group == 0 and scenario == 'ALT1':
                    after['d'] = after['e']  # preserve an exact tie
                cs = {name: condition(scores) for name, scores in zip(analysis.PRIMARY, (before, after))}
                for c in cs.values():
                    c['set_minus_alternative'] = c['scores']['e'] - c['scores'][analysis.ALTERNATIVE[scenario]]
                cs.update(clean_source=condition(dict(zip('abcd', [.25] * 4))),
                          clean_destination=condition(dict(zip('axyz', [.25] * 4))))
                gid = f'{datatype}-{group}'
                records.append({'id': scenario + '/' + gid, 'group_id': gid, 'datatype': datatype,
                                'scenario': scenario, 'seed': group, 'config_sha256': 'config', 'panel_sha256': 'panel',
                                'roles': {r: 'task.' + r for r in 'abcdefxyz'}, 'predictions': {},
                                'prompt_hashes': {p: p + '-hash' for p in ('p_src', 'p_kv', 'p_dst')},
                                'materialized': 'map.json', 'source_cache_key': 'cache', 'conditions': cs,
                                'paired_margin_change': cs[analysis.PRIMARY[1]]['set_minus_alternative'] -
                                                        cs[analysis.PRIMARY[0]]['set_minus_alternative']})
    return records


def refresh_manifest(sub):
    complete = analysis.load(sub / 'complete.json')
    complete['file_sha256'] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                               for p in sub.iterdir() if p.is_file() and p.name != 'complete.json'}
    analysis.dump(sub / 'complete.json', complete)


def make_pilot_grid(tmp_path, historical=False):
    """Four one-group datatypes with tiny causal rows and real artifact contracts."""
    from q_transfer_alt.provenance import source_cache_key

    root, grid = tmp_path / 'project', tmp_path / 'grid'
    (root / 'configs').mkdir(parents=True)
    grid.mkdir()
    panel = {'groups': [], 'rows': [], 'goal_heads': [[0, 0], [1, 1]]}
    for datatype in ('int', 'str', 'list[int]', 'list[str]'):
        gid = datatype + '-group-00'
        panel['groups'].append({'id': gid, 'datatype': datatype, 'index': 0})
        for scenario, kv_roles in [('ALT1', 'abde'), ('ALT2', 'adef'), ('ALT3', 'acbe')]:
            panel['rows'].append({'id': scenario + '/' + gid, 'group_id': gid, 'datatype': datatype,
                                  'scenario': scenario, 'seed': 0, 'roles': {r: 'task.' + r for r in 'abcdefxyz'},
                                  'predictions': {}, 'prompts': {k: {'listed_roles': list(rs)} for k, rs in
                                  [('p_src', 'abcd'), ('p_kv', kv_roles), ('p_dst', 'axyz')]}})
    analysis.dump(root / 'configs/panel.json', panel)
    panel_sha = hashlib.sha256((root / 'configs/panel.json').read_bytes()).hexdigest()
    analysis.dump(grid / 'environment.json', {'panel_sha256': panel_sha, 'revision': 'synthetic', 'pilot': True, 'schema': 'q_transfer_alt_run_v1', 'recipe_sha256': 'a' * 64})
    all_records = []
    for group in panel['groups']:
        gid = group['id']
        sub = grid / 'groups' / gid
        sub.mkdir(parents=True)
        rows = [r for r in panel['rows'] if r['group_id'] == gid]
        materials, records = [], []
        for row in rows:
            scenario = row['scenario']
            prompts = {}
            for key, info in row['prompts'].items():
                ids = ([20, 21, 22, 23] if key == 'p_src' and scenario == 'ALT3' else [10, 11, 12, 13])
                prompts[key] = {'input_ids': ids, 'input_ids_sha256': analysis.digest(ids),
                                'attention_mask': [1] * 4, 'offset_mapping': [[i, i + 1] for i in range(4)],
                                'final_equals_index': 3, 'task_positions': list(range(4)),
                                'description_positions': {r: [i] for i, r in enumerate(info['listed_roles'])}}
            materials.append({'id': row['id'], 'row_config_sha256': analysis.digest(row), 'prompts': prompts,
                              'alignment_width': 4, 'donor_positions': list(range(4)), 'destination_positions': list(range(4)),
                              'donor_to_dst': [[i, i] for i in range(4)],
                              'condition_prompt_keys': {k: 'p_dst' for k in ('clean_destination',) + analysis.PRIMARY}})
            cs = {}
            for name in analysis.PRIMARY + analysis.DIAGNOSTICS:
                prompt = prompts['p_src' if name == 'clean_source' else 'p_dst']
                positions = prompts['p_kv']['description_positions'] if name in analysis.PRIMARY else prompt['description_positions']
                filename = (('ALT1' if scenario == 'ALT2' else scenario) + '_source.npz' if name == 'clean_source'
                            else 'clean_destination.npz' if name == 'clean_destination' else scenario + '_' + name + '.npz')
                np.savez(sub / filename, head_ids=np.array(panel['goal_heads']),
                         attention=np.full((2, 4), .25, dtype=np.float32), value_norm=np.ones((2, 4), dtype=np.float32),
                         head_output=np.zeros((2, 2), dtype=np.float32))
                cs[name] = condition({r: .25 for r in positions}, f'groups/{gid}/{filename}', positions, prompt['input_ids'])
                if name in analysis.PRIMARY:
                    cs[name]['set_minus_alternative'] = 0.
            records.append({k: row[k] for k in ('id', 'group_id', 'scenario', 'datatype', 'seed', 'roles', 'predictions')})
            records[-1].update(config_sha256=analysis.digest(row), panel_sha256=panel_sha, conditions=cs,
                               prompt_hashes={k: analysis.digest(p['input_ids']) for k, p in prompts.items()},
                               materialized=f'groups/{gid}/materialized.json', paired_margin_change=0.,
                               recipe_sha256='a' * 64,
                               source_cache_key=(analysis.digest({'ids': prompts['p_src']['input_ids'], 'heads': panel['goal_heads'],
                                                                 'revision': 'synthetic', 'patch': None}) if historical else
                                                 source_cache_key(prompts['p_src']['input_ids'], panel['goal_heads'], 'a' * 64)))
            if historical:
                records[-1].pop('recipe_sha256')
        analysis.dump(sub / 'scores.json', records)
        analysis.dump(sub / 'materialized.json', materials)
        analysis.dump(sub / 'complete.json', {'schema': 'q_transfer_alt_group_v1', 'group_id': gid, 'records': 3, 'group_sha256': analysis.digest(group), 'panel_sha256': panel_sha, 'recipe_sha256': 'a' * 64})
        analysis.dump(sub / 'checks.json', {'group_id': gid, 'cache_reuse': [{'scenario': 'ALT2', 'source_key': records[1]['source_cache_key'],
                                                                          'same_exact_ids': True}]})
        if historical:
            complete = analysis.load(sub / 'complete.json')
            complete.pop('schema')
            analysis.dump(sub / 'complete.json', complete)
        refresh_manifest(sub)
        all_records.extend(records)
    analysis.dump(grid / 'scores.json', all_records)
    return grid, root / 'configs/panel.json'



class AnalysisTests(unittest.TestCase):
    def setUp(self):
        # Deliberately reduced synthetic arrays isolate the raw-data validator.
        # Production's full-panel boundary is independently tested below and in test_panel.
        seam = patch.object(analysis, 'validate_panel', return_value={'synthetic_fixture': True})
        seam.start()
        self.addCleanup(seam.stop)

    def test_exact_ties_and_triplets(self):
        records = small_records()[:3]
        assert analysis.winner_key(['e', 'd']) == '{d|e}'
        assert analysis.triplet_key(records, analysis.PRIMARY[0]) == 'eee'
        assert analysis.triplet_key(records, analysis.PRIMARY[1]) == '{d|e}/e/e'
        # No approximate tie threshold exists in the raw validator or exporter.
        raw = {'head_ids': np.array([[0, 0]]), 'attention': np.ones((1, 4), np.float32) / 4,
               'value_norm': np.ones((1, 4), np.float32), 'head_output': np.zeros((1, 2), np.float32)}
        c = condition(dict(zip('abde', [.25] * 4)))
        c['winners'] = ['e']
        with self.assertRaisesRegex(ValueError, 'winner'):
            analysis.raw_diagnostic(raw, c, [(0, 0)])


    def test_raw_reaggregation_every_mean_and_sum(self):
        a = np.array([[.125, .25, .125, .5], [.25, .125, .125, .5]], dtype=np.float32)
        v = np.array([[2, 4, 2, 1], [4, 2, 2, 1]], dtype=np.float32)
        positions = {'a': [0, 1], 'e': [2, 3]}
        product = a * v
        c = condition({r: float(product[:, ix].mean()) for r, ix in positions.items()}, positions=positions)
        raw = {'attention': a, 'value_norm': v, 'head_ids': np.array([[0, 1], [1, 2]]),
               'head_output': np.ones((2, 3), dtype=np.float32)}
        result = analysis.raw_diagnostic(raw, c, [(0, 1), (1, 2)])
        assert result['max_abs_score_or_sum_error'] == 0
        assert result['float64_sums']['a'] == 1.25
        for field in ('scores', 'sums'):
            broken = deepcopy(c)
            broken[field]['e'] += 2e-6
            with self.assertRaisesRegex(ValueError, 'differs'):
                analysis.raw_diagnostic(raw, broken, [(0, 1), (1, 2)])
        for field, value in [('head_ids', raw['head_ids'][::-1]), ('attention', a[:, :3]),
                             ('value_norm', np.full_like(v, np.nan))]:
            with self.assertRaises(ValueError):
                analysis.raw_diagnostic({**raw, field: value}, c, [(0, 1), (1, 2)])


    def test_exports_preserve_saved_scores_and_metadata(self):
        tmp_path = Path(self.enterContext(TemporaryDirectory()))
        records = small_records()
        primary, diagnostics, configs = analysis.score_exports(records)
        assert len(primary) == 18 * 2 * 4
        assert len(diagnostics) == len(primary)
        assert len(configs) == 18
        first = primary[0]
        assert first['score'] == records[0]['conditions']['kv_only']['scores']['a']
        assert first['task_id'] == 'task.a'
        assert first['map_ref'] == 'map.json'
        assert first['input_ids_sha256'] and first['prompt_hashes'] and first['config_sha256']
        tied = [r for r in primary if r['id'] == records[0]['id'] and r['condition'] == analysis.PRIMARY[1]]
        assert sum(r['winner'] for r in tied) == 2
        assert all(r['tie'] for r in tied)
        analysis.write_csv(tmp_path / 'scores.csv', primary)
        analysis.dump(tmp_path / 'scores.json', primary)
        with (tmp_path / 'scores.csv').open() as f:
            readback = list(csv.DictReader(f))
        assert len(readback) == len(primary)
        assert json.loads(readback[0]['prompt_hashes']) == first['prompt_hashes']
        assert analysis.load(tmp_path / 'scores.json') == primary
        assert 'clean_source_score_a' not in configs[0]


    def test_bootstrap_reuses_whole_group_indices_and_paired_difference(self):
        values = np.array([1., 2., 7.])
        indices = analysis.bootstrap_indices({'str': ['a', 'b', 'c']}, draws=200, seed=82391)['str']
        again = analysis.bootstrap_indices({'str': ['a', 'b', 'c']}, draws=200, seed=82391)['str']
        assert np.array_equal(indices, again)
        expected = np.quantile(values[indices].mean(axis=1), [.025, .975])
        got = analysis.estimate(values, indices)
        np.testing.assert_array_equal([got['ci_low'], got['ci_high']], expected)
        # A constant paired shift has a point interval despite variable marginal means.
        shifted = analysis.estimate((values + .5) - values, indices)
        assert shifted == {'value': .5, 'ci_low': .5, 'ci_high': .5}
        counted = analysis.estimate([True, False, True], indices, count=True)
        assert counted['value'] == 2


    def test_cell_pair_and_triplet_summaries_link_all_scenarios(self):
        records = small_records()
        summary, cells, paired, triplets = analysis.summarize(records, draws=200)
        assert len(cells) == 3 * 3 * 2 * 4  # two datatypes plus stratified pool
        assert len(paired) == 9 and len(triplets) == 6
        a2, a3 = [next(r for r in paired if r['datatype'] == 'int' and r['scenario'] == s)
                  for s in ('ALT2', 'ALT3')]
        assert a2['margin_change_ci_low'] == a3['margin_change_ci_low']
        assert a2['margin_change_ci_high'] == a3['margin_change_ci_high']
        assert a2['margin_change_value'] == .25
        assert summary['bootstrap']['groups_per_datatype'] == {'int': 3, 'str': 3}
        counts = next(x['counts'] for x in summary['triplet_counts']
                      if x['datatype'] == 'int' and x['condition'] == analysis.PRIMARY[1])
        assert counts['eee']['value'] == 2
        assert counts['{d|e}/e/e']['value'] == counts['all_other']['value'] == 1
        assert all(counts[k]['value'] == 0 for k in ('dee', 'efe', 'eeb'))
        transitions = next(r['transitions'] for r in paired if r['datatype'] == 'int' and r['scenario'] == 'ALT1')
        assert transitions['e->{d|e}']['value'] == 1
        pool = next(r for r in paired if r['datatype'] == 'pooled_stratified' and r['scenario'] == 'ALT2')
        assert pool['n'] == 6 and pool['margin_change_value'] == .25
        incomplete = [r for r in records if r['id'] != records[0]['id']]
        with self.assertRaisesRegex(ValueError, 'complete triplets'):
            analysis.summarize(incomplete, draws=5)


    def test_named_triplet_counts_and_full_export_cardinality(self):
        base = small_records()[:3]
        records = []
        patterns = ['eee', 'dee', 'efe', 'eeb']
        for group, pattern in enumerate(patterns):
            triplet = deepcopy(base)
            for i, record in enumerate(triplet):
                record['group_id'] = f'int-{group}'
                record['id'] = record['scenario'] + '/' + record['group_id']
                for name in analysis.PRIMARY:
                    c = record['conditions'][name]
                    c['scores'] = {role: float(role == pattern[i]) for role in c['scores']}
                    c['winners'] = [pattern[i]]
                    c['tie'] = False
                    c['set_minus_alternative'] = c['scores']['e'] - c['scores'][analysis.ALTERNATIVE[record['scenario']]]
            records.extend(triplet)
        summary, _, _, _ = analysis.summarize(records, draws=20)
        for counts in summary['triplet_counts']:
            assert all(counts['counts'][p]['value'] == 1 for p in patterns)
            assert counts['counts']['all_other']['value'] == 0
        full = []
        for datatype in ('int', 'str', 'list[int]', 'list[str]'):
            for group in range(32):
                triplet = deepcopy(base)
                for record in triplet:
                    record['datatype'] = datatype
                    record['group_id'] = f'{datatype}-{group}'
                    record['id'] = record['scenario'] + '/' + record['group_id']
                full.extend(triplet)
        primary, diagnostics, configs = analysis.score_exports(full)
        assert len(configs) == 384 and len(primary) == 3072 and len(diagnostics) == 3072
        assert len({r['group_id'] for r in configs}) == 128



    def test_mean_winner_is_not_sum_winner_and_near_ties_are_not_ties(self):
        raw = {'head_ids': np.array([[0, 0]]), 'attention': np.full((1, 5), .2, np.float32),
               'value_norm': np.array([[1., 2., 2., 1., 1.]], np.float32),
               'head_output': np.zeros((1, 2), np.float32)}
        positions = {'a': [0, 1, 2], 'e': [3], 'b': [4]}
        raw['value_norm'][0, 3] = 2.5
        product = raw['attention'] * raw['value_norm']
        c = condition({r: float(product[:, p].mean()) for r, p in positions.items()},
                      positions=positions, ids=[1, 2, 3, 4, 5])
        result = analysis.raw_diagnostic(raw, c, [(0, 0)])
        self.assertEqual(c['winners'], ['e'])
        self.assertGreater(result['float64_sums']['a'], result['float64_sums']['e'])
        # One FP32 ULP of score difference remains a unique winner.
        raw['value_norm'] = np.ones((1, 5), np.float32)
        raw['value_norm'][0, 3] = np.nextafter(np.float32(1), np.float32(2))
        product = raw['attention'] * raw['value_norm']
        c = condition({r: float(product[:, p].mean()) for r, p in positions.items()},
                      positions=positions, ids=[1, 2, 3, 4, 5])
        analysis.raw_diagnostic(raw, c, [(0, 0)])
        self.assertEqual(c['winners'], ['e'])
        self.assertFalse(c['tie'])

    def test_validate_synthetic_pilot_and_cli(self):
        tmp = Path(self.enterContext(TemporaryDirectory()))
        grid, panel = make_pilot_grid(tmp)
        records, result, raw = analysis.validate_grid(grid, panel, pilot=True)
        self.assertTrue(result['passed'])
        self.assertEqual((result['groups'], result['configurations']), (4, 12))
        self.assertEqual((result['primary_score_rows'], result['unique_raw_files']), (96, 36))
        self.assertEqual(len(raw), 48)
        self.assertEqual(result['max_abs_score_or_sum_error'], 0)
        self.assertEqual(result['provenance'], 'packaged_runtime')
        out = tmp / 'out'
        original = analysis.summarize
        # The CLI default remains the historical 10,000 draws. Task tests use 8 only.
        with patch.object(analysis, 'summarize', side_effect=lambda rows: original(rows, draws=8)):
            analysis.main(['--grid', str(grid), '--panel', str(panel), '--output', str(out), '--pilot'])
        self.assertTrue(analysis.load(out / 'validation.json')['passed'])
        self.assertEqual(len(analysis.load(out / 'task_scores.json')), 96)
        for filename, count in [('configurations.csv', 12), ('cells.csv', 120), ('paired.csv', 15), ('triplets.csv', 4)]:
            with (out / filename).open() as handle:
                self.assertEqual(len(list(csv.DictReader(handle))), count)
        self.assertEqual(analysis.load(out / 'summary.json')['provenance'], 'packaged_runtime')
        self.assertEqual(analysis.DRAWS, 10000)

    def test_historical_requires_frozen_identity_and_explicit_mode(self):
        tmp = Path(self.enterContext(TemporaryDirectory()))
        grid, panel = make_pilot_grid(tmp, historical=True)
        with self.assertRaisesRegex(ValueError, 'exact frozen'):
            analysis.validate_grid(grid, panel, pilot=True, historical=True)
        with self.assertRaisesRegex(ValueError, 'packaged runtime schema'):
            analysis.validate_grid(grid, panel, pilot=True)
        # Test the historical branch with a synthetic identity, not a fabricated
        # claim that these fixture bytes are scientifically historical.
        with patch.object(analysis, 'HISTORICAL_PANEL_SHA256', hashlib.sha256(panel.read_bytes()).hexdigest()):
            _, result, _ = analysis.validate_grid(grid, panel, pilot=True, historical=True)
            self.assertEqual(result['provenance'], 'historical')

    def test_validation_rejects_corruption(self):
        for damage in ('id', 'cached_score', 'recipient', 'source_reuse', 'raw_sum', 'raw_bytes', 'raw_checksum',
                       'incomplete', 'missing_row', 'extra_group', 'mixed_recipe', 'row_recipe',
                       'panel_hash', 'panel_duplicate', 'index', 'manifest_escape', 'symlink_escape'):
            with self.subTest(damage=damage), TemporaryDirectory() as directory:
                grid, panel = make_pilot_grid(Path(directory))
                records = analysis.load(grid / 'scores.json')
                sub = grid / 'groups' / records[0]['group_id']
                if damage == 'id':
                    records[0]['id'] = records[1]['id']
                    analysis.dump(grid / 'scores.json', records)
                elif damage == 'missing_row':
                    analysis.dump(grid / 'scores.json', records[:-1])
                elif damage == 'cached_score':
                    records[0]['conditions']['kv_only']['scores']['e'] += .1
                    analysis.dump(grid / 'scores.json', records)
                elif damage in ('recipient', 'source_reuse'):
                    mats = analysis.load(sub / 'materialized.json')
                    key = 'p_dst' if damage == 'recipient' else 'p_src'
                    mats[1]['prompts'][key]['input_ids'][0] = 999
                    analysis.dump(sub / 'materialized.json', mats)
                    refresh_manifest(sub)
                elif damage in ('raw_sum', 'raw_bytes', 'raw_checksum'):
                    path = grid / records[0]['conditions']['kv_only']['raw']
                    if damage == 'raw_sum':
                        with np.load(path, allow_pickle=False) as raw:
                            arrays = dict(raw)
                        arrays['value_norm'][0, 0] += .01
                        np.savez(path, **arrays)
                    else:
                        path.write_bytes(b'not an NPZ')
                    if damage != 'raw_checksum':
                        refresh_manifest(sub)  # still reject even if manifest is regenerated
                elif damage == 'incomplete':
                    (sub / 'complete.json').unlink()
                elif damage == 'extra_group':
                    (grid / 'groups' / 'extra').mkdir()
                elif damage in ('mixed_recipe', 'manifest_escape'):
                    complete = analysis.load(sub / 'complete.json')
                    if damage == 'mixed_recipe':
                        complete['recipe_sha256'] = 'b' * 64
                    else:
                        complete['file_sha256']['../outside'] = 'b' * 64
                    analysis.dump(sub / 'complete.json', complete)
                elif damage == 'row_recipe':
                    records[0]['recipe_sha256'] = 'b' * 64
                    analysis.dump(grid / 'scores.json', records)
                    analysis.dump(sub / 'scores.json', records[:3])
                    refresh_manifest(sub)
                elif damage in ('panel_hash', 'panel_duplicate', 'index'):
                    payload = analysis.load(panel)
                    if damage == 'panel_hash':
                        payload['provenance'] = 'changed'
                    elif damage == 'panel_duplicate':
                        payload['rows'].append(payload['rows'][0])
                    else:
                        payload['groups'][0]['index'] = 1
                    analysis.dump(panel, payload)
                elif damage == 'symlink_escape':
                    path = sub / 'materialized.json'
                    outside = Path(directory) / 'outside.json'
                    outside.write_bytes(path.read_bytes())
                    path.unlink()
                    path.symlink_to(outside)
                with self.assertRaises((ValueError, FileNotFoundError)):
                    analysis.validate_grid(grid, panel, pilot=True)

    def test_full_grid_rejects_pilot_and_duplicate_triplets(self):
        tmp = Path(self.enterContext(TemporaryDirectory()))
        grid, panel = make_pilot_grid(tmp)
        with self.assertRaisesRegex(ValueError, 'configuration count'):
            analysis.validate_grid(grid, panel)
        rows = small_records()
        duplicate = deepcopy(rows[0])
        duplicate['id'] = 'different-id'
        with self.assertRaisesRegex(ValueError, 'duplicate matched scenario'):
            analysis.summarize(rows + [duplicate], draws=3)

    def test_paths_reject_absolute_parent_and_symlink_escape(self):
        tmp = Path(self.enterContext(TemporaryDirectory()))
        grid = tmp / 'grid'
        grid.mkdir()
        external = tmp / 'external.json'
        external.write_text('{}')
        (grid / 'link.json').symlink_to(external)
        for ref in ('../external.json', str(external), 'link.json'):
            with self.subTest(ref=ref), self.assertRaisesRegex(ValueError, 'escapes grid'):
                analysis._path(grid, ref)

    def test_help_is_stdlib_only(self):
        code = """
import importlib.abc, sys
class BlockHeavy(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] in {'numpy', 'torch', 'transformers', 'pytest'}:
            raise ImportError('blocked ' + fullname)
sys.meta_path.insert(0, BlockHeavy())
from q_transfer_alt.analysis import main
main(['--help'])
"""
        code = 'import sys; sys.path.insert(0, ' + repr(str(_q_transfer_alt_testpath.ROOT / 'src')) + ')\n' + code
        result = subprocess.run([sys.executable, '-S', '-c', code], env=os.environ.copy(),
                                capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 0, result.stderr)
        for flag in ('--panel', '--grid', '--output', '--pilot', '--historical'):
            self.assertIn(flag, result.stdout)

    def test_cli_failure_writes_validation(self):
        tmp = Path(self.enterContext(TemporaryDirectory()))
        grid, panel = make_pilot_grid(tmp)
        output = tmp / 'out'
        with self.assertRaises(ValueError):
            analysis.main(['--grid', str(grid), '--panel', str(panel), '--output', str(output)])
        self.assertFalse(analysis.load(output / 'validation.json')['passed'])


if __name__ == '__main__':
    unittest.main()


class ProductionPanelBoundaryTests(unittest.TestCase):
    def test_reduced_synthetic_panel_rejected_without_test_seam(self):
        with TemporaryDirectory() as tmp:
            panel = Path(tmp) / 'panel.json'
            panel.write_text(json.dumps({'groups': [], 'rows': [], 'goal_heads': [[0, 0]]}))
            with self.assertRaises(ValueError):
                analysis.validate_grid(tmp, panel, pilot=True)
