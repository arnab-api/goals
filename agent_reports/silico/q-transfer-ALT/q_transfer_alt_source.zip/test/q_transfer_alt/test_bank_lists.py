"""Focused stdlib-only checks: python -m unittest discover
-s test/q_transfer_alt -p test_bank_lists.py -v
"""
import _q_transfer_alt_testpath  # supports stdlib unittest discovery from repository root
import ast
from collections import Counter
from copy import deepcopy
import inspect
import itertools
import random
import unittest

import sys
from pathlib import Path

from q_transfer_alt.bank.bank_lists import TASKS
from q_transfer_alt.bank.task import canonical, in_domain, output_matches, typed


def bounded_cases():
    rng = random.Random(20260217)
    integers = [
        [], [0], [1], [-1], [2], [-2], [1000000], [-1000000],
        [0, 0], [1, -1], [-1, 0, 1], [2, 1, 2], [3, -2, 0, 3, -1],
        [1, 2, 3, 4], [4, 3, 2, 1], [5] * 32, [0] * 32,
        [-1000000, 1000000] * 16, list(range(-16, 16)),
    ]
    words = [
        [], [''], ['a'], ['A'], ['ab'], ['', ''], ['a', 'a'],
        ['b', 'a', 'b'], ['ab', 'ba', 'ab', 'AB', ''],
        ['z', 'aa', 'bb', 'a'], ['aa', 'z', 'b', 'cc'],
        ['', 'Ab', '', 'é', ''], ['é', 'e\u0301', 'É', '中', '🙂'],
        ['ß', 'İ', 'Σ', 'ΟΣ', 'ǅ', '²', '٣', '\u00a0', '\t'],
        ['A² ', 'éÉ', '🙂🙂'], ['a'] * 32, [''] * 32,
        ['🙂' * 32] * 32, ['x' * 32, 'y', 'x' * 32],
        ['\0', '\n', ' ', '\ud800', '\U0010ffff'],
    ]
    for length in range(4):
        integers.extend(list(v) for v in itertools.product([-2, 0, 1], repeat=length))
        words.extend(list(v) for v in itertools.product(['', 'a', 'B', 'ab'], repeat=length))
    int_pool = [-1000000, -99, -2, -1, 0, 1, 2, 3, 37, 1000000]
    word_pool = ['', 'a', 'bb', 'ab', 'ba', 'Ab', 'A', 'é', 'É', 'e\u0301',
                 '🙂', '中', 'ß', 'İ', 'ΟΣ', '²', '٣', ' a\t', '\n', 'z' * 32]
    alphabet = 'aBéÉßİΣ中🙂 ²٣\t\u0301'
    for _ in range(160):
        length = rng.randrange(33)
        integers.append([rng.choice(int_pool) for _ in range(length)])
        words.append([rng.choice(word_pool) for _ in range(length)])
    for _ in range(40):
        length = rng.randrange(33)
        integers.append([rng.randint(-1000000, 1000000) for _ in range(length)])
        words.append([''.join(rng.choice(alphabet) for _ in range(rng.randrange(33)))
                      for _ in range(length)])
    return {'list[int]': integers, 'list[str]': words}


CASES = bounded_cases()
BY_ID = {task.id: task for task in TASKS}
PREFERRED = {
    'all_nonempty': 'quantification',
    'lexical_min': 'lexical_extrema',
    'anagram_groups': 'anagram_classes',
    'total_chars': 'length_aggregation',
    'initials': 'positional_transform',
    'equal_adjacent': 'adjacency',
    'uppercase_chars': 'character_classification',
    'distinct_chars': 'character_diversity',
    'palindrome': 'symmetry',
}


class ListBankTests(unittest.TestCase):
    def test_metadata_and_single_rhs_contract(self):
        self.assertEqual(Counter(task.datatype for task in TASKS),
                         {'list[int]': 32, 'list[str]': 32})
        self.assertEqual(len(BY_ID), 64)
        self.assertEqual(len({task.reference.__name__ for task in TASKS}), 64)
        allowed_calls = {'len', 'sum', 'abs', 'min', 'max', 'set', 'all', 'any',
                         'sorted', 'range', 'zip', 'tuple', 'map', 'bool'}
        for task in TASKS:
            with self.subTest(task=task.id):
                prefix = 'list_int' if task.datatype == 'list[int]' else 'list_str'
                self.assertRegex(task.id, rf'^py\.{prefix}\.[a-z_]+\.v1$')
                self.assertTrue(task.description)
                self.assertTrue(task.family)
                self.assertNotIn('\n', task.expression)
                self.assertNotIn(';', task.expression)
                tree = ast.parse('result = ' + task.expression)
                self.assertEqual(len(tree.body), 1)
                self.assertIsInstance(tree.body[0], ast.Assign)
                self.assertFalse(any(isinstance(node, (ast.Lambda, ast.NamedExpr,
                                                       ast.Import, ast.ImportFrom))
                                     for node in ast.walk(tree)))
                for node in ast.walk(tree):
                    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
                        self.assertIn(node.func.id, allowed_calls)
                reference_tree = ast.parse(inspect.getsource(task.reference))
                self.assertIsInstance(reference_tree.body[0], ast.FunctionDef)
                self.assertTrue(any(isinstance(node, (ast.For, ast.While))
                                    for node in ast.walk(reference_tree)))
                self.assertFalse(any(isinstance(node, ast.Call)
                                     and isinstance(node.func, ast.Name)
                                     and node.func.id == task.reference.__name__
                                     for node in ast.walk(reference_tree)))
                # Export metadata remains usable by the parent registry/renderer.
                self.assertEqual(task.record()['assignment'], '{name} = ' + task.expression)

    def test_preferred_families(self):
        families = []
        for role, family in PREFERRED.items():
            task = BY_ID[f'py.list_str.{role}.v1']
            self.assertEqual(task.family, family)
            families.append(task.family)
        self.assertEqual(len(set(families)), 9)
        # Related variants must not invent a fresh family for every expression.
        for roles in [('all_nonempty', 'all_alpha', 'any_empty'),
                      ('lexical_min', 'lexical_max'),
                      ('uppercase_chars', 'digit_chars', 'whitespace_chars'),
                      ('total_chars', 'max_length', 'min_length', 'lengths')]:
            self.assertEqual(len({BY_ID[f'py.list_str.{role}.v1'].family for role in roles}), 1)

    def test_cases_are_bounded_and_diverse(self):
        for datatype, cases in CASES.items():
            self.assertTrue(all(in_domain(datatype, case) for case in cases))
            self.assertIn([], cases)
            self.assertEqual(max(map(len, cases)), 32)
        self.assertTrue(any(-1000000 in case and 1000000 in case for case in CASES['list[int]']))
        self.assertTrue(any('é' in case and 'e\u0301' in case for case in CASES['list[str]']))

    def test_reference_matching_types_and_no_mutation(self):
        for task in TASKS:
            for index, case in enumerate(CASES[task.datatype]):
                with self.subTest(task=task.id, case=index):
                    original = deepcopy(case)
                    actual = task.evaluate(case)
                    self.assertEqual(case, original)
                    expected = task.reference(case)
                    self.assertEqual(case, original)
                    self.assertTrue(output_matches(task.output_type, actual))
                    self.assertTrue(output_matches(task.output_type, expected))
                    self.assertEqual(typed(actual), typed(expected))
                    # Verify the shipped RHS also works as a plain assignment.
                    namespace = {'x': case}
                    exec('result = ' + task.expression, namespace)
                    self.assertEqual(typed(namespace['result']), typed(actual))
                    self.assertEqual(case, original)

    def test_pairwise_typed_functional_signatures(self):
        # This finite-suite distinction is evidence, not a proof of independence.
        for datatype, cases in CASES.items():
            signatures = {}
            tasks = [task for task in TASKS if task.datatype == datatype]
            for task in tasks:
                signatures[task.id] = tuple(canonical(typed(task.evaluate(case))) for case in cases)
            for left, right in itertools.combinations(tasks, 2):
                with self.subTest(left=left.id, right=right.id):
                    self.assertNotEqual(signatures[left.id], signatures[right.id])
        self.assertNotEqual(typed(True), typed(1))
        self.assertNotEqual(typed(False), typed(0))

    def test_preferred_semantic_examples(self):
        examples = {
            'all_nonempty': [([], True), (['', 'a'], False), ([' ', 'é'], True)],
            'lexical_min': [([], ''), (['z', 'A', 'a'], 'A'), (['a', ''], '')],
            'anagram_groups': [([], 0), (['ab', 'ba', 'AB', 'ab', '', ''], 3),
                               (['é', 'e\u0301', '\u0301e'], 2)],
            'total_chars': [([], 0), (['é', 'e\u0301', '🙂'], 4)],
            'initials': [([], ''), (['', 'Ab', '', 'é', '🙂x'], 'Aé🙂')],
            'equal_adjacent': [([], 0), (['a', 'a', 'a', 'b', 'b'], 3), (['', ''], 1)],
            'uppercase_chars': [([], 0), (['AÉΣ', 'ß', 'İ', 'ǅ', '中', '²'], 4)],
            'distinct_chars': [([], 0), (['ab', 'ba', '', 'a'], 2), (['é', 'e\u0301'], 3)],
            'palindrome': [([], True), (['ab', 'ab'], True), (['ab', 'ba'], False),
                           (['A', '', 'A'], True)],
        }
        for role, checks in examples.items():
            task = BY_ID[f'py.list_str.{role}.v1']
            for case, expected in checks:
                with self.subTest(role=role, case=case):
                    self.assertEqual(typed(task.evaluate(case)), typed(expected))
                    self.assertEqual(typed(task.reference(case)), typed(expected))

    def test_ties_zero_signs_and_unicode_expansion(self):
        checks = [
            ('py.list_str.longest_word.v1', ['bb', 'aa', 'z'], 'bb'),
            ('py.list_str.shortest_word.v1', ['bb', 'z', 'a'], 'z'),
            ('py.list_str.lowercase_words.v1', ['İ', 'ΟΣ'], ['i\u0307', 'ος']),
            ('py.list_str.uppercase_words.v1', ['ß'], ['SS']),
            ('py.list_str.digit_chars.v1', ['²٣1', 'Ⅷ'], 3),
            ('py.list_str.whitespace_chars.v1', [' \t\n\u00a0', 'x'], 4),
            ('py.list_int.sign_changes.v1', [-1, 0, 1, -2, 3], 2),
            ('py.list_int.duplicate_count.v1', [2, 2, 2, 1, 1], 3),
            ('py.list_int.prefix_sums.v1', [-1, 2, -3], [-1, 1, -2]),
            ('py.list_int.even_positions.v1', [4, -1, 2, -3, 0], [4, 2, 0]),
        ]
        for task_id, case, expected in checks:
            with self.subTest(task=task_id):
                self.assertEqual(typed(BY_ID[task_id].evaluate(case)), typed(expected))
                self.assertEqual(typed(BY_ID[task_id].reference(case)), typed(expected))


if __name__ == '__main__':
    unittest.main()
