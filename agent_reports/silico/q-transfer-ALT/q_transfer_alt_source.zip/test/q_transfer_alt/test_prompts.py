"""Bounded CPU-only grid contracts; no model, downloads, or bank execution."""
import _q_transfer_alt_testpath  # supports stdlib unittest discovery from repository root
import copy
import hashlib
import json
from pathlib import Path
import re
import unittest

from q_transfer_alt.prompts import _render, materialize, materialize_group
from q_transfer_alt.validate_panel import (OLD16_FILE_SHA256, OLD16_SIGNATURES, OLD16_SOURCE,
                                digest, validate_panel)

ROOT = Path(__file__).resolve().parents[2]


class FakeTokenizer:
    """Reversible stub with leading-space tokens and merged newline runs."""
    pattern = re.compile(r"\n+| [A-Za-z]+|\.\n|.", re.DOTALL)

    def __init__(self):
        self.vocab, self.inverse = {}, {}

    def apply_chat_template(self, messages, **kwargs):
        assert kwargs == dict(add_generation_prompt=False, continue_final_message=True,
                              tokenize=False, chat_template_kwargs={"enable_thinking": False})
        return "".join(f"<{m['role']}>\n{m['content']}" for m in messages)

    def __call__(self, text, add_special_tokens=False, return_offsets_mapping=False):
        assert not add_special_tokens
        ids, offsets = [], []
        for match in self.pattern.finditer(text):
            token = match.group()
            if token not in self.vocab:
                index = len(self.vocab)
                self.vocab[token], self.inverse[index] = index, token
            ids.append(self.vocab[token])
            offsets.append(list(match.span()))
        result = dict(input_ids=ids, attention_mask=[1] * len(ids))
        if return_offsets_mapping:
            result['offset_mapping'] = offsets
        return result

    def decode(self, ids, **kwargs):
        return "".join(self.inverse[i] for i in ids)


def rehash(record, key):
    record[key] = digest({k: v for k, v in record.items() if k != key})


class GridPromptTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = (ROOT / 'configs/q_transfer_alt/panel.original.json').read_bytes()
        cls.panel = json.loads(cls.raw)

    def test_every_group_alignment_exact_ids_and_unchanged_sources(self):
        before = copy.deepcopy(self.panel)
        cross_row_padding = False
        for group in self.panel['groups']:
            rows = [r for r in self.panel['rows'] if r['group_id'] == group['id']]
            tok = FakeTokenizer()
            originals = [{k: _render(r['prompts'][k], tok) for k in ('p_src', 'p_kv', 'p_dst')}
                         for r in rows]
            target = max(len(p[k]['task_positions']) for p in originals for k in ('p_kv', 'p_dst'))
            bundles = materialize_group(reversed(rows), tok)
            self.assertEqual([b['id'] for b in bundles], [r['id'] for r in rows])
            self.assertEqual(json.loads(json.dumps(bundles)), bundles)
            recipients = [b['prompts']['p_dst'] for b in bundles]
            self.assertEqual(recipients[0], recipients[1])
            self.assertEqual(recipients[0], recipients[2])
            for row, original, bundle in zip(rows, originals, bundles):
                with self.subTest(row=row['id']):
                    self.assertEqual(bundle['row_config_sha256'], digest(row))
                    self.assertEqual(bundle['alignment_width'], target)
                    src = dict(bundle['prompts']['p_src'])
                    src.pop('input_ids_sha256')
                    self.assertEqual(src, original['p_src'])
                    self.assertEqual(bundle['donor_to_dst'], [list(pair) for pair in zip(
                        bundle['donor_positions'], bundle['destination_positions'])])
                    self.assertEqual(len(bundle['donor_positions']), target)
                    self.assertEqual(len(bundle['destination_positions']), target)
                    self.assertEqual(set(bundle['condition_prompt_keys'].values()), {'p_dst'})
                    old_target = max(len(original[k]['task_positions']) for k in ('p_kv', 'p_dst'))
                    cross_row_padding |= old_target < target
                    for key, p in bundle['prompts'].items():
                        self.assertEqual(p['input_ids_sha256'], digest(p['input_ids']))
                        self.assertEqual(tok.decode(p['input_ids']), p['rendered'])
                        self.assertEqual(len(p['input_ids']), len(p['offset_mapping']))
                        self.assertEqual(p['attention_mask'], [1] * len(p['input_ids']))
                        self.assertEqual(p['final_equals_index'], len(p['input_ids']) - 1)
                        self.assertEqual(tok.decode(p['input_ids'][-1:]), '=')
                        self.assertEqual(p['task_positions'], list(range(*p['task_span'])))
                        padding = set(p['padding_positions'])
                        self.assertEqual([v for i, v in enumerate(p['input_ids']) if i not in padding],
                                         original[key]['input_ids'])
                        for desc in row['prompts'][key]['description_spans']:
                            role = desc['role']
                            start, end = p['description_spans'][role]
                            self.assertEqual(p['rendered'][start:end], desc['text'])
                            self.assertTrue(padding.isdisjoint(p['description_positions'][role]))
                            for i in p['description_positions'][role]:
                                a, b = p['offset_mapping'][i]
                                self.assertLess(a, end)
                                self.assertGreater(b, start)
                                self.assertEqual(tok.decode(p['input_ids'][i:i + 1]), p['rendered'][a:b])
        self.assertTrue(cross_row_padding, 'must catch independent per-row padding regression')
        self.assertEqual(self.panel, before)
        self.assertEqual((ROOT / 'configs/q_transfer_alt/panel.original.json').read_bytes(), self.raw)

    def test_frozen_alignment_token_fixtures(self):
        # These hashes cover every JSON field, including the exact input IDs,
        # offsets, spans, padding, source preservation, and donor/destination map.
        # They describe the reversible stub above, not a real model tokenizer.
        fixtures = {
            'int': (65, '8646e7d6d583d364c44b132df52b30cddfdcb1528b489ad021b99ec6fe3212eb'),
            'str': (99, 'edc9a75c53a3bc62a2bc267e1d8ef5c9430472d543b120ce4f5f80592058d24b'),
            'list[int]': (57, 'c9cd3578b112b151c1882b172aafeb02ac67e8cbdb556bde6b9579cdf7aacb30'),
            'list[str]': (46, '95a41034cf1433314c69573d516fceaa55ab42bc6bf7b0a042cf304c288761aa'),
        }
        for datatype, (width, expected_hash) in fixtures.items():
            rows = [r for r in self.panel['rows'] if r['group_id'] == f'{datatype}-group-00']
            with self.subTest(datatype=datatype):
                bundles = materialize_group(rows, FakeTokenizer())
                self.assertEqual(bundles[0]['alignment_width'], width)
                self.assertEqual(digest(bundles), expected_hash)

    def test_padding_does_not_retokenize(self):
        tok = FakeTokenizer()
        bundles = materialize_group(self.panel['rows'][:3], tok)
        padded = next(p for b in bundles for p in b['prompts'].values() if len(p['padding_positions']) > 1)
        self.assertNotEqual(tok(padded['rendered'])['input_ids'], padded['input_ids'])
        self.assertTrue(all(padded['input_ids'][i] == tok('\n')['input_ids'][0]
                            for i in padded['padding_positions']))
        fringe = bundles[0]['prompts']['p_dst']['description_whitespace_fringe']['a']
        self.assertTrue(any(f['before'] == ' ' for f in fringe))
        self.assertTrue(any(f['after'] == '\n' for f in fringe))

    def test_single_row_api_compatible(self):
        tok = FakeTokenizer()
        row = self.panel['rows'][0]
        bundle = materialize(row, tok)
        self.assertEqual(bundle['row_config_sha256'], digest(row))
        self.assertEqual(bundle['prompts']['p_src']['padding_positions'], [])
        self.assertEqual(len(bundle['donor_positions']), len(bundle['destination_positions']))

    def test_bad_groups_rejected(self):
        for case in ('missing', 'duplicate', 'group_id', 'recipient', 'roles', 'opaque_names'):
            rows = copy.deepcopy(self.panel['rows'][:3])
            if case == 'missing':
                rows.pop()
            elif case == 'duplicate':
                rows[2] = rows[0]
            elif case == 'group_id':
                rows[1]['group_id'] = 'different'
            elif case == 'recipient':
                rows[1]['prompts']['p_dst']['text'] += ' '
            else:
                rows[1][case]['a'] = 'different'
            with self.subTest(case=case), self.assertRaises(ValueError):
                materialize_group(rows, FakeTokenizer())

    def test_invalid_tokenizer_contract_rejected(self):
        class SplitNewline(FakeTokenizer):
            def __call__(self, text, **kwargs):
                result = super().__call__(text, **kwargs)
                if text == '\n':
                    result['input_ids'] *= 2
                return result
        with self.assertRaisesRegex(ValueError, 'standalone newline'):
            materialize_group(self.panel['rows'][:3], SplitNewline())
        tok = FakeTokenizer()
        tok.pattern = re.compile(r'\(1\) Signed|\n+| [A-Za-z]+|\.\n|.', re.DOTALL)
        with self.assertRaisesRegex(ValueError, 'non-whitespace boundary'):
            materialize_group(self.panel['rows'][:3], tok)

    def test_frozen_panel_validation_and_goal_file(self):
        result = validate_panel(self.panel)
        self.assertTrue(result['valid'])
        self.assertEqual((result['row_count'], result['group_count']), (384, 128))
        self.assertEqual(len(result['counts']), 12)
        self.assertEqual(set(result['counts'].values()), {32})
        self.assertEqual(len(result['row_config_sha256']), 384)
        self.assertEqual(result['exclusion']['prior_assignment_count'], 16)
        self.assertEqual(result['exclusion']['checked_alt1_assignment_count'], 128)
        self.assertEqual(result['exclusion']['overlap_count'], 0)
        heads = (ROOT / 'configs/q_transfer_alt/goal250.json').read_bytes()
        self.assertEqual(json.loads(heads), self.panel['goal_heads'])
        self.assertEqual(hashlib.sha256(heads).hexdigest(), self.panel['goal_heads_sha256'])

    def test_content_and_nested_hash_tampering_rejected(self):
        p = copy.deepcopy(self.panel)
        p['rows'][0]['seed'] += 1
        with self.assertRaisesRegex(ValueError, 'content_sha256 mismatch'):
            validate_panel(p)
        p = copy.deepcopy(self.panel)
        p['rows'][0]['prompts']['p_src']['text'] += ' '
        rehash(p, 'content_sha256')
        with self.assertRaisesRegex(ValueError, 'components_sha256 mismatch'):
            validate_panel(p)

    def test_rehashed_semantic_corruptions_rejected(self):
        cases = ('row_id', 'group_id', 'duplicate_task', 'family_metadata', 'opaque_name',
                 'row_role', 'scenario_layout', 'row_layout', 'prediction', 'description',
                 'assignment', 'recipient', 'missing_row', 'missing_group', 'duplicate_head')
        for case in cases:
            p = copy.deepcopy(self.panel)
            row, group = p['rows'][0], p['groups'][0]
            prompt = row['prompts']['p_kv']
            if case == 'row_id': row['id'] = 'bogus'
            elif case == 'group_id': row['group_id'] = 'bogus'
            elif case == 'duplicate_task': group['roles']['f'] = group['roles']['a']
            elif case == 'family_metadata': group['family_by_role']['b'] = 'bogus'
            elif case == 'opaque_name': row['opaque_names']['b'] = 'v'
            elif case == 'row_role': row['roles']['b'] = row['roles']['c']
            elif case == 'scenario_layout':
                p['scenarios']['ALT1']['layouts']['p_kv']['listed_roles'] = list('acbe')
                rehash(p['scenarios']['ALT1'], 'definition_sha256')
            elif case == 'row_layout': prompt['listed_roles'] = list('acbe')
            elif case == 'prediction': row['predictions']['order_id'] = 'b'
            elif case == 'description': prompt['description_spans'][0]['task_id'] = 'bogus'
            elif case == 'assignment': prompt['supplied_assignments'][0]['variable'] = 'v'
            elif case == 'recipient': row['prompts']['p_dst']['frontier_task_id'] = 'bogus'
            elif case == 'missing_row': p['rows'].pop()
            elif case == 'missing_group': p['groups'].pop()
            elif case == 'duplicate_head': p['goal_heads'][1] = p['goal_heads'][0]
            rehash(prompt, 'components_sha256')
            rehash(row['prompts']['p_dst'], 'components_sha256')
            rehash(p, 'content_sha256')
            with self.subTest(case=case), self.assertRaises(ValueError):
                validate_panel(p)

    def test_exclusion_rejects_overlap(self):
        # Substituting a packaged signature isolates this last check from all
        # earlier semantic checks; an actual old map has only eight roles.
        from unittest.mock import patch
        row = self.panel['rows'][0]
        with patch('q_transfer_alt.validate_panel.OLD16_SIGNATURES', [(row['datatype'], digest(row['roles']))]):
            with self.assertRaisesRegex(ValueError, 'prior smoke ALT1 assignment reused'):
                validate_panel(self.panel)


if __name__ == '__main__':
    unittest.main()
