"""Projection capture, query audits, and raw attention/value persistence."""
import contextlib
import numpy as np
import torch
from .interventions import query_patch
from .provenance import dump

@contextlib.contextmanager
def projections(model, specs):
    stores={tag:{} for tag in specs}; handles=[]
    try:
        for tag,(which,layers,positions) in specs.items():
            for layer in layers:
                def hook(m,args,out,tag=tag,layer=layer,positions=positions):
                    stores[tag][layer]=out[0,positions].detach().float().cpu().clone()
                handles.append(getattr(model.model.layers[layer].self_attn,which+'_proj').register_forward_hook(hook))
        yield stores
    finally:
        for h in handles:h.remove()

@contextlib.contextmanager
def audited_query(model,q,heads):
    bylayer={}; handles=[]; before={}; audit={}
    for l,h in heads:bylayer.setdefault(l,[]).append(h)
    try:
        for l in bylayer:
            def pre(m,args,out,l=l):before[l]=out
            handles.append(model.model.layers[l].self_attn.q_proj.register_forward_hook(pre))
        with query_patch(model,q,heads,positions=(-1,)):
            for l,hs in bylayer.items():
                hd=model.model.layers[l].self_attn.head_dim
                def post(m,args,out,l=l,hs=hs,hd=hd):
                    b=before.pop(l); expected=b.clone()
                    source=q[l].to(out.device,out.dtype)
                    for h in hs:expected[:,-1,h*hd:(h+1)*hd]=source[:,h*hd:(h+1)*hd]
                    error=float((expected-out).abs().max())
                    delta=float((out.float()-b.float()).norm())
                    assert error==0
                    audit[l]={'all_raw_q_replacement_max_abs':error,'raw_q_edit_l2':delta,'edited_position':out.shape[1]-1,'heads':hs}
                handles.append(model.model.layers[l].self_attn.q_proj.register_forward_hook(post))
            yield audit
    finally:
        for h in handles:h.remove()

def rotation_audit(model,state,k):
    result={}
    for l,byhead in state['src_k'].items():
        a=model.model.layers[l].self_attn; hd=a.head_dim; pos=torch.tensor([state['span']],device=a.q_proj.weight.device)
        cos,sin=model.model.rotary_emb(a.q_proj.weight.new_zeros(1,len(state['span']),hd),pos)
        errors=[]
        for h,val in byhead.items():
            raw=k[l][:,h*hd:(h+1)*hd].to(val.device,val.dtype)
            rotated_half=torch.cat((-raw[:,hd//2:],raw[:,:hd//2]),-1)
            expected=raw*cos[0]+rotated_half*sin[0]
            errors.append(float((val-expected).abs().max()))
        result[l]=max(errors)
    assert max(result.values())==0
    return result

def arrays(gaze,path):
    p=gaze.packed()
    np.savez_compressed(path,head_ids=np.asarray(p['head_ids']),**{k:p[k].numpy() for k in ['attention','value_norm','head_output']})
    return p

def scores(p,positions):
    product=p['attention'].float()*p['value_norm'].float()
    return {role:float(product[:,idx].mean()) for role,idx in positions.items()}

def winner(s):
    m=max(s.values());return [r for r,x in s.items() if x==m]
