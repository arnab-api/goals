"""Portable frozen alternate-hypothesis grid; full-prefill forwards, no decoding.

Import, --help and --dry-run use only the standard library. Real execution is
restricted to the historical Python 3.11 / Transformers 5.18.0 GPU runtime.
"""
import argparse
import contextlib
import importlib.metadata
import json
import pathlib
import platform
import time

from . import CONFIG_DIR
from .loader import load_panel
from .validate_panel import validate_panel
from .provenance import (PINNED_REVISION, dump, file_sha, sha, recipe_hash,
                         verify_model_manifest, verify_resume, prepare_resume, source_cache_key)

ALT_ROLE = {'ALT1': 'd', 'ALT2': 'f', 'ALT3': 'b'}
SETTINGS = {'seed': 0, 'batch_size': 1, 'dtype': 'bfloat16', 'attention': 'eager',
            'alpha': 1, 'ov_boost': False, 'generated_tokens': 0,
            'q_position': 'final equals only; pre-RoPE', 'use_cache': False}


def runtime_versions():
    """Enforce supported numerical stack and bind actual dependencies to resume."""
    if platform.python_version_tuple()[:2] != ('3', '11'):
        raise RuntimeError('Full-model runtime requires historical Python 3.11')
    versions = {name: importlib.metadata.version(name) for name in
                ('torch', 'transformers', 'numpy', 'tokenizers', 'huggingface-hub', 'safetensors')}
    for name, expected in {'torch': '2.11.0+cu128', 'transformers': '5.18.0', 'numpy': '2.4.6'}.items():
        if versions[name] != expected:
            raise RuntimeError(f'Full-model runtime requires {name}=={expected}; found {versions[name]}')
    return {'python': platform.python_version(), 'versions': versions}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--panel', type=pathlib.Path, required=True)
    ap.add_argument('--model-path', type=pathlib.Path)
    ap.add_argument('--model-manifest', type=pathlib.Path)
    ap.add_argument('--output', type=pathlib.Path, required=True)
    ap.add_argument('--resume', type=pathlib.Path)
    ap.add_argument('--pilot', action='store_true')
    ap.add_argument('--dry-run', action='store_true')
    args = ap.parse_args(argv)
    panel = load_panel(args.panel)
    validation = validate_panel(panel)
    heads = [tuple(h) for h in panel['goal_heads']]
    reference_heads = json.loads((CONFIG_DIR / 'goal250.json').read_text())
    if heads != [tuple(h) for h in reference_heads] or len(heads) != 250:
        raise ValueError('Runtime requires the exact ordered 250 goal heads')
    if len(panel['rows']) != 384 or len(panel['groups']) != 128:
        raise ValueError('Runtime requires the validated 384-row, 128-group grid')
    selected = [g for g in panel['groups'] if not args.pilot or g['index'] == 0]
    grouped = {g['id']: [r for r in panel['rows'] if r['group_id'] == g['id']]
               for g in panel['groups']}
    panel_sha = file_sha(args.panel)
    if args.dry_run:
        dump(args.output / 'dry_run.json', {
            'schema': 'q_transfer_alt_dry_run_v1', 'groups': len(selected),
            'rows': sum(len(grouped[g['id']]) for g in selected),
            'primary_conditions': 2 * sum(len(grouped[g['id']]) for g in selected),
            'heads': len(heads), 'settings': SETTINGS, 'panel_sha256': panel_sha,
            'validated_panel_rows': len(panel['rows']), 'pilot': args.pilot,
            'tokenization_performed': False, 'inference_performed': False,
            'note': 'Schema validation only; no tokenization, model loading or inference.',
            'panel_validation': validation})
        return 0
    if args.model_path is None or args.model_manifest is None:
        ap.error('inference requires --model-path and --model-manifest')
    fingerprint = runtime_versions()
    identity = verify_model_manifest(args.model_path, args.model_manifest)
    options = dict(SETTINGS, pilot=args.pilot, runtime=fingerprint)
    recipe = recipe_hash(args.panel, heads, identity, options)
    # No model or tokenizer loading, and no artifact copying, precedes resume validation.
    prepare_resume(args.output, args.resume, selected, grouped, recipe, panel_sha)
    return _execute(args, panel, validation, heads, selected, grouped, panel_sha, identity, recipe)


def _execute(args, panel, validation, heads, selected, grouped, panel_sha, identity, recipe):
    import torch
    with torch.inference_mode():
        return _run(args, panel, validation, heads, selected, grouped, panel_sha, identity, recipe)


def _run(args, panel, validation, heads, selected, grouped, panel_sha, identity, recipe):
    import numpy as np
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer
    from .interventions import query_patch, kv_patch
    from .observe import Gaze, native_gaze
    from .prompts import materialize_group
    from .runtime_helpers import projections, audited_query, rotation_audit, arrays
    torch.set_num_threads(1)
    torch.manual_seed(0)
    np.random.seed(0)
    torch.set_float32_matmul_precision('highest')
    if torch.cuda.device_count() != 1:
        raise RuntimeError('Runtime requires exactly one visible CUDA device')
    out = args.output
    out.mkdir(parents=True, exist_ok=True)
    dump(out / 'panel_validation.json', validation)
    mp = args.model_path
    start = time.monotonic()
    dump(out / 'model_provenance.json', identity)
    tok = AutoTokenizer.from_pretrained(mp, local_files_only=True, trust_remote_code=False)
    env = dict(SETTINGS, python=platform.python_version(),
        versions={k: importlib.metadata.version(k) for k in ['torch', 'transformers', 'numpy']},
        cuda=torch.version.cuda, gpu=torch.cuda.get_device_name(0), count=torch.cuda.device_count(),
        model_path=str(mp), model_identity=identity, revision=PINNED_REVISION,
        panel_sha256=panel_sha, recipe_sha256=recipe,
        heads_sha256=file_sha(CONFIG_DIR / 'goal250.json'), pilot=args.pilot,
        selected_groups=len(selected), model_config=json.loads((mp / 'config.json').read_text()))
    dump(out / 'environment.json', env)
    print('STARTUP', json.dumps(env), flush=True)
    model = AutoModelForCausalLM.from_pretrained(mp, local_files_only=True, trust_remote_code=False,
        dtype=torch.bfloat16, attn_implementation='eager').to('cuda').eval()
    assert model.dtype == torch.bfloat16 and len(model.model.layers) == 64
    assert model.config.num_attention_heads == 40 and model.config.num_key_value_heads == 8
    assert not getattr(model.config, 'quantization_config', None)
    assert all(p.device.type == 'cuda' for p in model.parameters())
    loaded = time.monotonic()
    print('MODEL_LOADED seconds', loaded - start, flush=True)
    layers=sorted({l for l,h in heads});native=[b.self_attn.forward for b in model.model.layers];forward_count=0
    def forward(p):
        nonlocal forward_count
        ids=torch.tensor([p['input_ids']],device='cuda');mask=torch.ones_like(ids)
        z=model(input_ids=ids,attention_mask=mask,use_cache=False,logits_to_keep=1).logits[0,-1].float().cpu()
        forward_count+=1;return z
    records=[];completed=0
    for group in selected:
        gid=group['id'];sub=out/'groups'/gid;sub.mkdir(parents=True,exist_ok=True)
        rows=sorted(grouped[gid],key=lambda r:r['scenario'])
        if (sub/'complete.json').exists():
            records.extend(verify_resume(sub,group,rows,recipe,panel_sha));completed+=1;continue
        t=time.monotonic();f0=forward_count;torch.cuda.reset_peak_memory_stats()
        mats=materialize_group(rows,tok);assert len(mats)==3
        dump(sub/'materialized.json',mats)
        dst=mats[0]['prompts']['p_dst']; assert all(m['prompts']['p_dst']['input_ids']==dst['input_ids'] for m in mats)
        assert all(m['destination_positions']==mats[0]['destination_positions'] for m in mats), 'Shared self-control requires identical recipient span'
        dsthash=sha(dst['input_ids']);source_cache={};check={'group_id':gid,'sources':{},'rows':{},'cache_reuse':[]}
        # The first group in each datatype rechecks full-model parity and self-transfer for every contrast.
        controls=group['index']==0
        self_specs={'k':('k',layers,mats[0]['destination_positions']),'v':('v',layers,mats[0]['destination_positions']),'q':('q',layers,[-1])} if controls else {}
        gaze=Gaze(heads)
        with projections(model,self_specs) as self_kv,native_gaze(model,gaze): clean_logits=forward(dst)
        gaze.validate();p=arrays(gaze,sub/'clean_destination.npz')
        clean_record=summarize(p,dst['description_positions'],f'groups/{gid}/clean_destination.npz',dsthash)
        check['clean_destination']=gaze.checks
        check['shared_destination_control_scenarios']=['ALT1','ALT2','ALT3']
        check['identical_recipient_ids_and_destination_spans']=True
        if controls:
            plain=forward(dst);check['native_capture_logit_max_abs']=float((plain-clean_logits).abs().max())
            with kv_patch(model,heads,self_kv['k'],self_kv['v'],mats[0]['destination_positions']),query_patch(model,self_kv['q'],heads,positions=(-1,)):
                noop=forward(dst)
            check['self_transfer_logit_max_abs']=float((noop-clean_logits).abs().max())
            assert check['native_capture_logit_max_abs']==check['self_transfer_logit_max_abs']==0
        group_records=[]
        for row,mat in zip(rows,mats):
            ps=mat['prompts'];alt=row['scenario'];qkey=source_cache_key(ps['p_src']['input_ids'],heads,recipe)
            if qkey not in source_cache:
                gaze=Gaze(heads)
                with projections(model,{'q':('q',layers,[-1])}) as stores,native_gaze(model,gaze):forward(ps['p_src'])
                gaze.validate();p=arrays(gaze,sub/f'{alt}_source.npz')
                src=summarize(p,ps['p_src']['description_positions'],f'groups/{gid}/{alt}_source.npz',sha(ps['p_src']['input_ids']))
                source_cache[qkey]=(stores['q'],src);check['sources'][qkey]=gaze.checks
            else:check['cache_reuse'].append({'scenario':alt,'source_key':qkey,'same_exact_ids':True})
            q,source_record=source_cache[qkey]
            with projections(model,{'k':('k',layers,mat['donor_positions']),'v':('v',layers,mat['donor_positions'])}) as kv:forward(ps['p_kv'])
            mapping=dict(mat['donor_to_dst'])
            transferred={r:[mapping[j] for j in ix] for r,ix in ps['p_kv']['description_positions'].items()}
            record={k:row[k] for k in ['id','group_id','scenario','datatype','seed','roles','predictions']}
            record.update(config_sha256=sha(row),panel_sha256=panel_sha,recipe_sha256=recipe,source_cache_key=qkey,
                prompt_hashes={k:sha(p['input_ids']) for k,p in ps.items()},materialized=f'groups/{gid}/materialized.json',
                conditions={'clean_source':source_record,'clean_destination':clean_record})
            rc={};logits={}
            for name,use_q in [('kv_only',False),('kv_plus_source_q',True)]:
                gaze=Gaze(heads)
                with kv_patch(model,heads,kv['k'],kv['v'],mat['destination_positions'],observer=gaze.transferred) as state:
                    if name=='kv_only':rc['rotation_max_abs_by_layer']=rotation_audit(model,state,kv['k'])
                    with audited_query(model,q,heads) if use_q else contextlib.nullcontext() as qa: z=forward(dst)
                    rc[name+'_forward_calls']=state['forward_calls'];rc[name+'_kv_integrity']=state['kv_checks']
                    assert set(state['forward_calls'])==set(layers) and all(n==1 for n in state['forward_calls'].values())
                if use_q:rc['query_patch']=qa
                gaze.validate();p=arrays(gaze,sub/f'{alt}_{name}.npz')
                rec=summarize(p,transferred,f'groups/{gid}/{alt}_{name}.npz',dsthash)
                rec['set_minus_alternative']=rec['scores']['e']-rec['scores'][ALT_ROLE[alt]]
                record['conditions'][name]=rec;rc[name+'_gaze']=gaze.checks;logits[name]=z
            rc['query_logit_delta_max_abs']=float((logits['kv_plus_source_q']-logits['kv_only']).abs().max())
            if controls:
                with kv_patch(model,heads,kv['k'],kv['v'],mat['destination_positions']),query_patch(model,q,heads,positions=(-1,)): plain=forward(dst)
                rc['kv_capture_logit_max_abs']=float((plain-logits['kv_plus_source_q']).abs().max());assert rc['kv_capture_logit_max_abs']==0
                np.savez_compressed(sub/f'{alt}_logit_controls.npz',clean=clean_logits.numpy(),kv_only=logits['kv_only'].numpy(),kv_plus_query=logits['kv_plus_source_q'].numpy(),capture_off=plain.numpy())
            record['paired_margin_change']=record['conditions']['kv_plus_source_q']['set_minus_alternative']-record['conditions']['kv_only']['set_minus_alternative']
            group_records.append(record);check['rows'][alt]=rc
        assert len(source_cache)==2 and len(check['cache_reuse'])==1 and check['cache_reuse'][0]['scenario']=='ALT2'
        assert [b.self_attn.forward for b in model.model.layers]==native
        torch.cuda.synchronize();stats={'schema':'q_transfer_alt_group_v1','group_id':gid,'panel_sha256':panel_sha,'group_sha256':sha(group),'seconds':time.monotonic()-t,
            'forwards':forward_count-f0,'peak_gpu_allocated_bytes':torch.cuda.max_memory_allocated(),'peak_gpu_reserved_bytes':torch.cuda.max_memory_reserved(),'records':3}
        dump(sub/'scores.json',group_records);dump(sub/'checks.json',check)
        stats['recipe_sha256']=recipe
        stats['file_sha256']={p.name:file_sha(p) for p in sorted(sub.iterdir()) if p.is_file() and p.name!='complete.json'}
        dump(sub/'complete.json',stats)
        records.extend(group_records);completed+=1
        print('GROUP',completed,'/',len(selected),json.dumps(stats),'WINNERS',[(r['scenario'],r['conditions']['kv_only']['winners'],r['conditions']['kv_plus_source_q']['winners']) for r in group_records],flush=True)
    dump(out/'scores.json',records)
    dump(out/'run_summary.json',{'completed_groups':completed,'completed_configurations':len(records),'primary_observations':2*len(records),
         'forwards_this_job':forward_count,'generated_tokens':0,'load_seconds':loaded-start,'run_seconds':time.monotonic()-loaded,
         'load_and_run_seconds':time.monotonic()-start,'pilot':args.pilot,'all_checks_passed':True,
         'peak_gpu_allocated_bytes':torch.cuda.max_memory_allocated(),'peak_gpu_reserved_bytes':torch.cuda.max_memory_reserved()})
    print('FINISHED',len(records),'configurations',flush=True)


def summarize(p,positions,raw,prompt_hash):
    from .runtime_helpers import winner
    product=p['attention'].float()*p['value_norm'].float()
    s={r:float(product[:,ix].mean()) for r,ix in positions.items()}
    return {'scores':s,'sums':{r:float(product[:,ix].mean(0).sum()) for r,ix in positions.items()},
            'description_token_counts':{r:len(ix) for r,ix in positions.items()},
            'winners':winner(s),'tie':len(winner(s))>1,'raw':str(raw),'input_ids_sha256':prompt_hash,
            'description_positions':positions,'token_count':p['attention'].shape[1]}


if __name__ == '__main__':
    main()
