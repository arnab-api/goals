"""CPU-only validation and matched-group analysis of run_grid.py artifacts.

Saved torch FP32 scores are authoritative. Float64 raw reaggregation is an
independent diagnostic, never a replacement score or an eligibility filter.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import json
from pathlib import Path

from .validate_panel import validate_panel

# Only the exact frozen E8 bytes identify historical provenance.
HISTORICAL_PANEL_SHA256 = 'c8fdfc60501fcfe5b020684798d81ebe19c0dd6333e0194be586a458dcb6808d'
PRIMARY = ('kv_only', 'kv_plus_source_q')
DIAGNOSTICS = ('clean_source', 'clean_destination')
SCENARIOS = ('ALT1', 'ALT2', 'ALT3')
ALTERNATIVE = {'ALT1': 'd', 'ALT2': 'f', 'ALT3': 'b'}
SEED = 82391
DRAWS = 10000
TOLERANCE = 1e-6


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def load(path):
    return json.loads(Path(path).read_text())


def dump(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def write_csv(path, rows):
    rows = list(rows)
    fields = list(dict.fromkeys(k for row in rows for k in row))
    with Path(path).open('w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, sort_keys=True, separators=(',', ':'))
                             if isinstance(v, (dict, list, tuple)) else v
                             for k, v in row.items()})


def winner_key(winners):
    """Tie labels are sets, not arbitrarily selected winners."""
    winners = sorted(winners)
    return winners[0] if len(winners) == 1 else '{' + '|'.join(winners) + '}'


def triplet_key(records, condition):
    by_scenario = {r['scenario']: r for r in records}
    labels = [winner_key(by_scenario[s]['conditions'][condition]['winners']) for s in SCENARIOS]
    return ''.join(labels) if all(len(x) == 1 for x in labels) else '/'.join(labels)


def raw_diagnostic(raw, condition, heads):
    """Check every full final-query causal row, then every saved role mean/sum."""
    import numpy as np

    attention, norm, output = (raw[k] for k in ('attention', 'value_norm', 'head_output'))
    require(np.array_equal(raw['head_ids'], np.asarray(heads)), 'raw head identity/order mismatch')
    require(attention.dtype == norm.dtype == output.dtype == np.float32, 'raw arrays must be FP32')
    shape = (len(heads), condition['token_count'])
    require(attention.shape == norm.shape == shape, 'raw full causal token/head shape mismatch')
    require(output.ndim == 2 and output.shape[0] == len(heads) and output.shape[1] > 0,
            'raw head output shape mismatch')
    require(all(np.isfinite(x).all() for x in (attention, norm, output)), 'nonfinite raw array')
    require((attention >= 0).all() and (norm >= 0).all(), 'negative attention or value norm')
    row_error = float(np.max(np.abs(attention.astype(np.float64).sum(axis=1) - 1)))
    require(row_error <= .005, 'raw attention does not cover normalized causal rows')
    product = attention.astype(np.float64) * norm.astype(np.float64)
    means, sums, max_error = {}, {}, 0.0
    roles = set(condition['description_positions'])
    require(roles == set(condition['scores']) == set(condition['sums']) ==
            set(condition['description_token_counts']), 'role fields disagree')
    used = []
    for role, positions in condition['description_positions'].items():
        require(positions and all(isinstance(i, int) and 0 <= i < shape[1] for i in positions),
                'description token out of causal range')
        require(len(set(positions)) == len(positions), 'duplicate description token')
        require(len(positions) == condition['description_token_counts'][role], 'description count mismatch')
        used.extend(positions)
        means[role] = float(product[:, positions].mean())
        sums[role] = float(product[:, positions].mean(axis=0).sum())
        for field, actual in (('scores', means[role]), ('sums', sums[role])):
            saved = condition[field][role]
            require(np.isfinite(saved), 'nonfinite saved score/sum')
            error = abs(actual - saved)
            max_error = max(max_error, error)
            require(error <= TOLERANCE, f'raw {field}/{role} differs by {error}, limit {TOLERANCE}')
    require(len(used) == len(set(used)), 'overlapping role descriptions')
    scores = condition['scores']
    winners = [r for r, value in scores.items() if value == max(scores.values())]
    require(set(condition['winners']) == set(winners) and len(condition['winners']) == len(winners),
            'saved winner disagrees with exact FP32 score tie')
    require(condition['tie'] == (len(winners) > 1), 'saved tie flag mismatch')
    return {'float64_means': means, 'float64_sums': sums,
            'max_abs_score_or_sum_error': max_error, 'max_attention_row_sum_error': row_error}


def _path(grid, ref):
    grid = Path(grid)
    ref = Path(ref)
    require(not ref.is_absolute() and '..' not in ref.parts, 'artifact reference escapes grid')
    path = (grid / ref).resolve()
    require(path.is_relative_to(grid.resolve()), 'artifact reference escapes grid')
    require(path.is_file(), f'missing artifact {ref}')
    return path


def validate_grid(grid, panel, pilot=False, *, historical=False):
    """Validate a grid against an explicit panel file, never an inferred ROOT.

    Fresh provenance is checked for internal consistency, not asserted to match
    the locally installed runtime recipe. Runtime resume owns that comparison.
    Historical input is opt-in and requires the exact frozen panel checksum.
    """
    import numpy as np

    grid = Path(grid).resolve()
    panel_bytes = Path(panel).read_bytes()
    panel_hash = hashlib.sha256(panel_bytes).hexdigest()
    panel = json.loads(panel_bytes)
    validate_panel(panel)  # Enforce the complete fixed protocol before reading raw outputs.
    if historical:
        require(panel_hash == HISTORICAL_PANEL_SHA256,
                'historical mode requires the exact frozen historical panel checksum')
    records = load(_path(grid, 'scores.json'))
    require(len({g['id'] for g in panel['groups']}) == len(panel['groups']), 'duplicate panel groups')
    require(len({r['id'] for r in panel['rows']}) == len(panel['rows']), 'duplicate panel rows')
    all_groups = {g['id']: g for g in panel['groups']}
    require(all(r['group_id'] in all_groups for r in panel['rows']), 'unknown panel group')
    selected = [g for g in panel['groups'] if not pilot or g['index'] == 0]
    groups = {g['id']: g for g in selected}
    require(all(isinstance(gid, str) and gid not in ('', '.', '..') and
                Path(gid).name == gid for gid in groups), 'unsafe group ID')
    expected = {r['id']: r for r in panel['rows'] if r['group_id'] in groups}
    for gid, group in groups.items():
        rows = [r for r in expected.values() if r['group_id'] == gid]
        require(sorted(r['scenario'] for r in rows) == list(SCENARIOS), 'panel requires complete triplets')
        require(all(r['datatype'] == group['datatype'] for r in rows), 'panel group datatype mismatch')
    require(len(records) == len(expected) == (12 if pilot else 384), 'configuration count mismatch')
    require(len(groups) == (4 if pilot else 128), 'group count mismatch')
    require(len({r['id'] for r in records}) == len(records) and
            {r['id'] for r in records} == set(expected), 'exact panel configuration IDs mismatch')
    datatypes = {g['datatype'] for g in panel['groups']}
    require(datatypes == {'int', 'str', 'list[int]', 'list[str]'} and Counter(g['datatype'] for g in selected) ==
            Counter({d: 1 if pilot else 32 for d in datatypes}), 'datatype group balance mismatch')
    require(all(sorted(g['index'] for g in selected if g['datatype'] == d) ==
                ([0] if pilot else list(range(32))) for d in datatypes), 'original group indices mismatch')
    actual_dirs = {p.name for p in (grid / 'groups').iterdir() if p.is_dir()}
    require(actual_dirs == set(groups), 'group directories differ from selected panel IDs')
    environment = load(_path(grid, 'environment.json'))
    require(environment['panel_sha256'] == panel_hash, 'environment panel hash mismatch')
    require(environment['pilot'] == pilot, 'pilot mode differs from producer')
    heads = sorted(map(tuple, panel['goal_heads']))
    require(len(set(heads)) == len(heads), 'duplicate panel head')
    by_group = defaultdict(list)
    for record in records:
        by_group[record['group_id']].append(record)
    raw_rows, checks_refs = [], []
    raw_files, checked_conditions = set(), 0
    recipe_hashes = set()
    for gid, group_records in sorted(by_group.items()):
        require(gid in groups, 'record group differs from panel')
        sub = grid / 'groups' / gid
        complete = load(_path(grid, f'groups/{gid}/complete.json'))
        recipe = complete.get('recipe_sha256')
        require(isinstance(recipe, str) and len(recipe) == 64 and
                all(c in '0123456789abcdef' for c in recipe), 'missing/invalid group recipe hash')
        recipe_hashes.add(recipe)
        require(len(recipe_hashes) == 1, 'mixed group measurement recipes')
        if historical:
            require('schema' not in complete, 'packaged runtime completion is not historical')
        else:
            require(complete.get('schema') == 'q_transfer_alt_group_v1',
                    'fresh analysis requires packaged runtime schema; use --historical for original data')
            require(environment.get('recipe_sha256') == recipe, 'environment recipe hash mismatch')
        manifest = complete.get('file_sha256')
        require(isinstance(manifest, dict) and manifest, 'missing group file checksum manifest')
        actual_files = {p.name for p in sub.iterdir() if p.is_file() and p.name != 'complete.json'}
        require(set(manifest) == actual_files, 'group file checksum manifest incomplete')
        for name, checksum in manifest.items():
            require(Path(name).name == name, 'unsafe group manifest reference')
            artifact = _path(grid, f'groups/{gid}/{name}')
            require(hashlib.sha256(artifact.read_bytes()).hexdigest() == checksum, 'group artifact checksum mismatch')
        require(complete['group_id'] == gid and complete['records'] == 3 and
                complete['panel_sha256'] == panel_hash and complete['group_sha256'] == digest(groups[gid]),
                f'{gid}: incomplete or mismatched completion record')
        require(sorted(load(_path(grid, f'groups/{gid}/scores.json')), key=lambda r: r['id']) ==
                sorted(group_records, key=lambda r: r['id']), f'{gid}: cached group records differ')
        materials = load(_path(grid, f'groups/{gid}/materialized.json'))
        require(len(materials) == 3 and {m['id'] for m in materials} == {r['id'] for r in group_records},
                f'{gid}: materialized IDs mismatch')
        mats = {m['id']: m for m in materials}
        ordered = sorted(group_records, key=lambda r: r['scenario'])
        require([r['scenario'] for r in ordered] == list(SCENARIOS), 'missing matched scenario')
        first = mats[ordered[0]['id']]['prompts']
        require(first['p_src']['input_ids'] == mats[ordered[1]['id']]['prompts']['p_src']['input_ids'],
                'ALT1/ALT2 source exact IDs differ')
        require(ordered[0]['conditions']['clean_source'] == ordered[1]['conditions']['clean_source'] and
                ordered[0]['source_cache_key'] == ordered[1]['source_cache_key'], 'ALT1/ALT2 source cache differs')
        require(len({r['source_cache_key'] for r in ordered}) == 2, 'expected two source caches per group')
        checks = load(_path(grid, f'groups/{gid}/checks.json'))
        require(checks['group_id'] == gid and len(checks['cache_reuse']) == 1 and
                checks['cache_reuse'][0] == {'scenario': 'ALT2', 'source_key': ordered[1]['source_cache_key'],
                                           'same_exact_ids': True}, 'source cache reuse audit mismatch')
        checks_refs.append(f'groups/{gid}/checks.json')
        raw_cache = {}
        for record in ordered:
            row, mat = expected[record['id']], mats[record['id']]
            for field in ('group_id', 'scenario', 'datatype', 'seed', 'roles', 'predictions'):
                require(record[field] == row[field], f'{record["id"]}: panel {field} differs')
            require(record['config_sha256'] == mat['row_config_sha256'] == digest(row) and
                    record['panel_sha256'] == panel_hash, 'configuration hash mismatch')
            if not historical:
                require(record.get('recipe_sha256') == recipe, 'record recipe hash mismatch')
            require(record['materialized'] == f'groups/{gid}/materialized.json', 'wrong map reference')
            prompts = mat['prompts']
            require(set(prompts) == {'p_src', 'p_dst', 'p_kv'}, 'unexpected prompts')
            require(set(record['prompt_hashes']) == set(prompts), 'prompt hash keys mismatch')
            for key, prompt in prompts.items():
                ids = prompt['input_ids']
                require(ids and all(isinstance(i, int) and i >= 0 for i in ids), 'invalid token IDs')
                require(prompt['attention_mask'] == [1] * len(ids) and
                        prompt['final_equals_index'] == len(ids) - 1 and
                        len(prompt['offset_mapping']) == len(ids), 'token metadata inconsistent')
                require(prompt['input_ids_sha256'] == record['prompt_hashes'][key] == digest(ids),
                        'exact input ID hash mismatch')
                require(set(prompt['description_positions']) == set(row['prompts'][key]['listed_roles']),
                        'materialized description role mismatch')
            require(prompts['p_dst']['input_ids'] == first['p_dst']['input_ids'], 'destination IDs not shared')
            require(record['conditions']['clean_destination'] == ordered[0]['conditions']['clean_destination'],
                    'clean destination cached record not shared')
            if historical:
                source_key = digest({'ids': prompts['p_src']['input_ids'], 'heads': panel['goal_heads'],
                                     'revision': environment['revision'], 'patch': None})
            else:
                from .provenance import source_cache_key
                source_key = source_cache_key(prompts['p_src']['input_ids'], panel['goal_heads'], recipe)
            require(record['source_cache_key'] == source_key, 'source cache hash mismatch')
            require(mat['condition_prompt_keys'] == {k: 'p_dst' for k in ('clean_destination',) + PRIMARY},
                    'primary conditions do not share recipient prompt')
            donor, dest = mat['donor_positions'], mat['destination_positions']
            require(donor == prompts['p_kv']['task_positions'] and dest == prompts['p_dst']['task_positions'] and
                    len(donor) == len(dest) == mat['alignment_width'] and len(set(donor)) == len(donor) and
                    len(set(dest)) == len(dest) and mat['donor_to_dst'] == [list(x) for x in zip(donor, dest)],
                    'invalid donor/recipient token mapping')
            require(all(0 <= i < len(prompts['p_kv']['input_ids']) for i in donor) and
                    all(0 <= i < len(prompts['p_dst']['input_ids']) for i in dest), 'mapping token out of bounds')
            mapping = dict(mat['donor_to_dst'])
            transferred = {r: [mapping[i] for i in positions]
                           for r, positions in prompts['p_kv']['description_positions'].items()}
            require(set(record['conditions']) == set(PRIMARY + DIAGNOSTICS), 'unexpected conditions')
            for name, condition in record['conditions'].items():
                prompt_key = 'p_src' if name == 'clean_source' else 'p_dst'
                prompt = prompts[prompt_key]
                positions = transferred if name in PRIMARY else prompt['description_positions']
                require(condition['description_positions'] == positions and
                        condition['token_count'] == len(prompt['input_ids']) and
                        condition['input_ids_sha256'] == digest(prompt['input_ids']), 'condition tokens/map mismatch')
                ref = condition['raw']
                scenario = record['scenario']
                filename = (f'{scenario}_{name}.npz' if name in PRIMARY else
                            'clean_destination.npz' if name == 'clean_destination' else
                            f'{"ALT1" if scenario == "ALT2" else scenario}_source.npz')
                require(ref == f'groups/{gid}/{filename}', 'raw reference does not match producer/cache identity')
                require(Path(ref).parent == Path('groups') / gid, 'raw belongs to different group')
                if ref not in raw_cache:
                    with np.load(_path(grid, ref), allow_pickle=False) as archive:
                        require(set(archive.files) == {'attention', 'value_norm', 'head_output', 'head_ids'},
                                'unexpected raw array fields')
                        raw_cache[ref] = {k: archive[k] for k in archive.files}
                diagnostic = raw_diagnostic(raw_cache[ref], condition, heads)
                raw_rows.append({'id': record['id'], 'condition': name, 'raw_ref': ref, **diagnostic})
                raw_files.add(ref)
                checked_conditions += 1
                if name in PRIMARY:
                    require(len(condition['scores']) == 4, 'primary condition must contain four tasks')
                    margin = condition['scores']['e'] - condition['scores'][ALTERNATIVE[record['scenario']]]
                    require(condition['set_minus_alternative'] == margin, 'saved primary margin mismatch')
            require(record['paired_margin_change'] == record['conditions'][PRIMARY[1]]['set_minus_alternative'] -
                    record['conditions'][PRIMARY[0]]['set_minus_alternative'], 'saved paired margin mismatch')
        found = {str(p.relative_to(grid)) for p in sub.glob('*.npz') if not p.name.endswith('_logit_controls.npz')}
        require(found == set(raw_cache), 'unreferenced/missing causal raw array file')
    return records, {'passed': True, 'pilot': pilot,
                     'provenance': 'historical' if historical else 'packaged_runtime',
                     'recipe_sha256': next(iter(recipe_hashes)),
                     'configurations': len(records), 'groups': len(groups),
                     'primary_score_rows': len(records) * 8, 'checked_condition_records': checked_conditions,
                     'unique_raw_files': len(raw_files), 'absolute_roundoff_tolerance': TOLERANCE,
                     'max_abs_score_or_sum_error': max(r['max_abs_score_or_sum_error'] for r in raw_rows),
                     'panel_sha256': panel_hash, 'raw_reaggregation': 'numpy float64, diagnostic only',
                     'primary_scores': 'unchanged saved torch FP32', 'checks_refs': checks_refs}, raw_rows


def score_exports(records):
    """Long-form primary and diagnostic scores, plus one wide row/configuration."""
    primary, diagnostics, configurations = [], [], []
    for record in records:
        base = {k: record[k] for k in ('id', 'group_id', 'datatype', 'scenario', 'seed', 'config_sha256', 'panel_sha256')}
        base.update(prompt_hashes=record['prompt_hashes'], map_ref=record['materialized'])
        if 'recipe_sha256' in record:
            base['recipe_sha256'] = record['recipe_sha256']
        config = {**base, 'roles': record['roles'], 'predictions': record['predictions'],
                  'source_cache_key': record['source_cache_key'], 'paired_margin_change': record['paired_margin_change']}
        for name, condition in record['conditions'].items():
            for role, score in condition['scores'].items():
                row = {**base, 'condition': name, 'role': role, 'task_id': record['roles'][role],
                       'score': score, 'sum': condition['sums'][role],
                       'description_token_count': condition['description_token_counts'][role],
                       'description_positions': condition['description_positions'][role],
                       'winner': role in condition['winners'], 'winners': condition['winners'], 'tie': condition['tie'],
                       'input_ids_sha256': condition['input_ids_sha256'], 'raw_ref': condition['raw']}
                (primary if name in PRIMARY else diagnostics).append(row)
            if name in PRIMARY:
                for role, score in condition['scores'].items():
                    config[f'{name}_score_{role}'] = score
                    config[f'{name}_sum_{role}'] = condition['sums'][role]
                    config[f'{name}_description_token_count_{role}'] = condition['description_token_counts'][role]
                config.update({f'{name}_winners': condition['winners'], f'{name}_tie': condition['tie'],
                               f'{name}_margin': condition['set_minus_alternative'], f'{name}_raw_ref': condition['raw']})
        configurations.append(config)
    return primary, diagnostics, configurations


def bootstrap_indices(group_ids, draws=DRAWS, seed=SEED):
    """One draw matrix per datatype, reused for ALL scenarios and conditions."""
    import numpy as np

    rng = np.random.default_rng(seed)
    return {datatype: rng.integers(0, len(ids), size=(draws, len(ids)))
            for datatype, ids in sorted(group_ids.items())}


def estimate(values, indices, count=False):
    import numpy as np

    values = np.asarray(values, dtype=np.float64)
    distribution = values[indices].mean(axis=1)
    scale = len(values) if count else 1
    lo, hi = np.quantile(distribution * scale, [.025, .975], axis=0)
    return {'value': float(values.mean() * scale), 'ci_low': float(lo), 'ci_high': float(hi)}


def summarize(records, draws=DRAWS, seed=SEED):
    """Bootstrap whole groups, preserving all three scenarios and both conditions.

    Pooled estimates are stratified: each draw retains the observed number of
    groups in each datatype (32 per datatype in the full run).
    """
    import numpy as np

    require(records, 'analysis requires complete triplets')
    require(len({r['id'] for r in records}) == len(records), 'duplicate configuration IDs')
    grouped = defaultdict(dict)
    for record in records:
        key = (record['datatype'], record['group_id'])
        require(record['scenario'] not in grouped[key], 'duplicate matched scenario')
        grouped[key][record['scenario']] = record
    require(all(set(rows) == set(SCENARIOS) for rows in grouped.values()), 'analysis requires complete triplets')
    group_ids = {d: sorted(g for dtype, g in grouped if dtype == d) for d in sorted({d for d, _ in grouped})}
    samples = bootstrap_indices(group_ids, draws, seed)
    ordered = {d: [grouped[(d, g)] for g in ids] for d, ids in group_ids.items()}
    offsets, offset = [], 0
    for datatype, ids in group_ids.items():
        offsets.append(samples[datatype] + offset)
        offset += len(ids)
    samples['pooled_stratified'] = np.concatenate(offsets, axis=1)
    ordered['pooled_stratified'] = [g for d in group_ids for g in ordered[d]]
    cells, paired, triplets, triplet_counts = [], [], [], []
    for (datatype, gid), rows in sorted(grouped.items()):
        triplets.append({'datatype': datatype, 'group_id': gid,
                         **{condition: triplet_key(rows.values(), condition) for condition in PRIMARY},
                         **{condition + '_winners': [rows[s]['conditions'][condition]['winners'] for s in SCENARIOS]
                            for condition in PRIMARY}})
    for datatype, group_rows in ordered.items():
        index = samples[datatype]
        n = len(group_rows)
        for scenario in SCENARIOS:
            rows = [g[scenario] for g in group_rows]
            before = [r['conditions'][PRIMARY[0]]['set_minus_alternative'] for r in rows]
            after = [r['conditions'][PRIMARY[1]]['set_minus_alternative'] for r in rows]
            transitions = [(winner_key(r['conditions'][PRIMARY[0]]['winners']),
                            winner_key(r['conditions'][PRIMARY[1]]['winners'])) for r in rows]
            transition_counts = {a + '->' + b: estimate([x == (a, b) for x in transitions], index, count=True)
                                 for a, b in sorted(set(transitions))}
            p = {'datatype': datatype, 'scenario': scenario, 'n': n, 'transitions': transition_counts}
            for label, values in (('margin_before', before), ('margin_after', after),
                                  ('margin_change', np.asarray(after) - before)):
                p.update({label + '_' + k: v for k, v in estimate(values, index).items()})
            paired.append(p)
            for condition in PRIMARY:
                cs = [r['conditions'][condition] for r in rows]
                exact = [winner_key(c['winners']) for c in cs]
                winner_counts = {w: estimate([x == w for x in exact], index, count=True) for w in sorted(set(exact))}
                roles = sorted(cs[0]['scores'])
                require(all(set(c['scores']) == set(roles) for c in cs), 'cell task roles differ')
                for role in roles:
                    cell = {'datatype': datatype, 'scenario': scenario, 'condition': condition, 'role': role, 'n': n,
                            'exact_winner_counts': winner_counts}
                    for metric, values, count in (
                            ('score', [c['scores'][role] for c in cs], False),
                            ('winner_including_ties_count', [role in c['winners'] for c in cs], True),
                            ('unique_winner_count', [c['winners'] == [role] for c in cs], True),
                            ('tie_count', [c['tie'] for c in cs], True)):
                        cell.update({metric + '_' + k: v for k, v in estimate(values, index, count).items()})
                    cells.append(cell)
        for condition in PRIMARY:
            keys = [triplet_key(g.values(), condition) for g in group_rows]
            named = {'eee', 'dee', 'efe', 'eeb'}
            counts = {key: estimate([x == key for x in keys], index, count=True) for key in sorted(set(keys) | named)}
            counts['all_other'] = estimate([x not in named for x in keys], index, count=True)
            triplet_counts.append({'datatype': datatype, 'condition': condition, 'n': n, 'counts': counts})
    summary = {'configurations': len(records), 'groups': len(grouped), 'primary_score_rows': len(records) * 8,
               'bootstrap': {'draws': draws, 'seed': seed, 'interval': '95% percentile',
                             'resampling_unit': 'whole matched basegroup, all three scenarios and both conditions linked',
                             'pooled': 'stratified by datatype, preserving observed counts',
                             'groups_per_datatype': {d: len(ids) for d, ids in group_ids.items()}},
               'score_source': 'unchanged saved torch FP32 scores; no threshold-based hypothesis selection',
               'tie_policy': 'exact score equality; tied winner sets retained; named triplets require unique winners',
               'diagnostics': 'separate, no eligibility filtering', 'triplet_counts': triplet_counts,
               'files': {'cells': 'cells.csv', 'paired': 'paired.csv', 'triplets': 'triplets.csv',
                         'task_scores': 'task_scores.json', 'configurations': 'configurations.csv'}}
    return summary, cells, paired, triplets


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--grid', type=Path, required=True)
    parser.add_argument('--panel', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--historical', action='store_true',
                        help='Validate original raw schema against the exact frozen historical panel')
    parser.add_argument('--pilot', action='store_true', help='Require the four index-0 groups (12 configurations)')
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)
    try:
        records, validation, raw = validate_grid(args.grid, args.panel, args.pilot, historical=args.historical)
    except Exception as error:
        dump(args.output / 'validation.json', {'passed': False, 'error': str(error), 'error_type': type(error).__name__})
        raise
    primary, diagnostics, configurations = score_exports(records)
    summary, cells, paired, triplets = summarize(records)
    summary['provenance'] = validation['provenance']
    summary['panel_sha256'] = validation['panel_sha256']
    summary['recipe_sha256'] = validation['recipe_sha256']
    for name, rows in (('configurations', configurations), ('task_scores', primary), ('diagnostics', diagnostics),
                       ('cells', cells), ('paired', paired), ('triplets', triplets)):
        write_csv(args.output / (name + '.csv'), rows)
    dump(args.output / 'task_scores.json', primary)
    dump(args.output / 'diagnostics.json', diagnostics)
    dump(args.output / 'raw_validation.json', raw)
    dump(args.output / 'validation.json', validation)
    dump(args.output / 'summary.json', summary)
    print(json.dumps({k: validation[k] for k in ('passed', 'configurations', 'groups', 'primary_score_rows',
                                                'unique_raw_files', 'max_abs_score_or_sum_error')}))


if __name__ == '__main__':
    main()
