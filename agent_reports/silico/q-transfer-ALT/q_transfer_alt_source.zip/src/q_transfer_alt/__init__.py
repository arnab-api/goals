"""Deterministic Q-transfer panels and opt-in runtime utilities.

Importing this package requires only the Python standard library and loads no
model, tokenizer, historical worktree, or environment-specific integration.
"""
from pathlib import Path

CONFIG_DIR = Path(__file__).resolve().parents[2] / "configs" / "q_transfer_alt"

__all__ = ["CONFIG_DIR"]
