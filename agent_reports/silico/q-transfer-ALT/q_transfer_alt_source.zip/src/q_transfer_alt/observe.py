"""Read-only final-query instrumentation; full-context native softmax is retained."""
from contextlib import contextmanager
import importlib
import torch

class Gaze:
    def __init__(self, heads):
        self.heads = {}
        for l,h in heads: self.heads.setdefault(l,[]).append(h)
        self.rows = {}; self.checks = {}

    def record(self, attn, weights, values, output, clean=None, routed=None):
        l=attn.layer_idx
        if l not in self.heads: return
        hs=sorted(self.heads[l]); group=attn.num_key_value_groups
        idx=torch.tensor(hs,device=values.device)
        va=values[0,idx//group]
        a=weights[0,idx,-1]
        o=output[0,-1,idx]
        # Independent FP32 reconstruction uses exactly the saved attention row
        # and matching effective value vectors. BF16 output is rounded natively.
        rec=torch.bmm(a.float().unsqueeze(1),va.float()).squeeze(1)
        err=(rec-o.float()).abs()
        tol=0.03125+0.015625*o.float().abs()
        norms=va.float().norm(dim=-1)
        self.rows[l]={'heads':hs, 'attention':a.detach().float().cpu(),
                      'value_norm':norms.detach().cpu(), 'head_output':o.detach().float().cpu()}
        check={'finite':bool(torch.isfinite(a).all() and torch.isfinite(norms).all()),
               'max_row_sum_error':float((a.float().sum(-1)-1).abs().max()),
               'reconstruction_max_abs':float(err.max()),
               'reconstruction_max_tolerance_ratio':float((err/tol).max()),
               'reconstruction_pass':bool((err<=tol).all()),
               'query_to_kv_heads':{str(h):h//group for h in hs}}
        if routed is not None:
            other=[h for h in range(weights.shape[1]) if h not in hs]
            check['unselected_native_max_abs']=float((routed[:,:,other]-clean[:,:,other]).abs().max()) if other else 0.
            check['selected_routed_max_abs']=float((routed[:,:,hs]-output[:,:,hs]).abs().max())
        self.checks[l]=check

    def transferred(self, attn, weights, values, output, clean, routed):
        self.record(attn,weights,values,output,clean,routed)

    def packed(self):
        layers=sorted(self.rows)
        return {'head_ids':[(l,h) for l in layers for h in self.rows[l]['heads']],
                **{k:torch.cat([self.rows[l][k] for l in layers]) for k in ['attention','value_norm','head_output']}}

    def validate(self):
        assert len(self.packed()['head_ids'])==sum(map(len,self.heads.values()))
        for c in self.checks.values():
            assert c['finite'] and c['reconstruction_pass'],c
            assert c['max_row_sum_error'] <= .005,c
            assert c.get('unselected_native_max_abs',0)==0,c
            assert c.get('selected_routed_max_abs',0)==0,c

@contextmanager
def native_gaze(model, gaze):
    """Observe the exact native eager function, returning its outputs untouched."""
    native=importlib.import_module(type(model.model.layers[0].self_attn).__module__)
    original=native.eager_attention_forward
    def observed(module, query, key, value, attention_mask, **kwargs):
        output, weights=original(module,query,key,value,attention_mask,**kwargs)
        gaze.record(module,weights,value,output)
        return output,weights
    native.eager_attention_forward=observed
    try: yield
    finally: native.eager_attention_forward=original
