"""Materialize frozen prompts without generating or renaming variables.

Alignment follows the previous experiment: insert *newline token IDs* at the
start of the shorter KV/destination task-list span. Never retokenize afterward:
BPE can merge adjacent newlines. The returned IDs are the model input; rendered
strings are exact decodings, not a promise of canonical retokenization.
"""
from __future__ import annotations

from .validate_panel import digest

SYSTEM = (
    "You are a helpful assistant proficient in programming. Always wrap your code inside "
    "<code></code> blocks. Just the code, no need to comment or explain."
)


def _decode(tok, ids):
    return tok.decode(ids, skip_special_tokens=False, clean_up_tokenization_spaces=False)


def _positions(offsets, start, end, text, label):
    """Keep whole tokens overlapping content; reject non-whitespace spill.

    A BPE token may contain a leading space or a trailing newline as well as
    description characters. Keep that indivisible token and audit its whitespace
    fringe. Standalone labels, separators, and padding are never selected.
    """
    selected, fringe = [], []
    for i, (a, b) in enumerate(offsets):
        if b <= a or a >= end or b <= start:
            continue
        left = text[a:start] if a < start else ""
        right = text[end:b] if b > end else ""
        if (left and not left.isspace()) or (right and not right.isspace()):
            raise ValueError(f"{label}: token {i} crosses a non-whitespace boundary")
        selected.append(i)
        if left or right:
            fringe.append({"token_index": i, "before": left, "after": right})
    if not selected:
        raise ValueError(f"{label}: empty token span")
    # Union coverage also permits multiple byte-level tokens for one Unicode char.
    cursor = start
    for i in selected:
        a, b = offsets[i]
        if a > cursor:
            raise ValueError(f"{label}: tokenizer offsets leave a character gap")
        cursor = max(cursor, b)
    if cursor < end:
        raise ValueError(f"{label}: tokenizer offsets truncate content")
    return selected, fringe


def _render(parts, tok):
    question, prefill = parts["question"], parts["prefill"]
    if parts["text"] != question + prefill:
        raise ValueError("Frozen text must equal question plus prefill")
    lo, hi = parts["task_list_span"]
    if not 0 <= lo < hi <= len(question) or question[lo:hi] != parts["task_list_text"]:
        raise ValueError("Frozen task-list character span is inconsistent")
    if not prefill.endswith("="):
        raise ValueError("Assistant prefill must end at equals")
    rendered = tok.apply_chat_template(
        [{"role": "system", "content": SYSTEM},
         {"role": "user", "content": question},
         {"role": "assistant", "content": prefill}],
        add_generation_prompt=False, continue_final_message=True, tokenize=False,
        chat_template_kwargs={"enable_thinking": False},
    )
    if rendered.count(question) != 1 or not rendered.endswith(prefill):
        raise ValueError("Chat template must preserve the question and final assistant prefill")
    base = rendered.index(question)
    encoded = tok(rendered, add_special_tokens=False, return_offsets_mapping=True)
    ids = [int(i) for i in encoded["input_ids"]]
    offsets = [[int(a), int(b)] for a, b in encoded["offset_mapping"]]
    if len(ids) != len(offsets) or not ids:
        raise ValueError("Tokenizer must return one offset pair per token")
    if any(a < 0 or b < a or b > len(rendered) for a, b in offsets):
        raise ValueError("Tokenizer offsets are not rendered-string character indices")
    if _decode(tok, ids) != rendered:
        raise ValueError("Token IDs do not decode to the exact rendered prompt")
    mask = encoded.get("attention_mask", [1] * len(ids))
    if len(mask) != len(ids) or any(int(x) != 1 for x in mask):
        raise ValueError("Unpadded tokenizer output must have an all-ones mask")
    task_positions, _ = _positions(offsets, base + lo, base + hi, rendered, "task list")
    if task_positions != list(range(task_positions[0], task_positions[-1] + 1)):
        raise ValueError("Task-list tokens must form a contiguous span")
    descriptions, spans, fringes = {}, {}, {}
    for desc in parts["description_spans"]:
        role, start, end = desc["role"], desc["start"], desc["end"]
        if (role in descriptions or not lo <= start < end <= hi
                or question[start:end] != desc["text"]):
            raise ValueError("Frozen description character span is inconsistent")
        spans[role] = [base + start, base + end]
        descriptions[role], fringes[role] = _positions(
            offsets, *spans[role], rendered, f"description {role}")
    if list(descriptions) != parts["listed_roles"]:
        raise ValueError("Description roles must match the frozen listed order")
    equals, _ = _positions(offsets, len(rendered) - 1, len(rendered), rendered, "final equals")
    if equals != [len(ids) - 1]:
        raise ValueError("Final equals must be exactly one final token")
    return {
        "rendered": rendered, "unpadded_rendered": rendered,
        "input_ids": ids, "attention_mask": [1] * len(ids),
        "offset_mapping": offsets, "description_positions": descriptions,
        "description_spans": spans, "description_whitespace_fringe": fringes,
        "task_positions": task_positions,
        "task_span": [task_positions[0], task_positions[-1] + 1],
        "task_list_char_span": [base + lo, base + hi],
        "padding_positions": [], "final_equals_index": equals[0],
    }


def _pad(prompt, count, newline_id, tok):
    if not count:
        return
    start, end = prompt["task_span"]
    char_start = prompt["offset_mapping"][start][0]
    # Inserting at a token boundary must not cut an overlapping byte-level token.
    if any(b > char_start for a, b in prompt["offset_mapping"][:start]):
        raise ValueError("Task-list insertion point cuts a token")
    old_offsets = prompt["offset_mapping"]
    prompt["input_ids"][start:start] = [newline_id] * count
    prompt["attention_mask"][start:start] = [1] * count
    prompt["offset_mapping"] = (
        old_offsets[:start]
        + [[char_start + i, char_start + i + 1] for i in range(count)]
        + [[a + count, b + count] for a, b in old_offsets[start:]]
    )
    prompt["rendered"] = (prompt["rendered"][:char_start] + "\n" * count
                          + prompt["rendered"][char_start:])
    if _decode(tok, prompt["input_ids"]) != prompt["rendered"]:
        raise ValueError("Inserted newline tokens do not preserve the exact prompt")
    prompt["padding_positions"] = list(range(start, start + count))
    prompt["task_span"] = [start, end + count]
    prompt["task_positions"] = list(range(start, end + count))
    prompt["task_list_char_span"] = [x + count for x in prompt["task_list_char_span"]]
    prompt["final_equals_index"] += count
    for role in prompt["description_positions"]:
        prompt["description_positions"][role] = [i + count for i in prompt["description_positions"][role]]
        prompt["description_spans"][role] = [x + count for x in prompt["description_spans"][role]]
        for fringe in prompt["description_whitespace_fringe"][role]:
            fringe["token_index"] += count


def materialize(row, tok):
    """Return a JSON-safe, single-example prompt bundle from one frozen panel row.

    ``prompts[p_src|p_kv|p_dst]`` contains exact rendered strings, flat model
    ``input_ids`` and all-ones ``attention_mask``, character ``offset_mapping``,
    per-role ``description_positions`` and character ``description_spans``,
    contiguous ``task_positions`` / half-open ``task_span``, padding positions,
    and ``final_equals_index``. Descriptions retain whole overlapping BPE tokens
    only; whitespace merged into them is recorded in
    ``description_whitespace_fringe``. No standalone separators or padding enter
    those indices. Character spans refer to ``rendered``; ``task_list_char_span``
    excludes inserted padding, whereas ``task_positions`` includes it.

    Only p_kv and p_dst are aligned; p_src is untouched. ``donor_to_dst`` is an
    ordered list of [p_kv token index, p_dst token index] pairs, not a semantic
    role match. All three conditions point to the same p_dst model input. The
    caller may batch/tensorize flat lists but must not retokenize the strings.
    The function does not modify the panel row, names, or head configuration.
    """
    prompts = {key: _render(row["prompts"][key], tok) for key in ("p_src", "p_kv", "p_dst")}
    newline_ids = [int(i) for i in tok("\n", add_special_tokens=False)["input_ids"]]
    if len(newline_ids) != 1 or _decode(tok, newline_ids) != "\n":
        raise ValueError("Alignment requires one standalone newline token")
    donor, destination = prompts["p_kv"], prompts["p_dst"]
    target = max(len(donor["task_positions"]), len(destination["task_positions"]))
    for prompt in (donor, destination):
        _pad(prompt, target - len(prompt["task_positions"]), newline_ids[0], tok)
    return _bundle(row, prompts, target)


def _bundle(row, prompts, target):
    for prompt in prompts.values():
        prompt["input_ids_sha256"] = digest(prompt["input_ids"])
    donor_positions = prompts["p_kv"]["task_positions"]
    destination_positions = prompts["p_dst"]["task_positions"]
    return {
        "row_config_sha256": digest(row), "alignment_width": target,
        "id": row["id"], "prompts": prompts,
        "donor_positions": list(donor_positions),
        "destination_positions": list(destination_positions),
        "donor_to_dst": [[a, b] for a, b in zip(donor_positions, destination_positions)],
        "condition_prompt_keys": {name: "p_dst" for name in
                                  ("clean_destination", "kv_only", "kv_plus_source_q")},
    }


def materialize_group(rows, tok):
    """Return ALT1/2/3 bundles aligned to one common donor/recipient width.

    Accept three rows in any order. Sources are rendered without padding. All
    recipients must be identical frozen records and yield identical padded IDs.
    SHA-256 values use the frozen builder's canonical JSON convention; ID hashes
    cover the actual model inputs, including any inserted newline tokens.
    """
    rows = list(rows)
    if len(rows) != 3 or {r["scenario"] for r in rows} != {"ALT1", "ALT2", "ALT3"}:
        raise ValueError("Group requires exactly one row for each ALT1/2/3")
    rows.sort(key=lambda r: r["scenario"])
    if len({r["group_id"] for r in rows}) != 1:
        raise ValueError("Rows must belong to one group")
    for field in ("datatype", "seed"):
        if len({r[field] for r in rows}) != 1:
            raise ValueError(f"Group {field} must match")
    for row in rows[1:]:
        if row["prompts"]["p_dst"] != rows[0]["prompts"]["p_dst"]:
            raise ValueError("Original recipients must be identical")
        for field in ("roles", "opaque_names"):
            for role in row[field].keys() & rows[0][field].keys():
                if row[field][role] != rows[0][field][role]:
                    raise ValueError(f"Group {field} must agree on shared roles")
    rendered = [{key: _render(row["prompts"][key], tok)
                 for key in ("p_src", "p_kv", "p_dst")} for row in rows]
    newline_ids = [int(i) for i in tok("\n", add_special_tokens=False)["input_ids"]]
    if len(newline_ids) != 1 or _decode(tok, newline_ids) != "\n":
        raise ValueError("Alignment requires one standalone newline token")
    target = max(len(bundle[key]["task_positions"])
                 for bundle in rendered for key in ("p_kv", "p_dst"))
    for bundle in rendered:
        for key in ("p_kv", "p_dst"):
            prompt = bundle[key]
            _pad(prompt, target - len(prompt["task_positions"]), newline_ids[0], tok)
    if any(bundle["p_dst"]["input_ids"] != rendered[0]["p_dst"]["input_ids"]
           for bundle in rendered[1:]):
        raise ValueError("Padded recipient IDs must be identical")
    return [_bundle(row, bundle, target) for row, bundle in zip(rows, rendered)]
