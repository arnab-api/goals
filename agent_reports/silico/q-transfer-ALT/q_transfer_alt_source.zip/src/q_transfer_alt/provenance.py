"""Portable, content-addressed model identity, measurement recipes and resume checks.

Manifest revision is an operator attestation, not proof of upstream origin. Hashes
bind that attestation to exact local bytes and survive copying out of HF caches.
This module deliberately imports only the standard library.
"""
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil

PINNED_REVISION = '381fc969f78efac66bc87ff7ddeadb7e73c218a7'


def sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def dump(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(obj, indent=2) + '\n')
    tmp.replace(path)


def _model_files(root):
    # These are the files used by native Qwen2/AutoTokenizer, not download cache
    # bookkeeping, logs, README files, or this explicit manifest.
    names = {p.name for p in root.iterdir() if p.is_file() and (
        p.suffix in {'.safetensors', '.bin', '.model', '.tiktoken'} or
        p.name in {'config.json', 'generation_config.json', 'model.safetensors.index.json',
                   'pytorch_model.bin.index.json', 'tokenizer.json', 'tokenizer_config.json',
                   'special_tokens_map.json', 'added_tokens.json', 'vocab.json', 'merges.txt',
                   'chat_template.jinja'})}
    names.update(p.relative_to(root).as_posix() for p in (root / 'chat_templates').glob('*.jinja') if p.is_file())
    if 'config.json' not in names or 'tokenizer_config.json' not in names:
        raise ValueError('Local checkpoint requires config.json and tokenizer_config.json')
    if not ({'tokenizer.json', 'vocab.json', 'tokenizer.model'} & names):
        raise ValueError('Local tokenizer vocabulary is missing')
    if not any(n.endswith(('.safetensors', '.bin')) for n in names):
        raise ValueError('Local model weights are missing')
    for index in ('model.safetensors.index.json', 'pytorch_model.bin.index.json'):
        if index in names:
            shards = set(json.loads((root / index).read_text())['weight_map'].values())
            if not shards or not shards <= names:
                raise ValueError('Weight index references missing or nonlocal shards')
    return sorted(names)


def create_model_manifest(model_path, revision=PINNED_REVISION):
    """Hash local weights/tokenizer; save returned dict with dump(path, result).

    Call only for a checkpoint whose upstream revision has been independently
    established. This may read tens of GB and belongs on the model's compute.
    """
    root = Path(model_path)
    files = {name: file_sha(root / name) for name in _model_files(root)}
    return {'schema_version': 1, 'revision': revision, 'files': files}


def verify_model_manifest(model_path, manifest_path):
    expected = json.loads(Path(manifest_path).read_text())
    if expected.get('schema_version') != 1 or expected.get('revision') != PINNED_REVISION:
        raise ValueError('Manifest must attest the pinned checkpoint revision')
    actual = create_model_manifest(model_path)
    if actual != expected:
        raise ValueError('Local checkpoint/tokenizer bytes do not match model manifest')
    return {'revision': PINNED_REVISION, 'manifest_sha256': sha(actual), 'files': actual['files']}


def recipe_hash(panel_path, heads, model_identity, options, lock_path=None):
    """Hash current portable source, environment lock, input bytes and settings."""
    package = Path(__file__).resolve().parent
    config = package.parents[1] / 'configs' / 'q_transfer_alt'
    lock = Path(lock_path) if lock_path else config / 'environment' / 'uv.lock'
    if not lock.is_file():
        raise ValueError(f'Measurement recipe requires environment lock: {lock}')
    return sha({'schema_version': 1,
                'package_files': {str(p.relative_to(package)): file_sha(p)
                                  for p in sorted(package.rglob('*.py'))},
                'lock_sha256': file_sha(lock), 'panel_sha256': file_sha(panel_path),
                'heads_file_sha256': file_sha(config / 'goal250.json'),
                'heads': heads, 'model_identity': model_identity, 'options': options})


def _safe_name(name):
    if not isinstance(name, str) or not name:
        raise ValueError('Artifact name must be a nonempty string')
    p = PurePosixPath(name)
    if p.is_absolute() or '..' in p.parts or str(p) != name or '\\' in name:
        raise ValueError(f'Unsafe artifact name: {name!r}')
    return p


def verify_resume(sub, group, rows, recipe_sha256, panel_sha256):
    """Validate a completed group, including closure of all artifact references."""
    sub = Path(sub)
    if sub.is_symlink():
        raise ValueError('Symlinked resume group is not allowed')
    done = json.loads((sub / 'complete.json').read_text())
    if done.get('schema') != 'q_transfer_alt_group_v1':
        raise ValueError('Historical or unknown resume schema is not supported')
    for key, value in {'panel_sha256': panel_sha256, 'group_sha256': sha(group),
                       'recipe_sha256': recipe_sha256}.items():
        if done.get(key) != value:
            raise ValueError(f'Resume {key} mismatch')
    if done.get('group_id') != group['id'] or done.get('records') != len(rows):
        raise ValueError('Resume completion group/count mismatch')
    files = done.get('file_sha256', {})
    if not {'scores.json', 'materialized.json', 'checks.json'} <= files.keys():
        raise ValueError('Resume missing required artifact digests')
    actual = {p.name for p in sub.iterdir() if p.name != 'complete.json'}
    if actual != set(files):
        raise ValueError('Resume file inventory mismatch')
    if (sub / 'complete.json').is_symlink():
        raise ValueError('Symlinked completion record is not allowed')
    for name, digest in files.items():
        _safe_name(name)
        p = sub / name
        if len(PurePosixPath(name).parts) != 1 or p.is_symlink() or not p.is_file() or file_sha(p) != digest:
            raise ValueError(f'Resume corrupt file: {name}')
    records = json.loads((sub / 'scores.json').read_text())
    materials = json.loads((sub / 'materialized.json').read_text())
    checks = json.loads((sub / 'checks.json').read_text())
    if len(materials) != len(rows) or not isinstance(checks, dict) or checks.get('group_id') != group['id']:
        raise ValueError('Resume materialized/checks structure mismatch')
    if [r['id'] for r in records] != [r['id'] for r in rows]:
        raise ValueError('Resume row IDs mismatch')
    prefix = f"groups/{group['id']}/"
    for rec, row, materialized in zip(records, rows, materials):
        if materialized.get('id') != row['id'] or materialized.get('row_config_sha256') != sha(row):
            raise ValueError('Resume materialized row identity mismatch')
        prompts = materialized.get('prompts', {})
        if set(prompts) != {'p_src', 'p_kv', 'p_dst'}:
            raise ValueError('Resume materialized prompts missing')
        hashes = {name: sha(p['input_ids']) for name, p in prompts.items()}
        if rec.get('prompt_hashes') != hashes or any(p.get('input_ids_sha256') != hashes[name] for name, p in prompts.items()):
            raise ValueError('Resume exact input IDs mismatch')
        if rec.get('config_sha256') != sha(row) or rec.get('recipe_sha256') != recipe_sha256 or rec.get('panel_sha256') != panel_sha256:
            raise ValueError('Resume row identity mismatch')
        if rec.get('materialized') != prefix + 'materialized.json':
            raise ValueError('Resume materialized reference mismatch')
        conditions = rec.get('conditions', {})
        if set(conditions) != {'clean_source', 'clean_destination', 'kv_only', 'kv_plus_source_q'}:
            raise ValueError('Resume required conditions missing')
        for name, condition in conditions.items():
            if condition.get('input_ids_sha256') != hashes['p_src' if name == 'clean_source' else 'p_dst']:
                raise ValueError('Resume condition input IDs mismatch')
            ref = condition.get('raw', '')
            if not ref.startswith(prefix) or ref[len(prefix):] not in files or not ref.endswith('.npz'):
                raise ValueError('Resume raw artifact reference missing')
            _safe_name(ref)
    return records


def prepare_resume(output, resume, groups, grouped, recipe, panel_sha):
    """Validate every completed selected product before copying anything.

    A directory without complete.json is disposable, never merged. Existing
    completed output groups are subject to exactly the same strict validation.
    """
    output = Path(output)
    sources = []
    selected_ids = {g['id'] for g in groups}
    for root in [output] + ([Path(resume)] if resume is not None else []):
        parent = root / 'groups'
        if parent.is_symlink():
            raise ValueError('Symlinked groups directory is not allowed')
        if parent.exists() and any(p.name not in selected_ids for p in parent.iterdir()):
            raise ValueError('Unexpected groups in output/resume directory')
    for group in groups:
        gid = group['id']
        _safe_name(gid)
        if len(PurePosixPath(gid).parts) != 1:
            raise ValueError('Group ID must be a single directory name')
        rows = sorted(grouped[gid], key=lambda r: r['scenario'])
        target = output / 'groups' / gid
        candidates = [target]
        if resume is not None:
            source = Path(resume) / 'groups' / gid
            if source.resolve() != target.resolve():
                candidates.insert(0, source)
        selected = None
        for source in candidates:
            if source.is_symlink():
                raise ValueError('Symlinked group not allowed')
            if (source / 'complete.json').exists():
                verify_resume(source, group, rows, recipe, panel_sha)
                if selected is None:
                    selected = source
        sources.append((target, selected))
    for target, source in sources:
        if source is not None and source.resolve() == target.resolve():
            continue
        if target.exists():
            shutil.rmtree(target)
        if source is not None:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copytree(source, target)
        else:
            target.mkdir(parents=True, exist_ok=True)


def source_cache_key(ids, heads, recipe_hash):
    """Source-Q reuse is bound to exact token IDs, ordered heads and recipe."""
    return sha({'ids': ids, 'heads': heads, 'recipe_sha256': recipe_hash, 'patch': None})


def main(argv=None):
    import argparse
    ap = argparse.ArgumentParser(description='Hash a local checkpoint and tokenizer. Revision is an operator declaration, not independent proof of upstream origin.')
    ap.add_argument('--model-path', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    ap.add_argument('--revision', default=PINNED_REVISION)
    args = ap.parse_args(argv)
    dump(args.output, create_model_manifest(args.model_path, args.revision))
    return 0


if __name__ == '__main__':
    main()
