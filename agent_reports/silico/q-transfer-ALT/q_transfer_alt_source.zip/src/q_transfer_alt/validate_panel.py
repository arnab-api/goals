"""Offline integrity/design validation for the frozen matched grid; no regeneration.

Hashes retain the original bank convention: sorted keys, ASCII escaping,
compact JSON, UTF-8, SHA-256. Validation never executes task reference code.
"""
from __future__ import annotations

from collections import Counter, defaultdict
import hashlib
import json
from . import CONFIG_DIR


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":"))


def digest(value):
    return hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _hashed(record, key, label):
    _require(record[key] == digest({k: v for k, v in record.items() if k != key}),
             f"{label}: {key} mismatch")


DATATYPES = ("int", "str", "list[int]", "list[str]")
ROLES = "abcdefxyz"
LAYOUTS = {
    "ALT1": {"p_src": ("abcd", "abd"), "p_kv": ("abde", "a"), "p_dst": ("axyz", "a")},
    "ALT2": {"p_src": ("abcd", "abd"), "p_kv": ("adef", "a"), "p_dst": ("axyz", "a")},
    "ALT3": {"p_src": ("abcd", "abc"), "p_kv": ("acbe", "a"), "p_dst": ("axyz", "a")},
}
PREDICTIONS = {
    "ALT1": dict(source_copy="c", clean_destination="x", set_transferred_list="e", count_transferred_list="e", order_id="d", last_written_successor="e", kv_only="b", count_original_destination="z"),
    "ALT2": dict(source_copy="c", clean_destination="x", set_transferred_list="e", count_transferred_list="f", order_id="e", last_written_successor="e", kv_only="d", count_original_destination="z"),
    "ALT3": dict(source_copy="d", clean_destination="x", set_transferred_list="e", count_transferred_list="e", order_id="e", last_written_successor="b", kv_only="c", count_original_destination="z"),
}


def _layout(record, listed, written, label):
    frontier = next(r for r in listed if r not in written)
    _require(record["listed_roles"] == list(listed), f"{label}: listed roles")
    _require(record["written_roles"] == list(written), f"{label}: written roles")
    _require(record["completed_set"] == sorted(written), f"{label}: completed set")
    _require(record["frontier_role"] == frontier, f"{label}: frontier")


def _prompt(prompt, row, key, definitions):
    label = f"{row['id']}/{key}"
    listed, written = LAYOUTS[row["scenario"]][key]
    _layout(prompt, listed, written, label)
    _hashed(prompt, "components_sha256", label)
    text, question, prefill = (prompt[k] for k in ("text", "question", "prefill"))
    _require(text == question + prefill, f"{label}: text components")
    _require(prompt["text_sha256"] == hashlib.sha256(text.encode("utf-8")).hexdigest(),
             f"{label}: text hash")
    lo, hi = prompt["task_list_span"]
    _require(0 <= lo < hi <= len(question), f"{label}: task span")
    descriptions = [definitions[row["roles"][r]]["description"] for r in listed]
    expected_list = "\n".join(f"({i}) {desc}" for i, desc in enumerate(descriptions, 1))
    _require(question[lo:hi] == prompt["task_list_text"] == expected_list, f"{label}: task text")
    phrase = {"int": "an integer", "str": "a string", "list[int]": "a list of integers",
              "list[str]": "a list of strings"}[row["datatype"]]
    header = f"Write a Python program that implements a function `func` which, given {phrase} `x`, computes:\n"
    _require(question == header + expected_list + "\n", f"{label}: question template")
    spans = prompt["description_spans"]
    _require([d["role"] for d in spans] == list(listed), f"{label}: description order")
    cursor = lo
    for index, (role, desc, span) in enumerate(zip(listed, descriptions, spans), 1):
        start = cursor + len(f"({index}) ")
        end = start + len(desc)
        _require(span == dict(role=role, task_id=row["roles"][role], start=start, end=end, text=desc),
                 f"{label}: description identity/span")
        cursor = end + 1
    names = row["opaque_names"]
    expected_assignments = [dict(role=r, task_id=row["roles"][r], variable=names[r],
                                text="    " + definitions[row["roles"][r]]["assignment"].replace("{name}", names[r]))
                            for r in written]
    _require(prompt["supplied_assignments"] == expected_assignments, f"{label}: assignments")
    pivot = f"    {names['pending']} ="
    expected_prefill = "<code>\ndef func(x: " + row["datatype"] + "):\n"
    expected_prefill += "\n".join(a["text"] for a in expected_assignments) + "\n" + pivot
    _require(prefill == expected_prefill, f"{label}: prefill/opaque names")
    _require(prompt["unfinished_variable"] == names["pending"] and prompt["pivot"] == pivot,
             f"{label}: pending name")
    _require(prompt["frontier_task_id"] == row["roles"][prompt["frontier_role"]], f"{label}: frontier identity")


def validate_panel(panel):
    """Return JSON-safe validation evidence; raise ValueError on invalid input.

    Exclusion is checked against packaged signatures read from the original
    16-row smoke artifact, not against a regenerated or outcome-screened panel.
    No tokenizer, model, bank import, or historical filesystem access is needed.
    """
    try:
        return _validate_panel(panel)
    except (KeyError, TypeError, IndexError, StopIteration, AttributeError) as exc:
        raise ValueError(f"Malformed frozen panel: {exc}") from exc


def _validate_panel(panel):
    _require(isinstance(panel, dict), "panel must be a JSON object")
    _hashed(panel, "content_sha256", "panel")
    _require(panel["schema"] == "alternate_hypothesis_kv_gaze_grid_v1", "panel schema")
    definitions = panel["task_definitions"]
    for task_id, task in definitions.items():
        _require(task_id == task["id"] and task["datatype"] in DATATYPES, "task identity/datatype")
        _hashed(task, "definition_sha256", task_id)
    bank_hash = digest({"version": panel["bank_version"],
                        "definitions": [definitions[k] for k in sorted(definitions)]})
    _require(panel["bank_sha256"] == bank_hash, "bank hash mismatch")
    _require(bank_hash == "06cb7cc8fd2dffa9fee7412de2cb767b1ce1f102b5a7345130e982867ad2d55e",
             "original bank definitions required")
    _require(panel["renderer_version"] == "1.0.0", "original renderer version required")
    _require(panel["input_domains"] == {task["datatype"]: task["input_domain"]
                                       for task in definitions.values()}, "input domains mismatch")
    _require(set(panel["scenarios"]) == set(LAYOUTS), "scenario inventory")
    for alt, scenario in panel["scenarios"].items():
        _hashed(scenario, "definition_sha256", alt)
        _require(scenario["id"] == f"{alt}_KV_GRID_V1", "scenario ID")
        _require(set(scenario["layouts"]) == set(LAYOUTS[alt]), "scenario layout inventory")
        for key, (listed, written) in LAYOUTS[alt].items():
            _layout(scenario["layouts"][key], listed, written, alt + key)
        _require(scenario["symbolic_predictions"] == PREDICTIONS[alt], "scenario predictions")
    heads = panel["goal_heads"]
    _require(len(heads) == len(set(map(tuple, heads))) == 250, "250 unique goal heads required")
    _require(all(len(h) == 2 and all(type(v) is int for v in h)
                 and 0 <= h[0] < 64 and 0 <= h[1] < 40 for h in heads), "goal head coordinates")
    _require(heads == GOAL_HEADS and panel["goal_heads_sha256"] == GOAL_HEADS_FILE_SHA256,
             "exact original goal heads/order/hash required")
    config = json.loads((CONFIG_DIR / "original_grid.json").read_text(encoding="utf-8"))
    _require(panel["settings"] == config["settings"], "original grid settings required")
    _require(panel["design_notes"] == config["design_notes"], "original grid design notes required")
    groups, rows = panel["groups"], panel["rows"]
    _require(len(groups) == 128 and len(rows) == 384, "128 groups/384 rows required")
    by_group = {g["id"]: g for g in groups}
    _require(len(by_group) == 128 and len({r["id"] for r in rows}) == 384, "unique group/row IDs")
    counts = Counter(f"{r['scenario']}:{r['datatype']}" for r in rows)
    _require(counts == Counter({f"{a}:{d}": 32 for a in LAYOUTS for d in DATATYPES}), "12 cells of 32 rows required")
    _require(Counter(g["datatype"] for g in groups) == Counter({d: 32 for d in DATATYPES}), "32 groups/datatype")
    signatures = set()
    for g in groups:
        dt, roles = g["datatype"], g["roles"]
        _require(type(g["index"]) is int and 0 <= g["index"] < 32, "group index")
        _require(g["id"] == f"{dt}-group-{g['index']:02d}", "group identity")
        _require(g["seed"] == dict(zip(DATATYPES, (31000, 41000, 51000, 61000)))[dt] + g["index"], "group seed")
        _require(set(roles) == set(ROLES) and len(set(roles.values())) == 9, "nine distinct task IDs per group")
        families, hashes = {}, {}
        for role, task_id in roles.items():
            task = definitions[task_id]
            _require(task["datatype"] == dt, "group task datatype")
            families[role], hashes[role] = task["family"], task["definition_sha256"]
        _require(g["family_by_role"] == families and g["task_definition_sha256"] == hashes, "group task metadata")
        _require(len({families[r] for r in "bcdef"}) == 5, "bcdef require five distinct families")
        policy = "bcdef_distinct_families_supporting_axyz_may_overlap"
        if dt.startswith("list"):
            _require(len(set(families.values())) == 9, "list group requires nine distinct families")
            policy = "all_nine_roles_distinct_families"
        _require(g["family_policy"] == policy, "family policy")
        names = g["opaque_names"]
        _require(set(names) == set(ROLES) | {"pending"} and len(set(names.values())) == 10,
                 "ten distinct opaque names required")
        _require(all(isinstance(n, str) and len(n) == 1 and n in "abcdefghijklmnopqrstuvwxyz" for n in names.values()), "opaque names")
        signatures.add((dt, digest(roles)))
    _require(len(signatures) == 128, "unique group assignment signatures")
    grouped = defaultdict(list)
    row_hashes = {}
    for row in rows:
        gid, alt = row["group_id"], row["scenario"]
        g = by_group[gid]
        _require(row["id"] == f"{alt}/{gid}", "row identity")
        _require(row["datatype"] == g["datatype"] and row["seed"] == g["seed"], "row group metadata")
        active = set().union(*(set(listed) for listed, _ in LAYOUTS[alt].values()))
        _require(row["roles"] == {r: g["roles"][r] for r in active}, "row role identities")
        _require(row["opaque_names"] == {r: g["opaque_names"][r] for r in active | {"pending"}}, "row opaque names")
        _require(row["predictions"] == PREDICTIONS[alt], "row predictions")
        _require(set(row["prompts"]) == set(LAYOUTS[alt]), "prompt inventory")
        for key, prompt in row["prompts"].items():
            _prompt(prompt, row, key, definitions)
        grouped[gid].append(row)
        row_hashes[row["id"]] = digest(row)
    for gid, matched in grouped.items():
        _require(Counter(r["scenario"] for r in matched) == Counter(LAYOUTS.keys()), "one ALT1/2/3 per group")
        _require(len({digest(r["prompts"]["p_dst"]) for r in matched}) == 1, "original recipients differ")
        src = {r["scenario"]: r["prompts"]["p_src"] for r in matched}
        _require(src["ALT1"] == src["ALT2"], "ALT1/2 sources differ")
    _require(len(grouped) == 128, "all groups must be represented")
    old_signatures = {(dt, sha) for dt, sha in OLD16_SIGNATURES}
    new_signatures = {(r["datatype"], digest(r["roles"])) for r in rows if r["scenario"] == "ALT1"}
    overlap = sorted(old_signatures & new_signatures)
    _require(not overlap, "prior smoke ALT1 assignment reused")
    return dict(valid=True, row_count=len(rows), group_count=len(groups), counts=dict(sorted(counts.items())),
                content_sha256=panel["content_sha256"], bank_sha256=bank_hash,
                row_config_sha256=row_hashes, goal_head_count=len(heads),
                exclusion=dict(verified=True, source=OLD16_SOURCE, source_file_sha256=OLD16_FILE_SHA256,
                               source_content_sha256=OLD16_CONTENT_SHA256, prior_assignment_count=len(old_signatures),
                               checked_alt1_assignment_count=len(new_signatures), overlap_count=len(overlap),
                               prior_signatures=[dict(datatype=dt, roles_sha256=sha) for dt, sha in OLD16_SIGNATURES]))


def _fixture(name, expected_sha256):
    raw = (CONFIG_DIR / name).read_bytes()
    _require(hashlib.sha256(raw).hexdigest() == expected_sha256, f"Packaged fixture changed: {name}")
    return json.loads(raw)


# Closed fixtures replace all reads of external historical worktrees.
SMOKE_EXCLUSIONS_FILE_SHA256 = "dbb6123801cc22cf68ddd71ad7565af284f873d9d0b4139a3a948bac9ccc993a"
_smoke = _fixture("smoke_exclusions.json", SMOKE_EXCLUSIONS_FILE_SHA256)
_hashed(_smoke, "content_sha256", "smoke exclusions")
OLD16_SOURCE = _smoke["source"]
OLD16_FILE_SHA256 = _smoke["source_file_sha256"]
OLD16_CONTENT_SHA256 = _smoke["source_content_sha256"]
OLD16_SIGNATURES = [(s["datatype"], s["roles_sha256"]) for s in _smoke["signatures"]]
_require(len(OLD16_SIGNATURES) == len(set(OLD16_SIGNATURES)) == 16, "16 smoke exclusions required")
GOAL_HEADS_FILE_SHA256 = "6b7c52d21a3cfc75c718a6c618e8f02f15a3372d00434497fbf427923978a96b"
GOAL_HEADS = _fixture("goal250.json", GOAL_HEADS_FILE_SHA256)
