"""Standalone, inference-only Qwen2 projection and headwise KV transfers.

Adapted from the customer-owned ``vendor/functional_original.py``. Requires
HF Qwen2 eager attention, ``model.model.layers`` and ``model.model.rotary_emb``.
The caller owns eval mode and gradient/inference mode (capture uses no_grad).
KV spans assume unpadded, zero-based absolute positions and a full-context cache;
sliding-window caches, custom position IDs and concurrent use are unsupported.
"""

from collections import defaultdict
from contextlib import contextmanager
import importlib
from operator import index
import types

import torch

__all__ = ["capture", "query_patch", "kv_patch"]


def _attention(model, layer):
    if not 0 <= layer < len(model.model.layers):
        raise ValueError(f"Invalid layer {layer}")
    return model.model.layers[layer].self_attn


def _headmap(model, heads):
    grouped = defaultdict(set)
    for layer, head in heads:
        layer, head = index(layer), index(head)
        attn = _attention(model, layer)
        if not 0 <= head < attn.q_proj.out_features // attn.head_dim:
            raise ValueError(f"Invalid query head {(layer, head)}")
        grouped[layer].add(head)
    return {layer: sorted(hs) for layer, hs in grouped.items()}


def _positions(positions):
    result = tuple(index(p) for p in positions)
    if len(set(result)) != len(result):
        raise ValueError("Positions must be unique")
    return result


def _local_positions(positions, length):
    return [(row, p if p >= 0 else length + p)
            for row, p in enumerate(positions) if -length <= p < length]


def _check_cache(cache, layer, rows, width):
    if layer not in cache or tuple(cache[layer].shape) != (rows, width):
        raise ValueError(f"Cache layer {layer} must have shape {(rows, width)}")


def capture(model, inputs, layers, positions, which):
    """Capture raw q/k/v projection rows, before RoPE, as detached CPU float32.

    Inputs are model keyword arguments for a single example; positions index
    the current input sequence. Unlike patch hooks, absent positions are errors.
    No generation cache is created or consumed by this helper.
    """
    if which not in ("q", "k", "v"):
        raise ValueError("which must be 'q', 'k' or 'v'")
    positions = _positions(positions)
    layers = sorted(set(index(layer) for layer in layers))
    if inputs.get("past_key_values") is not None:
        raise ValueError("capture expects a full input, without past_key_values")
    result, handles = {}, []
    try:
        for layer in layers:
            projection = getattr(_attention(model, layer), f"{which}_proj")

            def hook(module, args, output, layer=layer):
                if output.shape[0] != 1:
                    raise ValueError("capture requires batch size one")
                kept = _local_positions(positions, output.shape[1])
                if len(kept) != len(positions):
                    raise ValueError("Capture position outside input sequence")
                result[layer] = output[0, [p for _, p in kept]].detach().float().cpu().clone()

            handles.append(projection.register_forward_hook(hook))
        with torch.no_grad():
            model(**{**inputs, "use_cache": False})
    finally:
        for handle in handles:
            handle.remove()
    return result


@contextmanager
def query_patch(model, cache, heads, positions=(-1,)):
    """Replace selected query-head slices at raw q_proj output, before RoPE.

    Cache row r maps to positions[r] on each forward; absent positive positions
    are skipped on decode. Default -1 patches the final token on every forward.
    Donor rows broadcast across recipient batch examples.
    """
    positions = _positions(positions)
    headmap = _headmap(model, heads)
    handles = []
    try:
        for layer, hs in headmap.items():
            attn = _attention(model, layer)
            _check_cache(cache, layer, len(positions), attn.q_proj.out_features)

            def hook(module, args, output, hs=hs, hd=attn.head_dim, source=cache[layer]):
                kept = _local_positions(positions, output.shape[1])
                if not kept:
                    return output
                patched = output.clone()
                donor = source.to(device=output.device, dtype=output.dtype)
                for head in hs:
                    sl = slice(head * hd, (head + 1) * hd)
                    for row, pos in kept:
                        patched[:, pos, sl] = donor[row, sl]
                return patched

            handles.append(attn.q_proj.register_forward_hook(hook))
        yield
    finally:
        for handle in handles:
            handle.remove()


def _headwise_forward(attn, state):
    native = importlib.import_module(type(attn).__module__)

    def forward(self, hidden_states, position_embeddings, attention_mask,
                past_key_values=None, **kwargs):
        if self.training:
            raise ValueError("kv_patch requires model.eval()")
        shape = hidden_states.shape[:-1]
        head_shape = (*shape, -1, self.head_dim)
        # Call the modules, not F.linear: query_patch and observation hooks must fire.
        q = self.q_proj(hidden_states).view(head_shape).transpose(1, 2)
        k = self.k_proj(hidden_states).view(head_shape).transpose(1, 2)
        v = self.v_proj(hidden_states).view(head_shape).transpose(1, 2)
        q, k = native.apply_rotary_pos_emb(q, k, *position_embeddings)
        if past_key_values is not None:
            # HF 5.18: update accepts exactly these three arguments. Never write
            # donor KV to cache: the cache stores the actual recipient trajectory.
            k, v = past_key_values.update(k, v, self.layer_idx)
        options = dict(kwargs)
        options.update(dropout=0.0, scaling=self.scaling,
                       sliding_window=getattr(self, "sliding_window", None))
        clean, clean_weights = native.eager_attention_forward(self, q, k, v, attention_mask, **options)
        del clean_weights
        span = state["span"]
        if span and max(span) >= k.shape[-2]:
            raise ValueError("KV destination span must already exist in the prefix")
        k2, v2 = k.clone(), v.clone()
        layer = self.layer_idx
        for kvhead, donor in state["src_k"][layer].items():
            k2[:, kvhead, span, :] = donor.to(device=k.device, dtype=k.dtype)
            v2[:, kvhead, span, :] = state["src_v"][layer][kvhead].to(device=v.device, dtype=v.dtype)
        transferred, transferred_weights = native.eager_attention_forward(self, q, k2, v2, attention_mask, **options)
        routed = clean.clone()
        hs = state["goal_qheads"][layer]
        routed[:, :, hs, :] = transferred[:, :, hs, :]
        state["forward_calls"][layer] += 1
        if state.get("observer") is not None:
            other_positions = [j for j in range(k.shape[-2]) if j not in span]
            expected_heads = sorted({h // self.num_key_value_groups for h in hs})
            assert sorted(state["src_k"][layer]) == expected_heads
            checks = {
                "nonspan_k_max_abs": float((k2[:, :, other_positions] - k[:, :, other_positions]).abs().max()),
                "nonspan_v_max_abs": float((v2[:, :, other_positions] - v[:, :, other_positions]).abs().max()),
                "donor_k_max_abs": max(float((k2[0,h,span] - state["src_k"][layer][h]).abs().max()) for h in expected_heads),
                "donor_v_max_abs": max(float((v2[0,h,span] - state["src_v"][layer][h]).abs().max()) for h in expected_heads),
            }
            assert max(checks.values()) == 0
            state["kv_checks"][layer] = checks
            state["observer"](self, transferred_weights, v2, transferred, clean, routed)
        # Do not return clean attention weights for patched head outputs.
        return self.o_proj(routed.reshape(*shape, -1).contiguous()), None

    return forward


@contextmanager
def kv_patch(model, heads, k_cache, v_cache, dest_positions, observer=None):
    """Route donor KV to only the chosen QUERY heads, without GQA sibling bleed.

    k_cache/v_cache contain raw k_proj/v_proj rows from capture. Keys are rotated
    at fixed destination positions, values are not rotated. Routing is reapplied
    on every prefill/decode forward while this context is active. The native
    cache always holds untransplanted KV of the *intervened trajectory*, not an
    independent baseline run. Attention weights are intentionally omitted.

    Optional observer receives effective attention, values and routing outputs without modifying them.

    Yields state with span, goal_qheads, src_k/src_v (rotated per KV head), and
    per-layer forward_calls. Does not retain full attention matrices/activations.
    """
    headmap = _headmap(model, heads)
    span = list(_positions(dest_positions))
    if any(p < 0 for p in span):
        raise ValueError("KV destinations must be nonnegative absolute positions")
    state = {"observer": observer, "kv_checks": {}, "span": span, "goal_qheads": headmap, "src_k": {}, "src_v": {},
             "forward_calls": {layer: 0 for layer in headmap}}
    if not headmap or not span:
        yield state
        return
    originals = []
    try:
        for layer, hs in headmap.items():
            attn = _attention(model, layer)
            if getattr(attn, "sliding_window", None) is not None:
                raise ValueError("kv_patch supports full-context attention only")
            hd = attn.head_dim
            nq, nkv = attn.q_proj.out_features // hd, attn.k_proj.out_features // hd
            if nq % nkv:
                raise ValueError("Query head count must be divisible by KV head count")
            _check_cache(k_cache, layer, len(span), attn.k_proj.out_features)
            _check_cache(v_cache, layer, len(span), attn.v_proj.out_features)
            native = importlib.import_module(type(attn).__module__)
            ref = attn.q_proj.weight
            pos = torch.tensor([span], device=ref.device, dtype=torch.long)
            dummy = ref.new_zeros(1, len(span), hd)
            with torch.no_grad():
                cos, sin = model.model.rotary_emb(dummy, pos)
                cos, sin = cos.to(ref.device), sin.to(ref.device)
                keys, values = {}, {}
                for kvhead in sorted({h // (nq // nkv) for h in hs}):
                    sl = slice(kvhead * hd, (kvhead + 1) * hd)
                    raw = k_cache[layer][:, sl].to(ref.device, ref.dtype)[None, None]
                    _, rotated = native.apply_rotary_pos_emb(torch.zeros_like(raw), raw, cos, sin)
                    keys[kvhead] = rotated[0, 0].detach()
                    values[kvhead] = v_cache[layer][:, sl].to(ref.device, ref.dtype).detach().clone()
            state["src_k"][layer], state["src_v"][layer] = keys, values
            # Preserve instance-level overrides as well as ordinary class methods.
            originals.append((attn, attn.__dict__.get("forward"), "forward" in attn.__dict__))
            attn.forward = types.MethodType(_headwise_forward(attn, state), attn)
        yield state
    finally:
        for attn, original, had_override in reversed(originals):
            if had_override:
                attn.forward = original
            else:
                del attn.forward
