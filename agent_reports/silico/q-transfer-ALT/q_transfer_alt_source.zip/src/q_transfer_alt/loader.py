"""Read and validate a frozen or regenerated panel without importing the bank."""
from pathlib import Path
import json

from .validate_panel import validate_panel


def load_panel(path):
    """Return the decoded panel after integrity/design validation.

    Invalid panel records raise ValueError; ordinary filesystem errors propagate.
    No task expressions or reference functions from the file are executed.
    """
    panel = json.loads(Path(path).read_text(encoding="utf-8"))
    validate_panel(panel)
    return panel
