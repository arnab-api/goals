"""Deterministic task selection with explicit, never-relaxed family policy."""
from collections import Counter, defaultdict
from math import factorial
import random
from .task import DOMAINS, digest


class InfeasibleSampling(ValueError):
    pass


def pool_for(registry, datatype, candidate_ids=None):
    if datatype not in DOMAINS:
        raise ValueError(f"Unknown datatype: {datatype}")
    if candidate_ids is None:
        return [t for t in registry.tasks if t.datatype == datatype]
    if len(set(candidate_ids)) != len(candidate_ids):
        raise ValueError("Duplicate candidate IDs")
    tasks = [registry.get(i) for i in candidate_ids]
    if any(t.datatype != datatype for t in tasks):
        raise ValueError("Candidate datatype mismatch")
    return sorted(tasks, key=lambda t: t.id)


def assignment_space(pool, role_count, family_policy):
    if family_policy not in ("distinct", "any"):
        raise ValueError(f"Unknown family policy: {family_policy}")
    if any(t.incompatible_ids for t in pool):
        raise ValueError("Exact assignment counting supports only the shipped bank's family/ID policy; pair exclusions require a new counter")
    if role_count < 1:
        raise ValueError("role_count must be positive")
    counts = Counter(t.family for t in pool)
    if family_policy == "any":
        n = len(pool)
        count = factorial(n) // factorial(n - role_count) if n >= role_count else 0
        family_combinations = None
    else:
        dp, cp = [1] + [0] * role_count, [1] + [0] * role_count
        for n in counts.values():
            for k in range(role_count, 0, -1):
                dp[k] += n * dp[k - 1]
                cp[k] += cp[k - 1]
        count = factorial(role_count) * dp[role_count]
        family_combinations = cp[role_count]
    return {"role_count": role_count, "candidate_tasks": len(pool),
            "family_policy": family_policy, "family_counts": dict(sorted(counts.items())),
            "feasible_ordered_role_assignments": count,
            "feasible_unordered_family_sets": family_combinations,
            "count_method": "exact combinatorial count; task IDs distinct",
            "policy_note": "Family labels are a sampling policy, not mathematical independence."}


def validate_roles(registry, roles, required, datatype, family_policy):
    if family_policy not in ("distinct", "any"):
        raise ValueError(f"Unknown family policy: {family_policy}")
    if set(roles) != set(required):
        raise ValueError(f"Role keys must be exactly {list(required)}")
    tasks = [registry.get(roles[r]) for r in required]
    if any(t.datatype != datatype for t in tasks):
        raise ValueError("Role datatype mismatch")
    for i, a in enumerate(tasks):
        for b in tasks[i + 1:]:
            if not registry.compatible(a.id, b.id, family_policy):
                raise InfeasibleSampling(f"Incompatible roles: {a.id}, {b.id}; policy={family_policy}")


def sample_roles(registry, scenario, datatype, seed, family_policy="distinct", candidate_ids=None):
    pool = pool_for(registry, datatype, candidate_ids)
    space = assignment_space(pool, len(scenario.roles), family_policy)
    if space["feasible_ordered_role_assignments"] == 0:
        raise InfeasibleSampling(f"No feasible {len(scenario.roles)}-role assignment: {space}")
    rng = random.Random(seed)
    if family_policy == "any":
        chosen = rng.sample(pool, len(scenario.roles))
        method = "uniform task sampling without replacement using Python Random"
    else:
        groups = defaultdict(list)
        for t in pool:
            groups[t.family].append(t)
        families = rng.sample(sorted(groups), len(scenario.roles))
        chosen = [rng.choice(groups[f]) for f in families]
        method = "uniform distinct family sequence, then uniform task within family; NOT uniform over task assignments"
    roles = dict(zip(scenario.roles, (t.id for t in chosen)))
    validate_roles(registry, roles, scenario.roles, datatype, family_policy)
    ids = sorted(t.id for t in pool)
    return roles, {**space, "sampling_method": method, "rejections": [],
                   "candidate_ids": ids, "candidate_ids_sha256": digest(ids),
                   "excluded_by_datatype": len(registry.tasks) - sum(t.datatype == datatype for t in registry.tasks)}
