"""Bounded list tasks with loop-based independent references.

Families are curation-policy labels, not claims of mathematical independence.
Variants intentionally share families. Expressions are single assignment RHSs;
inputs follow the list domains declared in task.py. Unicode predicates use
Python's code-point semantics (no normalization or case folding).
"""
from .task import Task


def int_length(x):
    count = 0
    for _ in x:
        count += 1
    return count


def int_sum(x):
    total = 0
    for value in x:
        total += value
    return total


def int_abs_sum(x):
    total = 0
    for value in x:
        total += -value if value < 0 else value
    return total


def int_sum_squares(x):
    total = 0
    for value in x:
        total += value * value
    return total


def int_minimum(x):
    if not x:
        return 0
    result = x[0]
    for value in x:
        if value < result:
            result = value
    return result


def int_maximum(x):
    if not x:
        return 0
    result = x[0]
    for value in x:
        if value > result:
            result = value
    return result


def int_range(x):
    if not x:
        return 0
    low = high = x[0]
    for value in x:
        if value < low:
            low = value
        if value > high:
            high = value
    return high - low


def int_first(x):
    for value in x:
        return value
    return 0


def int_last(x):
    result = 0
    for value in x:
        result = value
    return result


def int_count_odd(x):
    count = 0
    for value in x:
        if value % 2 != 0:
            count += 1
    return count


def int_count_positive(x):
    count = 0
    for value in x:
        if value > 0:
            count += 1
    return count


def int_count_negative(x):
    count = 0
    for value in x:
        if value < 0:
            count += 1
    return count


def int_count_zero(x):
    count = 0
    for value in x:
        if value == 0:
            count += 1
    return count


def int_count_even(x):
    count = 0
    for value in x:
        if value % 2 == 0:
            count += 1
    return count


def int_distinct_count(x):
    seen = []
    for value in x:
        if value not in seen:
            seen.append(value)
    return len(seen)


def int_duplicate_count(x):
    seen = set()
    count = 0
    for value in x:
        if value in seen:
            count += 1
        else:
            seen.add(value)
    return count


def int_all_positive(x):
    for value in x:
        if value <= 0:
            return False
    return True


def int_any_negative(x):
    for value in x:
        if value < 0:
            return True
    return False


def int_nondecreasing(x):
    for index in range(1, len(x)):
        if x[index] < x[index - 1]:
            return False
    return True


def int_palindrome(x):
    left, right = 0, len(x) - 1
    while left < right:
        if x[left] != x[right]:
            return False
        left += 1
        right -= 1
    return True


def int_equal_adjacent(x):
    count = 0
    previous = None
    for value in x:
        if value == previous:
            count += 1
        previous = value
    return count


def int_sign_changes(x):
    count = 0
    for index in range(1, len(x)):
        before, after = x[index - 1], x[index]
        if (before < 0 and after > 0) or (before > 0 and after < 0):
            count += 1
    return count


def int_reverse(x):
    result = []
    for value in x:
        result.insert(0, value)
    return result


def int_sorted(x):
    result = []
    for value in x:
        index = 0
        while index < len(result) and result[index] <= value:
            index += 1
        result.insert(index, value)
    return result


def int_sorted_desc(x):
    result = []
    for value in x:
        index = 0
        while index < len(result) and result[index] >= value:
            index += 1
        result.insert(index, value)
    return result


def int_unique_sorted(x):
    result = []
    for value in x:
        if value in result:
            continue
        index = 0
        while index < len(result) and result[index] < value:
            index += 1
        result.insert(index, value)
    return result


def int_positive_values(x):
    result = []
    for value in x:
        if value > 0:
            result.append(value)
    return result


def int_absolute_values(x):
    result = []
    for value in x:
        result.append(-value if value < 0 else value)
    return result


def int_squares(x):
    result = []
    for value in x:
        result.append(value * value)
    return result


def int_prefix_sums(x):
    result = []
    total = 0
    for value in x:
        total += value
        result.append(total)
    return result


def int_rotate_left(x):
    result = []
    for index, value in enumerate(x):
        if index:
            result.append(value)
    if x:
        result.append(x[0])
    return result


def int_even_positions(x):
    result = []
    for index, value in enumerate(x):
        if index % 2 == 0:
            result.append(value)
    return result


def words_all_nonempty(x):
    for word in x:
        if len(word) == 0:
            return False
    return True


def words_lexical_min(x):
    if not x:
        return ''
    best = x[0]
    for word in x:
        if word < best:
            best = word
    return best


def words_anagram_groups(x):
    # Character-frequency dictionaries avoid the expression's sorting algorithm.
    signatures = []
    for word in x:
        counts = {}
        for character in word:
            counts[character] = counts.get(character, 0) + 1
        if counts not in signatures:
            signatures.append(counts)
    return len(signatures)


def words_total_chars(x):
    total = 0
    for word in x:
        for _ in word:
            total += 1
    return total


def words_initials(x):
    result = ''
    for word in x:
        for character in word:
            result += character
            break
    return result


def words_equal_adjacent(x):
    count = 0
    previous = None
    for word in x:
        if word == previous:
            count += 1
        previous = word
    return count


def words_uppercase_chars(x):
    count = 0
    for word in x:
        for character in word:
            if character.isupper():
                count += 1
    return count


def words_distinct_chars(x):
    characters = []
    for word in x:
        for character in word:
            if character not in characters:
                characters.append(character)
    return len(characters)


def words_palindrome(x):
    for index in range(len(x) // 2):
        if x[index] != x[len(x) - 1 - index]:
            return False
    return True


def words_length(x):
    count = 0
    for _ in x:
        count += 1
    return count


def words_nonempty_count(x):
    count = 0
    for word in x:
        if word != '':
            count += 1
    return count


def words_empty_count(x):
    count = 0
    for word in x:
        if len(word) == 0:
            count += 1
    return count


def words_max_length(x):
    best = 0
    for word in x:
        if len(word) > best:
            best = len(word)
    return best


def words_min_length(x):
    if not x:
        return 0
    best = len(x[0])
    for word in x:
        if len(word) < best:
            best = len(word)
    return best


def words_lexical_max(x):
    best = ''
    for word in x:
        if word > best:
            best = word
    return best


def words_longest_word(x):
    best = ''
    for word in x:
        if len(word) > len(best):
            best = word
    return best


def words_shortest_word(x):
    if not x:
        return ''
    best = x[0]
    for word in x:
        if len(word) < len(best):
            best = word
    return best


def words_all_alpha(x):
    for word in x:
        if not word.isalpha():
            return False
    return True


def words_any_empty(x):
    for word in x:
        if len(word) == 0:
            return True
    return False


def words_sorted(x):
    result = []
    for word in x:
        index = 0
        while index < len(result) and result[index] <= word:
            index += 1
        result.insert(index, word)
    return result


def words_reversed(x):
    result = []
    for word in x:
        result.insert(0, word)
    return result


def words_nonempty(x):
    result = []
    for word in x:
        if len(word) > 0:
            result.append(word)
    return result


def words_lowercase(x):
    result = []
    for word in x:
        result.append(word.lower())
    return result


def words_uppercase(x):
    result = []
    for word in x:
        result.append(word.upper())
    return result


def words_lengths(x):
    result = []
    for word in x:
        count = 0
        for _ in word:
            count += 1
        result.append(count)
    return result


def words_first(x):
    for word in x:
        return word
    return ''


def words_last(x):
    result = ''
    for word in x:
        result = word
    return result


def words_joined(x):
    result = ''
    for index, word in enumerate(x):
        if index:
            result += ' '
        result += word
    return result


def words_digit_chars(x):
    count = 0
    for word in x:
        for character in word:
            if character.isdigit():
                count += 1
    return count


def words_whitespace_chars(x):
    count = 0
    for word in x:
        for character in word:
            if character.isspace():
                count += 1
    return count


def words_unique_count(x):
    seen = []
    for word in x:
        if word not in seen:
            seen.append(word)
    return len(seen)


def words_unique_sorted(x):
    result = []
    for word in x:
        if word in result:
            continue
        index = 0
        while index < len(result) and result[index] < word:
            index += 1
        result.insert(index, word)
    return result


# Family names are policy groupings, including across input datatypes.
TASKS = [
    Task('py.list_int.length.v1', 'list[int]', 'Number of items.', 'int', 'cardinality', 'len(x)', int_length),
    Task('py.list_int.sum.v1', 'list[int]', 'Sum of items; zero for empty input.', 'int', 'numeric_aggregation', 'sum(x)', int_sum),
    Task('py.list_int.abs_sum.v1', 'list[int]', 'Sum of absolute values.', 'int', 'numeric_aggregation', 'sum(abs(v) for v in x)', int_abs_sum),
    Task('py.list_int.sum_squares.v1', 'list[int]', 'Sum of squared values.', 'int', 'numeric_aggregation', 'sum(v ** 2 for v in x)', int_sum_squares),
    Task('py.list_int.minimum.v1', 'list[int]', 'Minimum value; zero for empty input.', 'int', 'numeric_extrema', 'min(x, default=0)', int_minimum),
    Task('py.list_int.maximum.v1', 'list[int]', 'Maximum value; zero for empty input.', 'int', 'numeric_extrema', 'max(x, default=0)', int_maximum),
    Task('py.list_int.range.v1', 'list[int]', 'Maximum minus minimum; zero for empty input.', 'int', 'numeric_extrema', 'max(x, default=0) - min(x, default=0)', int_range),
    Task('py.list_int.first.v1', 'list[int]', 'First value; zero for empty input.', 'int', 'positional_selection', 'x[0] if x else 0', int_first),
    Task('py.list_int.last.v1', 'list[int]', 'Last value; zero for empty input.', 'int', 'positional_selection', 'x[-1] if x else 0', int_last),
    Task('py.list_int.count_odd.v1', 'list[int]', 'Number of odd values.', 'int', 'value_classification', 'sum(v % 2 != 0 for v in x)', int_count_odd),
    Task('py.list_int.count_positive.v1', 'list[int]', 'Number of strictly positive values.', 'int', 'value_classification', 'sum(v > 0 for v in x)', int_count_positive),
    Task('py.list_int.count_negative.v1', 'list[int]', 'Number of strictly negative values.', 'int', 'value_classification', 'sum(v < 0 for v in x)', int_count_negative),
    Task('py.list_int.count_zero.v1', 'list[int]', 'Number of zero values.', 'int', 'value_classification', 'x.count(0)', int_count_zero),
    Task('py.list_int.count_even.v1', 'list[int]', 'Number of even values, including zero.', 'int', 'value_classification', 'sum(v % 2 == 0 for v in x)', int_count_even),
    Task('py.list_int.distinct_count.v1', 'list[int]', 'Number of distinct values.', 'int', 'value_diversity', 'len(set(x))', int_distinct_count),
    Task('py.list_int.duplicate_count.v1', 'list[int]', 'Number of occurrences beyond each distinct value first occurrence.', 'int', 'value_diversity', 'len(x) - len(set(x))', int_duplicate_count),
    Task('py.list_int.all_positive.v1', 'list[int]', 'Whether every value is strictly positive; true for empty input.', 'bool', 'quantification', 'all(v > 0 for v in x)', int_all_positive),
    Task('py.list_int.any_negative.v1', 'list[int]', 'Whether any value is negative.', 'bool', 'quantification', 'any(v < 0 for v in x)', int_any_negative),
    Task('py.list_int.nondecreasing.v1', 'list[int]', 'Whether values are in nondecreasing order.', 'bool', 'ordering', 'x == sorted(x)', int_nondecreasing),
    Task('py.list_int.palindrome.v1', 'list[int]', 'Whether the value sequence is an exact palindrome.', 'bool', 'symmetry', 'x == x[::-1]', int_palindrome),
    Task('py.list_int.equal_adjacent.v1', 'list[int]', 'Number of equal adjacent pairs.', 'int', 'adjacency', 'sum(a == b for a, b in zip(x, x[1:]))', int_equal_adjacent),
    Task('py.list_int.sign_changes.v1', 'list[int]', 'Number of adjacent pairs of strictly opposite signs; zero does not bridge signs.', 'int', 'adjacency', 'sum(a * b < 0 for a, b in zip(x, x[1:]))', int_sign_changes),
    Task('py.list_int.reverse.v1', 'list[int]', 'Values in reverse input order.', 'list[int]', 'positional_transform', 'x[::-1]', int_reverse),
    Task('py.list_int.sorted.v1', 'list[int]', 'Values sorted in ascending order.', 'list[int]', 'ordering', 'sorted(x)', int_sorted),
    Task('py.list_int.sorted_desc.v1', 'list[int]', 'Values sorted in descending order.', 'list[int]', 'ordering', 'sorted(x, reverse=True)', int_sorted_desc),
    Task('py.list_int.unique_sorted.v1', 'list[int]', 'Distinct values sorted in ascending order.', 'list[int]', 'value_diversity', 'sorted(set(x))', int_unique_sorted),
    Task('py.list_int.positive_values.v1', 'list[int]', 'Strictly positive values in input order.', 'list[int]', 'filtering', '[v for v in x if v > 0]', int_positive_values),
    Task('py.list_int.absolute_values.v1', 'list[int]', 'Absolute values in input order.', 'list[int]', 'elementwise_transform', '[abs(v) for v in x]', int_absolute_values),
    Task('py.list_int.squares.v1', 'list[int]', 'Squared values in input order.', 'list[int]', 'elementwise_transform', '[v ** 2 for v in x]', int_squares),
    Task('py.list_int.prefix_sums.v1', 'list[int]', 'Inclusive running totals in input order.', 'list[int]', 'prefix_aggregation', '[sum(x[:i + 1]) for i in range(len(x))]', int_prefix_sums),
    Task('py.list_int.rotate_left.v1', 'list[int]', 'Move the first value to the end; empty input remains empty.', 'list[int]', 'positional_transform', 'x[1:] + x[:1]', int_rotate_left),
    Task('py.list_int.even_positions.v1', 'list[int]', 'Values at zero-based even positions.', 'list[int]', 'positional_selection', 'x[::2]', int_even_positions),
    Task('py.list_str.all_nonempty.v1', 'list[str]', 'Whether all words are nonempty; true for empty input.', 'bool', 'quantification', 'all(x)', words_all_nonempty),
    Task('py.list_str.lexical_min.v1', 'list[str]', 'Lexically smallest word; empty string for empty input.', 'str', 'lexical_extrema', "min(x, default='')", words_lexical_min),
    Task('py.list_str.anagram_groups.v1', 'list[str]', 'Number of distinct case-sensitive sorted-character signatures.', 'int', 'anagram_classes', 'len({tuple(sorted(word)) for word in x})', words_anagram_groups),
    Task('py.list_str.total_chars.v1', 'list[str]', 'Total number of Unicode code points across all words.', 'int', 'length_aggregation', 'sum(map(len, x))', words_total_chars),
    Task('py.list_str.initials.v1', 'list[str]', 'Concatenate the first character of each nonempty word.', 'str', 'positional_transform', "''.join(word[0] for word in x if word)", words_initials),
    Task('py.list_str.equal_adjacent.v1', 'list[str]', 'Number of equal adjacent word pairs.', 'int', 'adjacency', 'sum(a == b for a, b in zip(x, x[1:]))', words_equal_adjacent),
    Task('py.list_str.uppercase_chars.v1', 'list[str]', 'Total number of Unicode characters satisfying isupper.', 'int', 'character_classification', 'sum(c.isupper() for word in x for c in word)', words_uppercase_chars),
    Task('py.list_str.distinct_chars.v1', 'list[str]', 'Number of distinct Unicode code points across all words.', 'int', 'character_diversity', "len(set(''.join(x)))", words_distinct_chars),
    Task('py.list_str.palindrome.v1', 'list[str]', 'Whether the exact word sequence is a palindrome.', 'bool', 'symmetry', 'x == x[::-1]', words_palindrome),
    Task('py.list_str.length.v1', 'list[str]', 'Number of words, including empty strings.', 'int', 'cardinality', 'len(x)', words_length),
    Task('py.list_str.nonempty_count.v1', 'list[str]', 'Number of nonempty words.', 'int', 'value_classification', 'sum(bool(word) for word in x)', words_nonempty_count),
    Task('py.list_str.empty_count.v1', 'list[str]', 'Number of empty words.', 'int', 'value_classification', "x.count('')", words_empty_count),
    Task('py.list_str.max_length.v1', 'list[str]', 'Largest word length; zero for empty input.', 'int', 'length_aggregation', 'max(map(len, x), default=0)', words_max_length),
    Task('py.list_str.min_length.v1', 'list[str]', 'Smallest word length; zero for empty input.', 'int', 'length_aggregation', 'min(map(len, x), default=0)', words_min_length),
    Task('py.list_str.lexical_max.v1', 'list[str]', 'Lexically largest word; empty string for empty input.', 'str', 'lexical_extrema', "max(x, default='')", words_lexical_max),
    Task('py.list_str.longest_word.v1', 'list[str]', 'First longest word in input order; empty string for empty input.', 'str', 'length_aggregation', "max(x, key=len, default='')", words_longest_word),
    Task('py.list_str.shortest_word.v1', 'list[str]', 'First shortest word in input order; empty string for empty input.', 'str', 'length_aggregation', "min(x, key=len, default='')", words_shortest_word),
    Task('py.list_str.all_alpha.v1', 'list[str]', 'Whether every word is nonempty and Unicode alphabetic; true for empty input.', 'bool', 'quantification', 'all(word.isalpha() for word in x)', words_all_alpha),
    Task('py.list_str.any_empty.v1', 'list[str]', 'Whether any word is empty.', 'bool', 'quantification', 'any(not word for word in x)', words_any_empty),
    Task('py.list_str.sorted_words.v1', 'list[str]', 'Words in ascending Unicode lexical order.', 'list[str]', 'ordering', 'sorted(x)', words_sorted),
    Task('py.list_str.reversed_words.v1', 'list[str]', 'Words in reverse input order.', 'list[str]', 'positional_transform', 'x[::-1]', words_reversed),
    Task('py.list_str.nonempty_words.v1', 'list[str]', 'Nonempty words in input order.', 'list[str]', 'filtering', '[word for word in x if word]', words_nonempty),
    Task('py.list_str.lowercase_words.v1', 'list[str]', 'Apply Unicode lower to each whole word in input order.', 'list[str]', 'elementwise_transform', '[word.lower() for word in x]', words_lowercase),
    Task('py.list_str.uppercase_words.v1', 'list[str]', 'Apply Unicode upper to each whole word in input order.', 'list[str]', 'elementwise_transform', '[word.upper() for word in x]', words_uppercase),
    Task('py.list_str.lengths.v1', 'list[str]', 'Unicode code-point length of each word in input order.', 'list[int]', 'length_aggregation', '[len(word) for word in x]', words_lengths),
    Task('py.list_str.first_word.v1', 'list[str]', 'First word; empty string for empty input.', 'str', 'positional_selection', "x[0] if x else ''", words_first),
    Task('py.list_str.last_word.v1', 'list[str]', 'Last word; empty string for empty input.', 'str', 'positional_selection', "x[-1] if x else ''", words_last),
    Task('py.list_str.joined.v1', 'list[str]', 'Join words with one space between successive words.', 'str', 'sequence_join', "' '.join(x)", words_joined),
    Task('py.list_str.digit_chars.v1', 'list[str]', 'Total number of Unicode characters satisfying isdigit.', 'int', 'character_classification', 'sum(c.isdigit() for word in x for c in word)', words_digit_chars),
    Task('py.list_str.whitespace_chars.v1', 'list[str]', 'Total number of Unicode characters satisfying isspace.', 'int', 'character_classification', 'sum(c.isspace() for word in x for c in word)', words_whitespace_chars),
    Task('py.list_str.unique_words_count.v1', 'list[str]', 'Number of distinct exact words.', 'int', 'value_diversity', 'len(set(x))', words_unique_count),
    Task('py.list_str.unique_words_sorted.v1', 'list[str]', 'Distinct exact words in ascending Unicode lexical order.', 'list[str]', 'value_diversity', 'sorted(set(x))', words_unique_sorted),
]
