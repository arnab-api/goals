"""Model-free exact prompt components. Explicit written order is never re-sorted."""
import random
import hashlib
from .task import digest

RENDERER_VERSION = "1.0.0"
PHRASES = {"int": "an integer", "str": "a string", "list[int]": "a list of integers", "list[str]": "a list of strings"}
NAME_POOL = ("u", "v", "w", "t", "q", "r", "s", "j", "k", "m", "n", "h")


def opaque_names(roles, seed):
    names = list(NAME_POOL)
    random.Random("diff-expanded-names-v1:" + str(seed)).shuffle(names)
    keys = sorted(roles) + ["pending"]
    if len(keys) > len(names):
        raise ValueError("Opaque name pool exhausted")
    return dict(zip(keys, names))


def render_prompt(registry, roles, names, datatype, layout):
    layout.validate()
    if len(set(names.values())) != len(names) or "x" in names.values():
        raise ValueError("Result names must be distinct from each other and input x")
    if set(names) != set(roles) | {"pending"}:
        raise ValueError("Names must cover all roles and pending")
    if any(n not in NAME_POOL for n in names.values()):
        raise ValueError("Names must be opaque members of NAME_POOL")
    tasks = [registry.get(roles[r]) for r in layout.listed]
    head = f"Write a Python program that implements a function `func` which, given {PHRASES[datatype]} `x`, computes:\n"
    task_list = "\n".join(f"({i + 1}) {t.description}" for i, t in enumerate(tasks))
    question = head + task_list + "\n"
    signature = f"def func(x: {datatype}):"
    assignments = [{"role": r, "task_id": roles[r], "variable": names[r],
                    "text": f"    {names[r]} = {registry.get(roles[r]).expression}"} for r in layout.written]
    pivot = f"    {names['pending']} ="
    prefill = "\n".join(["<code>", signature] + [a["text"] for a in assignments] + [pivot])
    text = question + prefill
    descriptions = []
    cursor = len(head)
    for i, (r, t) in enumerate(zip(layout.listed, tasks)):
        start = cursor + len(f"({i + 1}) ")
        end = start + len(t.description)
        descriptions.append({"role": r, "task_id": t.id, "start": start, "end": end, "text": t.description})
        cursor = end + 1
    record = {**layout.record(), "question": question, "prefill": prefill, "text": text,
              "text_format": "question immediately followed by assistant code prefill; chat template deferred to runtime",
              "task_list_text": task_list, "task_list_span": [len(head), len(head) + len(task_list)],
              "span_unit": "Python Unicode code-point indices; end exclusive, relative to text",
              "description_spans": descriptions, "supplied_assignments": assignments,
              "unfinished_variable": names["pending"], "pivot": pivot,
              "frontier_task_id": roles[layout.frontier], "text_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest()}
    record["components_sha256"] = digest(record)
    return record
