"""Strict opt-in registry, bounded validation and typed functional signatures."""
import ast
from collections import Counter
import re
from .task import DOMAINS, BANK_VERSION, digest, typed, output_matches
from .cases import cases, SUITE_VERSION


class Registry:
    def __init__(self, tasks=None):
        if tasks is None:
            from .bank_scalar import TASKS as scalar
            from .bank_lists import TASKS as lists
            tasks = scalar + lists
        self.tasks = tuple(sorted(tasks, key=lambda t: t.id))
        self.by_id = {}
        for t in self.tasks:
            if t.id in self.by_id:
                raise ValueError(f"Duplicate task ID: {t.id}")
            self.by_id[t.id] = t

    def get(self, task_id):
        try:
            return self.by_id[task_id]
        except KeyError:
            raise ValueError(f"Unknown predicate ID: {task_id}") from None

    def compatible(self, left, right, family_policy="distinct"):
        a, b = self.get(left), self.get(right)  # unknowns must never default to True
        if family_policy not in ("distinct", "any"):
            raise ValueError(f"Unknown family policy: {family_policy}")
        return (a.id != b.id and a.datatype == b.datatype and
                b.id not in a.incompatible_ids and a.id not in b.incompatible_ids and
                (family_policy == "any" or a.family != b.family))

    def records(self):
        return [t.record() for t in self.tasks]

    @property
    def sha256(self):
        return digest({"version": BANK_VERSION, "definitions": self.records()})

    def validate(self):
        suite = cases()
        signatures, descriptions = {}, set()
        comparisons = 0
        for t in self.tasks:
            if not re.fullmatch(r"py\.[a-z_]+\.[a-z_0-9]+\.v[1-9][0-9]*", t.id):
                raise ValueError(f"Unversioned/invalid ID: {t.id}")
            if t.datatype not in DOMAINS or not t.family or not t.description.strip():
                raise ValueError(f"Incomplete metadata: {t.id}")
            key = (t.datatype, t.description.casefold().strip())
            if key in descriptions:
                raise ValueError(f"Duplicate description: {t.id}")
            descriptions.add(key)
            for other in t.incompatible_ids:
                self.get(other)
            if "\n" in t.expression or ";" in t.expression:
                raise ValueError(f"Expression is not one line: {t.id}")
            tree = ast.parse(t.expression, mode="eval")
            if any(isinstance(n, (ast.Lambda, ast.NamedExpr)) or
                   isinstance(n, ast.Attribute) and n.attr.startswith("_") or
                   isinstance(n, ast.Name) and n.id.startswith("_") for n in ast.walk(tree)):
                raise ValueError(f"Disallowed expression: {t.id}")
            values = []
            for x in suite[t.datatype]:
                actual, expected = t.evaluate(x), t.reference(x)
                if not output_matches(t.output_type, actual) or not output_matches(t.output_type, expected):
                    raise ValueError(f"Wrong output type: {t.id} on {x!r}")
                if typed(actual) != typed(expected):
                    raise ValueError(f"Reference mismatch: {t.id} on {x!r}: {actual!r} != {expected!r}")
                values.append(typed(actual))
                comparisons += 1
            signature = digest(values)
            key = (t.datatype, signature)
            if key in signatures:
                raise ValueError(f"Duplicate functional signature: {t.id} and {signatures[key]}")
            signatures[key] = t.id
        return {"bank_version": BANK_VERSION, "bank_sha256": self.sha256,
                "suite_version": SUITE_VERSION, "suite_sha256": digest(suite),
                "case_counts": {k: len(v) for k, v in suite.items()},
                "task_counts": dict(Counter(t.datatype for t in self.tasks)),
                "families": {d: dict(sorted(Counter(t.family for t in self.tasks if t.datatype == d).items())) for d in DOMAINS},
                "expression_reference_comparisons": comparisons,
                "signature_count": len(signatures), "rejected": [],
                "limitation": "No duplicate typed signatures on this finite suite; this does not prove functional inequivalence."}
