"""Deterministic versioned manifests and the preferred nine-role example."""
from pathlib import Path
import sys
from .cases import cases, SUITE_VERSION
from .registry import Registry
from .render import render_prompt, opaque_names, RENDERER_VERSION
from .sampling import sample_roles, validate_roles, pool_for, assignment_space
from .scenarios import get_scenario
from .task import BANK_VERSION, DOMAINS, digest, typed

PREFERRED = dict(zip("abcdefxyz", ["py.list_str." + s + ".v1" for s in
    ("all_nonempty", "lexical_min", "anagram_groups", "total_chars", "initials", "equal_adjacent", "uppercase_chars", "distinct_chars", "palindrome")]))
EXAMPLE_INPUT = ["Tea", "eat", "ate", "", "ABC", "ABC", "x", ""]
BASE_REVISION = "7ef5101a7a1e28acbc70f0c4f8bf2d73aca6fde7"


def implementation_hash():
    here = Path(__file__).parent
    return digest({p.name: p.read_text() for p in sorted(here.glob("*.py"))})


def build(scenario_id="ALT2_KV", datatype="list[str]", seed=73, family_policy="distinct", preferred=False, candidate_ids=None):
    registry = Registry()
    validation = registry.validate()
    scenario = get_scenario(scenario_id)
    if preferred:
        if scenario_id != "ALT2_KV" or datatype != "list[str]" or candidate_ids is not None:
            raise ValueError("Preferred example requires ALT2_KV, list[str], and the full candidate pool")
        roles = dict(PREFERRED)
        validate_roles(registry, roles, scenario.roles, datatype, family_policy)
        sampling = {**assignment_space(pool_for(registry, datatype), 9, family_policy),
                    "sampling_method": "fixed preferred illustrative role assignment (not a random draw)", "rejections": [], "substitutions": [],
                    "candidate_ids": sorted(t.id for t in pool_for(registry, datatype)),
                    "candidate_ids_sha256": digest(sorted(t.id for t in pool_for(registry, datatype)))}
    else:
        roles, sampling = sample_roles(registry, scenario, datatype, seed, family_policy, candidate_ids)
    names = opaque_names(scenario.roles, seed)
    layouts = {"p_src": scenario.src, "p_dst": scenario.dst}
    if scenario.kv:
        layouts["p_kv"] = scenario.kv
    prompts = {k: render_prompt(registry, roles, names, datatype, v) for k, v in layouts.items()}
    predictions = {k: {"role": r, "task_id": roles[r], "interpretation": "symbolic selector, not measured model behavior"} for k, r in scenario.predictions.items()}
    witnesses = []
    for i, a in enumerate(scenario.roles):
        for b in scenario.roles[i + 1:]:
            for value in cases()[datatype]:
                av, bv = typed(registry.get(roles[a]).reference(value)), typed(registry.get(roles[b]).reference(value))
                if av != bv:
                    witnesses.append({"roles": [a, b], "input": value, "outputs": [av, bv]})
                    break
            else:
                raise ValueError(f"No finite-suite distinguishing witness for {a}, {b}")
    result = {"schema_version": 1, "bank_version": BANK_VERSION, "bank_sha256": registry.sha256,
              "renderer_version": RENDERER_VERSION, "implementation_sha256": implementation_hash(),
              "scenario": scenario.record(), "seed": seed, "datatype": datatype,
              "input_domain": DOMAINS[datatype], "roles": roles, "opaque_names": names,
              "task_definitions": {r: registry.get(i).record() for r, i in roles.items()},
              "prompts": prompts, "predictions": predictions, "sampling": sampling,
              "coverage": {"tasks": len(roles), "families": sorted({registry.get(i).family for i in roles.values()})},
              "distinguishing_witnesses": witnesses, "suite_version": SUITE_VERSION,
              "validation": validation, "provenance": {"base_repository": "arnab-api/goals", "base_commit": BASE_REVISION,
                  "python_version": sys.version.split()[0], "model_generation_performed": False,
                  "tokenizer_alignment_verified": False},
              "runtime_cache_requirement": "Also key by tokenizer identity/revision, exact rendered token IDs, model revision and effective intervention config."}
    if datatype == "list[str]":
        result["illustrative_execution"] = {"input": EXAMPLE_INPUT, "outputs": {r: typed(registry.get(i).reference(EXAMPLE_INPUT)) for r, i in roles.items()}}
    result["content_sha256"] = digest(result)
    return result
