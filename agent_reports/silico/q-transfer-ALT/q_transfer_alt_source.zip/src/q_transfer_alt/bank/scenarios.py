"""Frozen layouts. Selectors identify tasks, not their numerical execution results."""
from dataclasses import dataclass
from .task import digest

SCENARIO_VERSION = "1.0.0"


@dataclass(frozen=True)
class Layout:
    listed: tuple
    written: tuple

    def validate(self):
        if len(self.listed) != 4 or len(set(self.listed)) != 4:
            raise ValueError("Exactly four distinct listed roles required")
        if len(set(self.written)) != len(self.written) or not set(self.written) < set(self.listed):
            raise ValueError("Written roles must be a distinct proper subset of listed roles")
        return self

    @property
    def frontier(self):
        return first_absent(self.listed, self.written)

    def record(self):
        self.validate()
        return {"listed_roles": list(self.listed), "written_roles": list(self.written),
                "completed_set": sorted(self.written), "frontier_role": self.frontier}


def first_absent(ordered, completed):
    return next((r for r in ordered if r not in set(completed)), None)


@dataclass(frozen=True)
class Scenario:
    id: str
    src: Layout
    dst: Layout
    kv: Layout = None

    @property
    def roles(self):
        return tuple(sorted(set(self.src.listed + self.dst.listed + (() if self.kv is None else self.kv.listed))))

    @property
    def predictions(self):
        target_list = self.kv.listed if self.kv else self.dst.listed
        p = {"source_copy": self.src.frontier, "clean_destination": self.dst.frontier,
             "set_transferred_list" if self.kv else "set": first_absent(target_list, self.src.written),
             "count_transferred_list" if self.kv else "count": target_list[len(self.src.written)],
             "order_id": target_list[self.src.listed.index(self.src.frontier)],
             "last_written_successor": target_list[target_list.index(self.src.written[-1]) + 1]}
        if self.kv:
            p.update(kv_only=self.kv.frontier, count_original_destination=self.dst.listed[len(self.src.written)])
        return p

    def record(self):
        result = {"id": self.id, "version": SCENARIO_VERSION,
                  "layouts": {"p_src": self.src.record(), "p_dst": self.dst.record()},
                  "symbolic_predictions": self.predictions,
                  "set_rule": "first listed task absent from source completed set",
                  "order_id_rule": "source frontier's zero-based list index applied to recipient list",
                  "count_rule": "source completed count as zero-based index in named list",
                  "last_written_rule": "successor of final written source role in recipient list"}
        if self.kv:
            result["layouts"]["p_kv"] = self.kv.record()
        result["definition_sha256"] = digest(result)
        return result


SCENARIOS = {
    "ALT1": Scenario("ALT1", Layout(tuple("abcd"), tuple("abd")), Layout(tuple("abde"), tuple("a"))),
    "ALT2": Scenario("ALT2", Layout(tuple("abcd"), tuple("abd")), Layout(tuple("adef"), tuple("a"))),
    "ALT3": Scenario("ALT3", Layout(tuple("abcd"), tuple("abc")), Layout(tuple("acbe"), tuple("a"))),
    "ALT2_KV": Scenario("ALT2_KV", Layout(tuple("abcd"), tuple("abd")), Layout(tuple("axyz"), tuple("a")), Layout(tuple("adef"), tuple("a"))),
}


def get_scenario(name):
    try:
        return SCENARIOS[name]
    except KeyError:
        raise ValueError(f"Unknown scenario: {name}") from None
