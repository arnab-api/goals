"""Versioned finite suite: validation evidence, not proof of equivalence."""
import random

SUITE_VERSION = "1.0.0"


def cases():
    r = random.Random(7319)
    ints = list(range(-40, 41)) + [-1000000, 1000000, -1024, 1023, 99, 100, 101, -101, 999]
    strings = ["", "a", "A", "aa", "ab", "aba", "Hello WORLD", " a\tb\n", "  ", "0012", "-13", "a1b2", "abcABC", "éßİΩ", "٠١٢३４", "a\u2003b", "\x00", "a!b?", "abca", "racecar", "Abc", "ABC", "123", "a" * 128]
    alphabet = "abAB09 !\téß"
    strings += ["".join(r.choice(alphabet) for _ in range(r.randrange(20))) for _ in range(80)]
    li = [[], [0], [-1], [1], [1, 1], [1, 2], [2, 1], [-2, 0, 2], [1, 2, 1], [1, 1, 2, 2], [1000000, -1000000], list(range(32)), [0] * 32, [3, -1, 3, -1, 0]]
    li += [[r.randrange(-9, 10) for _ in range(r.randrange(14))] for _ in range(100)]
    ls = [[], [""], ["", ""], ["a"], ["a", "a"], ["a", "b"], ["b", "a"], ["ab", "ba", "AB", "", "ab"], ["A", "bc", "D", ""], ["a", "b", "a"], ["one", "", "two"], ["éß", "İΩ", "123"], ["x" * 32] * 32, ["Tea", "eat", "ate", "", "ABC", "ABC", "x", ""]]
    words = ["", "a", "b", "ab", "ba", "AA", "A", "abc", "123", "a!", "a b", "éß", "İ"]
    ls += [[r.choice(words) for _ in range(r.randrange(14))] for _ in range(100)]
    return {"int": ints, "str": strings, "list[int]": li, "list[str]": ls}
