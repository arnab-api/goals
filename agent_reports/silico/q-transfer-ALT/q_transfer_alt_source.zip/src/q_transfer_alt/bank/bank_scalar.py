"""Scalar tasks over the bounded domains in task.py.

Family policy: families group a shared computational primitive, not purportedly
independent problems. All decimal representations/aggregations share one family;
all binary operations share one family; division/rounding variants share one;
and square-root variants share one. String case maps, boundary trimming,
positional selections and whitespace tokenization group their variants.
Character predicates and counts share a classification family; sorting and
deduplication share an ordering/deduplication family. Distinct IDs
and finite-suite signatures do not establish computational independence.
"""
from .task import Task


def int_absolute(x):
    if x < 0:
        return -x
    return x


def int_square(x):
    return pow(x, 2)


def int_negate(x):
    return 0 - x


def int_sign(x):
    if x < 0:
        return -1
    if x > 0:
        return 1
    return 0


def int_even(x):
    return (x & 1) == 0


def int_floor_half(x):
    quotient, remainder = divmod(x, 2)
    return quotient


def int_ceil_half(x):
    quotient, remainder = divmod(x, 2)
    if remainder:
        quotient += 1
    return quotient


def int_modulo_ten(x):
    quotient = x // 10
    return x - quotient * 10


def int_floor_ten(x):
    return x - x % 10


def int_triangular(x):
    n = -x if x < 0 else x
    # Divide an even factor first, rather than multiplying then dividing.
    if n % 2:
        return n * ((n + 1) // 2)
    return (n // 2) * (n + 1)


def int_digit_count(x):
    n = -x if x < 0 else x
    count = 1
    while n >= 10:
        n //= 10
        count += 1
    return count


def int_digit_sum(x):
    n = -x if x < 0 else x
    total = 0
    while n:
        n, digit = divmod(n, 10)
        total += digit
    return total


def int_digit_max(x):
    n = -x if x < 0 else x
    maximum = 0
    while n:
        n, digit = divmod(n, 10)
        if digit > maximum:
            maximum = digit
    return maximum


def int_reverse_digits(x):
    n = -x if x < 0 else x
    result = 0
    while n:
        n, digit = divmod(n, 10)
        result = result * 10 + digit
    return result


def int_digits(x):
    n = -x if x < 0 else x
    result = []
    while True:
        n, digit = divmod(n, 10)
        result.insert(0, digit)
        if n == 0:
            return result


def int_zero_digits(x):
    n = -x if x < 0 else x
    count = 0
    while True:
        n, digit = divmod(n, 10)
        if digit == 0:
            count += 1
        if n == 0:
            return count


def int_unique_digits(x):
    n = -x if x < 0 else x
    seen = [False] * 10
    while True:
        n, digit = divmod(n, 10)
        seen[digit] = True
        if not n:
            break
    count = 0
    for present in seen:
        if present:
            count += 1
    return count


def int_digit_palindrome(x):
    n = -x if x < 0 else x
    original = n
    reverse = 0
    while n:
        n, digit = divmod(n, 10)
        reverse = reverse * 10 + digit
    return original == reverse


def int_bit_length(x):
    n = -x if x < 0 else x
    count = 0
    while n:
        n //= 2
        count += 1
    return count


def int_popcount(x):
    n = -x if x < 0 else x
    count = 0
    while n:
        n, bit = divmod(n, 2)
        count += bit
    return count


def int_power_two(x):
    if x <= 0:
        return False
    n = x
    while n % 2 == 0:
        n //= 2
    return n == 1


def int_lowest_bit(x):
    n = -x if x < 0 else x
    if n == 0:
        return 0
    result = 1
    while n % 2 == 0:
        result *= 2
        n //= 2
    return result


def int_clear_lowest_bit(x):
    n = -x if x < 0 else x
    if n == 0:
        return 0
    divisor = 1
    while (n // divisor) % 2 == 0:
        divisor *= 2
    return n - divisor


def int_binary(x):
    n = -x if x < 0 else x
    result = ''
    while True:
        n, bit = divmod(n, 2)
        result = ('1' if bit else '0') + result
        if not n:
            return result


def int_bit_positions(x):
    n = -x if x < 0 else x
    result = []
    index = 0
    while n:
        n, bit = divmod(n, 2)
        if bit:
            result.append(index)
        index += 1
    return result


def int_bit_parity(x):
    n = -x if x < 0 else x
    odd = False
    while n:
        if n % 2:
            odd = not odd
        n //= 2
    return int(odd)


def int_sqrt_magnitude(x):
    n = -x if x < 0 else x
    low, high = 0, n + 1
    while low + 1 < high:
        mid = (low + high) // 2
        if mid * mid <= n:
            low = mid
        else:
            high = mid
    return low


def int_perfect_square(x):
    if x < 0:
        return False
    # Successive odd differences enumerate squares, at most 1001 iterations.
    remainder, odd = x, 1
    while remainder > 0:
        remainder -= odd
        odd += 2
    return remainder == 0


def int_decimal(x):
    n = -x if x < 0 else x
    result = ''
    while True:
        n, digit = divmod(n, 10)
        result = chr(48 + digit) + result
        if not n:
            break
    if x < 0:
        result = '-' + result
    return result


def int_clamp(x):
    if x < -100:
        return -100
    if x > 100:
        return 100
    return x


def int_toward_zero(x):
    if x > 0:
        return x - 1
    if x < 0:
        return x + 1
    return 0


def int_digit_square_sum(x):
    n = -x if x < 0 else x
    total = 0
    while n:
        n, digit = divmod(n, 10)
        total += digit * digit
    return total


def str_length(x):
    count = 0
    for character in x:
        count += 1
    return count


def str_upper(x):
    result = []
    for character in x:
        result.append(character.upper())
    return ''.join(result)


def str_casefold(x):
    result = []
    for character in x:
        result.append(character.casefold())
    return ''.join(result)


def str_strip(x):
    start, stop = 0, len(x)
    while start < stop and x[start].isspace():
        start += 1
    while stop > start and x[stop - 1].isspace():
        stop -= 1
    return x[start:stop]


def str_lstrip(x):
    result = ''
    started = False
    for character in x:
        if not character.isspace():
            started = True
        if started:
            result += character
    return result


def str_rstrip(x):
    result, pending = '', ''
    for character in x:
        if character.isspace():
            pending += character
        else:
            result += pending + character
            pending = ''
    return result


def str_reverse(x):
    result = ''
    for character in x:
        result = character + result
    return result


def str_even_positions(x):
    result = ''
    take = True
    for character in x:
        if take:
            result += character
        take = not take
    return result


def str_odd_positions(x):
    result = ''
    take = False
    for character in x:
        if take:
            result += character
        take = not take
    return result


def str_rotate_left(x):
    result = ''
    for i in range(1, len(x)):
        result += x[i]
    if x:
        result += x[0]
    return result


def str_rotate_right(x):
    result = ''
    if x:
        result = x[len(x) - 1]
    for i in range(len(x) - 1):
        result += x[i]
    return result


def str_words(x):
    result, word = [], ''
    for character in x:
        if character.isspace():
            if word:
                result.append(word)
                word = ''
        else:
            word += character
    if word:
        result.append(word)
    return result


def str_word_lengths(x):
    result, length = [], 0
    for character in x:
        if character.isspace():
            if length:
                result.append(length)
                length = 0
        else:
            length += 1
    if length:
        result.append(length)
    return result


def str_normalize_whitespace(x):
    result = ''
    pending = False
    for character in x:
        if character.isspace():
            pending = bool(result)
        else:
            if pending:
                result += ' '
            result += character
            pending = False
    return result


def str_remove_whitespace(x):
    result = ''
    for character in x:
        if not character.isspace():
            result += character
    return result


def str_count_whitespace(x):
    count = 0
    for character in x:
        if character.isspace():
            count += 1
    return count


def str_count_alpha(x):
    count = 0
    for character in x:
        if character.isalpha():
            count += 1
    return count


def str_count_decimal(x):
    count = 0
    for character in x:
        if character.isdecimal():
            count += 1
    return count


def str_count_ascii_digits(x):
    count = 0
    for character in x:
        if 48 <= ord(character) <= 57:
            count += 1
    return count


def str_palindrome(x):
    for i in range(len(x) // 2):
        if x[i] != x[len(x) - 1 - i]:
            return False
    return True


def str_sorted_unique(x):
    # Insertion into an ordered list avoids set + sorted from the expression.
    result = []
    for character in x:
        if character in result:
            continue
        index = 0
        while index < len(result) and result[index] < character:
            index += 1
        result.insert(index, character)
    return result


def str_stable_unique(x):
    result = ''
    for character in x:
        if character not in result:
            result += character
    return result


def str_sorted_chars(x):
    result = []
    for character in x:
        index = 0
        while index < len(result) and result[index] <= character:
            index += 1
        result.insert(index, character)
    return ''.join(result)


def str_codepoints(x):
    result = []
    for character in x:
        result.append(ord(character))
    return result


def str_ascii(x):
    for character in x:
        if ord(character) >= 128:
            return False
    return True


def str_printable(x):
    for character in x:
        if not character.isprintable():
            return False
    return True


def str_alpha(x):
    if not x:
        return False
    for character in x:
        if not character.isalpha():
            return False
    return True


def str_decimal(x):
    if not x:
        return False
    for character in x:
        if not character.isdecimal():
            return False
    return True


def str_has_upper(x):
    for character in x:
        if character.isupper():
            return True
    return False


def str_first(x):
    for character in x:
        return character
    return ''


def str_last(x):
    result = ''
    for character in x:
        result = character
    return result


def str_count_lf(x):
    count = 0
    for character in x:
        if ord(character) == 10:
            count += 1
    return count


TASKS = [
    Task('py.int.absolute.v1', 'int', 'Absolute value, including zero.', 'int', 'int.sign', 'abs(x)', int_absolute),
    Task('py.int.square.v1', 'int', 'Square of the signed integer.', 'int', 'int.polynomial', 'x * x', int_square),
    Task('py.int.negate.v1', 'int', 'Additive inverse, with zero unchanged.', 'int', 'int.sign', '-x', int_negate),
    Task('py.int.sign.v1', 'int', 'Return -1, 0, or 1 for negative, zero, or positive input.', 'int', 'int.sign', '(x > 0) - (x < 0)', int_sign),
    Task('py.int.even.v1', 'int', 'Whether x is divisible by two; zero is even.', 'bool', 'int.division', 'x % 2 == 0', int_even),
    Task('py.int.floor_half.v1', 'int', 'Half of x rounded toward negative infinity.', 'int', 'int.division', 'x // 2', int_floor_half),
    Task('py.int.ceil_half.v1', 'int', 'Half of x rounded toward positive infinity.', 'int', 'int.division', '-(-x // 2)', int_ceil_half),
    Task('py.int.modulo_ten.v1', 'int', 'Nonnegative remainder modulo ten, even for negative x.', 'int', 'int.division', 'x % 10', int_modulo_ten),
    Task('py.int.floor_ten.v1', 'int', 'Greatest multiple of ten no greater than x.', 'int', 'int.division', '(x // 10) * 10', int_floor_ten),
    Task('py.int.triangular.v1', 'int', 'Sum of integers from 1 through abs(x); zero gives zero.', 'int', 'int.polynomial', 'abs(x) * (abs(x) + 1) // 2', int_triangular),
    Task('py.int.digit_count.v1', 'int', 'Number of decimal digits in abs(x); zero has one digit.', 'int', 'int.decimal_digits', 'len(str(abs(x)))', int_digit_count),
    Task('py.int.digit_sum.v1', 'int', 'Sum of decimal digits of abs(x); zero gives zero.', 'int', 'int.decimal_digits', 'sum(int(c) for c in str(abs(x)))', int_digit_sum),
    Task('py.int.digit_max.v1', 'int', 'Largest decimal digit of abs(x); zero gives zero.', 'int', 'int.decimal_digits', 'max(int(c) for c in str(abs(x)))', int_digit_max),
    Task('py.int.reverse_digits.v1', 'int', 'Reverse decimal digits of abs(x), dropping leading zeros in the result.', 'int', 'int.decimal_digits', 'int(str(abs(x))[::-1])', int_reverse_digits),
    Task('py.int.digits.v1', 'int', 'Decimal digits of abs(x) in left-to-right order; zero gives [0].', 'list[int]', 'int.decimal_digits', '[int(c) for c in str(abs(x))]', int_digits),
    Task('py.int.zero_digits.v1', 'int', 'Count zero digits in abs(x); input zero gives one.', 'int', 'int.decimal_digits', "str(abs(x)).count('0')", int_zero_digits),
    Task('py.int.unique_digits.v1', 'int', 'Count distinct decimal digits of abs(x); zero gives one.', 'int', 'int.decimal_digits', 'len(set(str(abs(x))))', int_unique_digits),
    Task('py.int.digit_palindrome.v1', 'int', 'Whether decimal abs(x) reads identically backward; zero is true.', 'bool', 'int.decimal_digits', 'str(abs(x)) == str(abs(x))[::-1]', int_digit_palindrome),
    Task('py.int.bit_length.v1', 'int', 'Number of bits needed for abs(x), excluding leading zeros; zero gives zero.', 'int', 'int.bits', 'abs(x).bit_length()', int_bit_length),
    Task('py.int.popcount.v1', 'int', 'Count one bits in the binary magnitude of x; zero gives zero.', 'int', 'int.bits', "bin(abs(x)).count('1')", int_popcount),
    Task('py.int.power_two.v1', 'int', 'Whether x is a positive power of two, including one.', 'bool', 'int.bits', 'x > 0 and (x & (x - 1)) == 0', int_power_two),
    Task('py.int.lowest_bit.v1', 'int', 'Value of lowest set bit of abs(x); zero gives zero.', 'int', 'int.bits', 'abs(x) & -abs(x)', int_lowest_bit),
    Task('py.int.clear_lowest_bit.v1', 'int', 'Magnitude of x with its lowest set bit cleared; zero stays zero.', 'int', 'int.bits', 'abs(x) & (abs(x) - 1)', int_clear_lowest_bit),
    Task('py.int.binary.v1', 'int', 'Binary magnitude without prefix or sign; zero gives the string 0.', 'str', 'int.bits', "format(abs(x), 'b')", int_binary),
    Task('py.int.bit_positions.v1', 'int', 'Ascending zero-based positions of set bits in abs(x); zero gives [].', 'list[int]', 'int.bits', '[i for i in range(abs(x).bit_length()) if abs(x) & (1 << i)]', int_bit_positions),
    Task('py.int.bit_parity.v1', 'int', 'One for an odd count of magnitude one bits, otherwise zero.', 'int', 'int.bits', "bin(abs(x)).count('1') % 2", int_bit_parity),
    Task('py.int.sqrt_magnitude.v1', 'int', 'Floor of square root of abs(x), on the bounded integer domain.', 'int', 'int.root', 'int(abs(x) ** 0.5)', int_sqrt_magnitude),
    Task('py.int.perfect_square.v1', 'int', 'Whether x is a nonnegative perfect square; zero is true.', 'bool', 'int.root', 'x >= 0 and int(x ** 0.5) ** 2 == x', int_perfect_square),
    Task('py.int.decimal.v1', 'int', 'Signed decimal representation, without plus sign or leading zeros.', 'str', 'int.decimal_digits', 'str(x)', int_decimal),
    Task('py.int.clamp.v1', 'int', 'Clamp x to the inclusive interval [-100, 100].', 'int', 'int.sign', 'min(100, max(-100, x))', int_clamp),
    Task('py.int.toward_zero.v1', 'int', 'Move one integer step toward zero; zero is unchanged.', 'int', 'int.sign', 'x - ((x > 0) - (x < 0))', int_toward_zero),
    Task('py.int.digit_square_sum.v1', 'int', 'Sum of squared decimal digits of abs(x); zero gives zero.', 'int', 'int.decimal_digits', 'sum(int(c) ** 2 for c in str(abs(x)))', int_digit_square_sum),
    Task('py.str.length.v1', 'str', 'Number of Unicode code points, not graphemes; empty gives zero.', 'int', 'str.position', 'len(x)', str_length),
    Task('py.str.upper.v1', 'str', 'Unicode uppercase mapping, allowing expansions; empty stays empty.', 'str', 'str.case_mapping', 'x.upper()', str_upper),
    Task('py.str.casefold.v1', 'str', 'Unicode casefold mapping, allowing expansions; empty stays empty.', 'str', 'str.case_mapping', 'x.casefold()', str_casefold),
    Task('py.str.strip.v1', 'str', 'Remove Unicode whitespace at both ends; all-whitespace gives empty.', 'str', 'str.trim', 'x.strip()', str_strip),
    Task('py.str.lstrip.v1', 'str', 'Remove leading Unicode whitespace only; all-whitespace gives empty.', 'str', 'str.trim', 'x.lstrip()', str_lstrip),
    Task('py.str.rstrip.v1', 'str', 'Remove trailing Unicode whitespace only; all-whitespace gives empty.', 'str', 'str.trim', 'x.rstrip()', str_rstrip),
    Task('py.str.reverse.v1', 'str', 'Reverse Unicode code points, not graphemes; empty stays empty.', 'str', 'str.position', 'x[::-1]', str_reverse),
    Task('py.str.even_positions.v1', 'str', 'Keep code points at even zero-based indices; empty stays empty.', 'str', 'str.position', 'x[::2]', str_even_positions),
    Task('py.str.odd_positions.v1', 'str', 'Keep code points at odd zero-based indices; length below two gives empty.', 'str', 'str.position', 'x[1::2]', str_odd_positions),
    Task('py.str.rotate_left.v1', 'str', 'Rotate left by one code point; empty and singleton stay unchanged.', 'str', 'str.position', 'x[1:] + x[:1]', str_rotate_left),
    Task('py.str.rotate_right.v1', 'str', 'Rotate right by one code point; empty and singleton stay unchanged.', 'str', 'str.position', 'x[-1:] + x[:-1]', str_rotate_right),
    Task('py.str.words.v1', 'str', 'Split on runs of Unicode whitespace without empty tokens; empty gives [].', 'list[str]', 'str.whitespace_tokens', 'x.split()', str_words),
    Task('py.str.word_lengths.v1', 'str', 'Code-point lengths of Unicode-whitespace-separated words; empty gives [].', 'list[int]', 'str.whitespace_tokens', '[len(word) for word in x.split()]', str_word_lengths),
    Task('py.str.normalize_whitespace.v1', 'str', 'Join Unicode-whitespace-separated words with ASCII spaces; empty gives empty.', 'str', 'str.whitespace_tokens', "' '.join(x.split())", str_normalize_whitespace),
    Task('py.str.remove_whitespace.v1', 'str', 'Remove every Unicode whitespace code point; empty stays empty.', 'str', 'str.whitespace_tokens', "''.join(c for c in x if not c.isspace())", str_remove_whitespace),
    Task('py.str.count_whitespace.v1', 'str', 'Count Unicode whitespace code points; empty gives zero.', 'int', 'str.character_class', 'sum(c.isspace() for c in x)', str_count_whitespace),
    Task('py.str.count_alpha.v1', 'str', 'Count Unicode alphabetic code points by isalpha; empty gives zero.', 'int', 'str.character_class', 'sum(c.isalpha() for c in x)', str_count_alpha),
    Task('py.str.count_decimal.v1', 'str', 'Count Unicode decimal code points, excluding nondecimal digits; empty gives zero.', 'int', 'str.character_class', 'sum(c.isdecimal() for c in x)', str_count_decimal),
    Task('py.str.count_ascii_digits.v1', 'str', 'Count only ASCII digits 0 through 9; empty gives zero.', 'int', 'str.character_class', "sum('0' <= c <= '9' for c in x)", str_count_ascii_digits),
    Task('py.str.palindrome.v1', 'str', 'Exact case-sensitive code-point palindrome; empty and singleton are true.', 'bool', 'str.position', 'x == x[::-1]', str_palindrome),
    Task('py.str.sorted_unique.v1', 'str', 'Distinct code points sorted by Unicode value as a list; empty gives [].', 'list[str]', 'str.ordering_deduplication', 'sorted(set(x))', str_sorted_unique),
    Task('py.str.stable_unique.v1', 'str', 'Keep first occurrence of each exact code point in encounter order; empty stays empty.', 'str', 'str.ordering_deduplication', "''.join(dict.fromkeys(x))", str_stable_unique),
    Task('py.str.sorted_chars.v1', 'str', 'Sort all code points by Unicode value, retaining repeats; empty stays empty.', 'str', 'str.ordering_deduplication', "''.join(sorted(x))", str_sorted_chars),
    Task('py.str.codepoints.v1', 'str', 'Unicode integer value of each code point in order; empty gives [].', 'list[int]', 'str.codepoint_encoding', '[ord(c) for c in x]', str_codepoints),
    Task('py.str.ascii.v1', 'str', 'Whether every code point is in U+0000 through U+007F; empty is true.', 'bool', 'str.character_class', 'x.isascii()', str_ascii),
    Task('py.str.printable.v1', 'str', 'Whether all code points are Python-printable; empty is true.', 'bool', 'str.character_class', 'x.isprintable()', str_printable),
    Task('py.str.alpha.v1', 'str', 'Whether nonempty and all code points are Unicode alphabetic; empty is false.', 'bool', 'str.character_class', 'x.isalpha()', str_alpha),
    Task('py.str.decimal.v1', 'str', 'Whether nonempty and all code points are Unicode decimal digits; empty is false.', 'bool', 'str.character_class', 'x.isdecimal()', str_decimal),
    Task('py.str.has_upper.v1', 'str', 'Whether any code point is Unicode uppercase; empty is false.', 'bool', 'str.character_class', 'any(c.isupper() for c in x)', str_has_upper),
    Task('py.str.first.v1', 'str', 'First code point, or empty string for empty input.', 'str', 'str.position', 'x[:1]', str_first),
    Task('py.str.last.v1', 'str', 'Last code point, or empty string for empty input.', 'str', 'str.position', 'x[-1:]', str_last),
    Task('py.str.count_lf.v1', 'str', 'Count literal LF (U+000A) only, not other line separators; empty gives zero.', 'int', 'str.character_class', "x.count('\\n')", str_count_lf),
]
