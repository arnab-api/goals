"""Standard-library-only task definitions; independent of the legacy bank."""
from dataclasses import dataclass
import hashlib
import inspect
import json
from typing import Callable, Any

BANK_VERSION = "1.0.0"
DOMAIN_VERSION = "1.0.0"
DOMAINS = {
    "int": {"kind": "int", "minimum": -1000000, "maximum": 1000000, "exclude_bool": True},
    "str": {"kind": "str", "max_length": 128, "alphabet": "Unicode code points"},
    "list[int]": {"kind": "list[int]", "max_length": 32, "element_minimum": -1000000, "element_maximum": 1000000, "exclude_bool": True},
    "list[str]": {"kind": "list[str]", "max_length": 32, "element_max_length": 32, "alphabet": "Unicode code points"},
}


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":"))


def digest(value):
    return hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()


def typed(value):
    """Keep bool/int and container identities distinct in signatures."""
    if type(value) is list:
        return {"type": "list", "value": [typed(v) for v in value]}
    if type(value) not in (int, bool, str):
        raise TypeError(f"Unsupported output type: {type(value).__name__}")
    return {"type": type(value).__name__, "value": value}


def in_domain(datatype, value):
    if datatype == "int":
        return type(value) is int and -1000000 <= value <= 1000000
    if datatype == "str":
        return type(value) is str and len(value) <= 128
    if datatype == "list[int]":
        return type(value) is list and len(value) <= 32 and all(in_domain("int", v) for v in value)
    if datatype == "list[str]":
        return type(value) is list and len(value) <= 32 and all(type(v) is str and len(v) <= 32 for v in value)
    raise ValueError(f"Unknown datatype: {datatype}")


def output_matches(output_type, value):
    if output_type in ("int", "bool", "str"):
        return type(value).__name__ == output_type
    if output_type in ("list[int]", "list[str]"):
        element = output_type[5:-1]
        return type(value) is list and all(type(v).__name__ == element for v in value)
    return False


@dataclass(frozen=True)
class Task:
    id: str
    datatype: str
    description: str
    output_type: str
    family: str
    expression: str
    reference: Callable[[Any], Any]
    incompatible_ids: tuple = ()
    compatibility_note: str = "Distinct IDs and finite-suite signatures required; optional distinct-family policy."

    def evaluate(self, value):
        if not in_domain(self.datatype, value):
            raise ValueError(f"Input outside {self.datatype} domain for {self.id}")
        # Expressions are trusted shipped code, NOT a sandbox for external strings.
        return eval(self.expression, {"x": value})

    def record(self):
        record = {"id": self.id, "datatype": self.datatype, "description": self.description,
                  "output_type": self.output_type, "family": self.family,
                  "expression": self.expression, "assignment": "{name} = " + self.expression,
                  "input_domain": DOMAINS[self.datatype], "domain_version": DOMAIN_VERSION,
                  "compatibility": {"incompatible_ids": list(self.incompatible_ids), "note": self.compatibility_note},
                  "reference_name": self.reference.__name__,
                  "reference_source": inspect.getsource(self.reference)}
        record["definition_sha256"] = digest(record)
        return record
