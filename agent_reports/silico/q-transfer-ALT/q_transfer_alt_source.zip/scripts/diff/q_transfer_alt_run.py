#!/usr/bin/env python3
"""Portable q-transfer-ALT run entry point (no legacy setup imports)."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "src"))
from q_transfer_alt.runtime import main

if __name__ == "__main__":
    main()
