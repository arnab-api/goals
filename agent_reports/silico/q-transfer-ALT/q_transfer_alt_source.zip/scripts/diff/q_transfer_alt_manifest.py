#!/usr/bin/env python3
"""Hash an existing local checkpoint without loading weights or downloading."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "src"))
from q_transfer_alt.provenance import main

if __name__ == "__main__":
    main()
